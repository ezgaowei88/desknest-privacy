// dock.js：分类渲染、hover 二级面板、点击启动、内置分类图标、条目移动
'use strict';

window.Dock = (() => {
  // 内置分类 SVG（单色，currentColor）
  const CAT_ICONS = {
    office: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M5 3.8h9.5L19 8.3V20a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4.8a1 1 0 0 1 1-1z"/><path d="M14 4v5h5M8.5 12.5h7M8.5 16h5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    dev: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 7.5 4 12l4.5 4.5M15.5 7.5 20 12l-4.5 4.5M13 5l-2.4 14"/></svg>',
    internet: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c-4.7 4.7-4.7 12.3 0 17M12 3.5c4.7 4.7 4.7 12.3 0 17"/></svg>',
    game: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M7 8h10a4.5 4.5 0 0 1 4.4 5.4l-.7 3.3A2.6 2.6 0 0 1 16.4 18l-2-2.4h-4.8L7.6 18a2.6 2.6 0 0 1-4.3-1.3l-.7-3.3A4.5 4.5 0 0 1 7 8z"/><path d="M8 11v3M6.5 12.5h3M15.5 11.4h.01M17.8 13.4h.01" stroke-width="1.9"/></svg>',
    tool: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 6.5a4 4 0 0 0-5.6 4.9L3.6 16.7a1.8 1.8 0 0 0 2.6 2.6l5.3-5.3a4 4 0 0 0 4.9-5.6l-2.6 2.6-2.3-2.3 2.6-2.6z"/></svg>',
    design: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 9 9c0-1.7-1.3-3-3-3h-2.5A2.5 2.5 0 0 1 13 6.5V4a1 1 0 0 0-1-1z"/><circle cx="8" cy="10" r="1.2" fill="currentColor" stroke="none"/><circle cx="7.2" cy="15" r="1.2" fill="currentColor" stroke="none"/></svg>',
    inbox: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 13.5 6 5.5a1.5 1.5 0 0 1 1.4-1h9.2a1.5 1.5 0 0 1 1.4 1l2.5 8v4a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5v-4z"/><path d="M3.5 13.5H9a3 3 0 0 0 6 0h5.5"/></svg>',
    star: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3.6 2.6 5.4 5.9.8-4.3 4.1 1.1 5.9L12 17l-5.3 2.8 1.1-5.9L3.5 9.8l5.9-.8z"/></svg>',
    folder: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 6.5a1.5 1.5 0 0 1 1.5-1.5h4l2 2.5h7.5a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5z"/></svg>',
    book: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H10a2 2 0 0 1 2 2v13a2 2 0 0 0-2-2H5.5A1.5 1.5 0 0 1 4 15.5z"/><path d="M20 5.5A1.5 1.5 0 0 0 18.5 4H14a2 2 0 0 0-2 2v13a2 2 0 0 1 2-2h4.5a1.5 1.5 0 0 0 1.5-1.5z"/></svg>',
    cloud: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M7 18h9.5a3.5 3.5 0 0 0 .4-7A5.5 5.5 0 0 0 6.4 10.2A3.9 3.9 0 0 0 7 18z"/></svg>',
    shield: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.2 5 6v5.5c0 4.3 2.9 8.1 7 9.3 4.1-1.2 7-5 7-9.3V6z"/><path d="m9.2 12 2 2 3.6-3.8"/></svg>',
    music: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 17.5V6.2l9-1.8v11"/><circle cx="7" cy="17.8" r="2.4"/><circle cx="16" cy="15.6" r="2.4"/></svg>',
    chat: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12.5a7.5 7.5 0 0 1-10.9 6.7L4.5 20.5l1.3-4.4A7.5 7.5 0 1 1 20 12.5z"/></svg>',
    money: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M8.5 8.5 12 12l3.5-3.5M15.5 15.5 12 12l-3.5 3.5"/></svg>'
  };

  const ICON_KEYS = Object.keys(CAT_ICONS);
  const PALETTE = ['#00E58C', '#37D67A', '#7BE495', '#22C1C3', '#4A9EFF', '#A77BFF', '#FF7A90', '#FFB347'];

  const el = {
    catList: document.getElementById('cat-list'),
    panel: document.getElementById('panel'),
    panelBody: document.getElementById('panel-body')
  };

  let categories = [];
  let panelCatId = null;
  let hideTimer = null;

  // ★ 拖拽归类相关状态
  //   { item, srcEl, srcCatId, sx, sy, active, ghost, targetId, srcCatEl }
  let itemDrag = null;
  let suppressClickUntil = 0;   // 拖拽结束后的短暂窗口内忽略 click（防误启动）
  // ★ 拖拽诊断用：记录最近一次拖拽的起点/终点/是否提交（原生日志可查，便于回归）
  let lastDrag = null;

  // ★ 重命名覆盖表：%APPDATA%\DeskNest\rename.json → 原生注入 window.__RENAME
  //   单独存表的原因：categories.json 每次重扫都会整表重建，写在条目上的自定义名会被冲掉
  let renameMap = Object.assign({}, window.__RENAME || {});

  function iconSrc(item) {
    if (!item.iconFile) return null;
    // data: URL（Rust 壳内嵌图标）直接透传；Electron 走自定义协议
    if (item.iconFile.startsWith('data:')) return item.iconFile;
    return `desknest-icon://local/${encodeURIComponent(item.iconFile)}`;
  }

  // ★ 显示名：优先用户重命名，否则去掉快捷方式后缀 .lnk（"Download.lnk" → "Download"）
  function dispName(item) {
    if (!item) return '';
    const custom = renameMap[item.path];
    if (custom) return custom;
    // ★ v1.33.10：去掉常见快捷方式/可执行文件后缀（原来只去 .lnk，
    //   导致 AION 2.url 这类网页快捷方式显示名残留「.url」）
    return String(item.name || '')
      .replace(/\.(lnk|url|website|appref-ms|exe)$/i, '');
  }

  // 覆盖表变更后重刷（菜单重命名 / 重扫完成后调用）
  function applyRenames(map) {
    if (map) renameMap = Object.assign({}, map);
    try { renderCats(); } catch (e) { /* ignore */ }
    if (panelCatId && !el.panel.hidden) {
      const cat = categories.find((c) => c.id === panelCatId);
      const anchor = el.catList.querySelector(`.cat[data-id="${panelCatId}"]`);
      if (cat && anchor) openPanel(cat, anchor);
    }
    if (window.Search && window.Search.refresh) window.Search.refresh();
  }

  // ★ 兜底图标：取软件名首字符，渲染成"默认应用图标"样式
  //   （原生已保证 iconFile 必有值；此处再兜一层协议/解码异常，杜绝空白与破损图标）
  function makePhIcon(item) {
    const ch = dispName(item).trim().charAt(0) || '?';
    const s = document.createElement('span');
    s.className = 'ph';
    s.textContent = ch.toUpperCase();
    return s;
  }

  // ★ 统一图标元素工厂：img 加载失败（协议异常/解码失败/图标缺失）自动降级为兜底图标
  function makeIconEl(item) {
    const src = iconSrc(item);
    if (!src) return makePhIcon(item);
    const img = document.createElement('img');
    img.alt = '';
    img.draggable = false;   // ★ HTML img 默认可拖拽 → 按住移动触发 Chromium 拖放接管（pointercancel），必须禁掉
    img.src = src;
    // 注意：CSP 为 script-src 'self'，内联 onerror 会被拦截，必须用事件监听
    img.addEventListener('error', () => {
      if (img.parentNode) img.replaceWith(makePhIcon(item));
    });
    return img;
  }

  // 分类图标：cat.icon 形如 'builtin:office'，需剥前缀；未知键回退 inbox
  function catIconSvg(iconKey) {
    const key = String(iconKey || '').replace(/^builtin:/, '');
    return CAT_ICONS[key] || CAT_ICONS.inbox;
  }

  function renderCats() {
    el.catList.innerHTML = '';
    for (const cat of categories) {
      const d = document.createElement('div');
      d.className = 'cat';
      d.dataset.id = cat.id;
      // ★ 不再设 draggable=true：组合宿主下 HTML5 DnD 不可用（壳未实现拖放转发），
      //   draggable 只会让 Chromium 在按下移动后接管指针流（pointercancel）并吞掉
      //   后续鼠标事件 → 条目拖拽归类永远失败。芯片排序由右键菜单（整理/左右移）承担；
      //   attachDrag 的 dragstart 监听保留，待壳实现 DragEnter/DragOver/Drop 转发后恢复。
      d.title = `${cat.name}（右键更多操作）`;
      d.style.color = cat.color || 'var(--accent)';
      d.innerHTML = `${catIconSvg(cat.icon)}
        ${cat.items.length ? `<span class="count">${cat.items.length}</span>` : ''}
        <span class="cname">${escapeHtml(cat.name)}</span>
        <span class="tip">${escapeHtml(cat.name)}</span>`;
      d.addEventListener('mouseenter', () => {
        if (dragging || dragActive() || chipDragActive()) return;   // 拖拽/排序经过时不弹二级面板
        clearTimeout(hideTimer);
        openPanel(cat, d);
      });
      d.addEventListener('mouseleave', () => scheduleHide());
      // ★ 右键：分类芯片菜单（打开/整理排序/重命名/左右移/分类管理）
      d.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (dragActive()) resetDrag('cat-ctx');
        clearTimeout(hideTimer);
        closeAll();                              // 先收起浮层，避免形状区域与菜单叠加
        if (window.Menu) window.Menu.open({ kind: 'cat', cat }, e.clientX, e.clientY);
      });
      attachDrag(d);
      attachItemDropTarget(d, cat);
      // ★ 按住即准备排序（手动鼠标实现；移动超 6px 才进入排序态，不影响单击/hover）
      d.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;                 // 非左键不启动（右键归菜单）
        if (itemDrag) resetDrag('restart');         // 与条目拖拽互斥：先清残留
        if (chipDrag) endChipDrag('restart', false);
        chipDrag = { el: d, sx: e.clientX, sy: e.clientY, active: false, order: null };
      });
      el.catList.appendChild(d);
    }
  }

  // —— ★ 条目拖拽归类（手动实现，不用 HTML5 DnD）——
  // 原因：本壳是 WebView2【组合宿主】模式。该模式下页面内 HTML5 拖拽无法启动——
  //   拖放必须由宿主窗口 RegisterDragDrop 并转发 ICoreWebView2CompositionController 的
  //   DragEnter/DragOver/Drop（crate 中这些接口确实存在，但本壳未实现该转发），
  //   因此 dragstart 永不触发 → 表现为"拖不动"。
  //   故改用普通鼠标事件（mousedown/mousemove/mouseup）自行实现拖拽。
  //
  // ★★ 本轮修复「图标卡在桌面上无法归位」：
  //   旧实现只有 document 上的 mousemove/mouseup 两个出口，一旦 mouseup 没有到达
  //   document（光标移出窗口、右键抢占、被其它元素吞掉、窗口失焦），itemDrag 会永久
  //   停留在 active 状态 → 跟随图标 .drag-ghost 永远挂在光标下、源条目一直半透明、
  //   目标分类一直保持虚线高亮，观感就是「图标卡在桌面上不动了、怎么点都不归位」。
  //   修法：把所有可能的终止条件统一收敛到 resetDrag()，并补齐出口：
  //     ① mouseup / pointerup（主出口）        ② mouseleave（判定是否真的离开窗口）
  //     ③ window.blur（窗口失焦）              ④ keydown Escape
  //     ⑤ 右键按下 / 非左键                  ⑥ 拖拽中源条目被 DOM 移除（重渲染）
  //   另：每次 mousemove 都做一次「状态自检」——若 ghost 已不在文档里则立即复位。
  function chipAt(x, y) {
    // 命中判定：ghost 设了 pointer-events:none，因此不会挡住 .cat 的命中
    const node = document.elementFromPoint(x, y);
    return node && node.closest ? node.closest('.cat') : null;
  }

  function clearDropTargets() {
    el.catList.querySelectorAll('.cat.drop-target').forEach((c) => c.classList.remove('drop-target'));
  }

  // 唯一复位入口：无论正常结束还是异常中断，都走这里，保证状态一定回到干净态
  // reason：复位出口标记（mouseup/leave-timer/ghost-gone/blur/escape/contextmenu/…），
  //         随 [drag] end 进 console 日志，回归排查时开 DevTools 即可看到
  function resetDrag(reason) {
    dropPendingDragFrame();   // ★ 异常复位也收敛：挂起的合帧一律作废
    if (!itemDrag) return;
    const st = itemDrag;
    itemDrag = null;
    if (st.ghost && st.ghost.parentNode) st.ghost.remove();
    const cls = document.body.classList;
    cls.remove('drag-ghost-active');
    cls.remove('dragging-item');
    if (st.srcEl) st.srcEl.classList.remove('dragging');
    if (st.srcCatEl) st.srcCatEl.classList.remove('drag-source');
    clearDropTargets();
    clearPanelInsertMarkers();   // ★ 面板排序模式的指示条残留清理
    if (st.active) {
      suppressClickUntil = Date.now() + 400;   // 拖拽后的 click 视为误触
      lastDrag = { path: st.item && st.item.path, from: st.srcCatId, to: st.targetId, ok: false, why: reason || '?' };
      // 诊断日志（原生日志可查，便于回归验证）
      console.log('[drag] end', JSON.stringify(lastDrag));
    }
  }

  function endItemDrag(commit) {
    if (!itemDrag) {
      // 兜底：异常情况下残留的视觉状态（例如页面重渲染后 ghost 变成了孤儿节点）
      document.querySelectorAll('.drag-ghost').forEach((g) => g.remove());
      document.body.classList.remove('drag-ghost-active', 'dragging-item');
      clearDropTargets();
      return;
    }
    const st = itemDrag;
    const targetId = st.targetId;
    const active = st.active;
    const srcCatId = st.srcCatId;
    const item = st.item;
    resetDrag('mouseup');
    if (!commit || !active || !targetId || targetId === srcCatId) return;

    // 落盘：moveItem 会打 manual 标记（重扫不覆盖）并原子写 categories.json
    const p = moveItem(srcCatId, item.path, targetId);
    lastDrag = { path: item.path, from: srcCatId, to: targetId, ok: true };
    console.log('[drag] commit', JSON.stringify(lastDrag));
    // 拖拽后同步：坞条计数已由 persist→renderCats 刷新；面板若打开则重建内容
    Promise.resolve(p).then(() => {
      if (panelCatId && !el.panel.hidden) {
        const open = categories.find((c) => c.id === panelCatId);
        const anchor = el.catList.querySelector(`.cat[data-id="${panelCatId}"]`);
        if (open && anchor) openPanel(open, anchor);
      }
    });
  }

  // 是否还有未完成的拖拽（供 scheduleHide 判断）
  function dragActive() { return !!(itemDrag && itemDrag.active); }

  // ★ 光标是否在面板内（排序模式判定；rect 判定比 elementFromPoint 稳，不受 ghost 影响）
  function inPanel(x, y) {
    if (el.panel.hidden) return false;
    const r = el.panel.getBoundingClientRect();
    return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
  }

  function snapshotPanelOrder() { return [...el.panelBody.querySelectorAll('.panel-item')]; }
  function restorePanelOrder(snap) { for (const n of snap) el.panelBody.appendChild(n); }
  function clearPanelInsertMarkers() {
    el.panelBody.querySelectorAll('.panel-item.insert-before, .panel-item.insert-after')
      .forEach((n) => n.classList.remove('insert-before', 'insert-after'));
  }

  // 排序模式：★ 光标定位（09-29 v2：槽位算术 + 变化早退，修「拖拽响应滞后」）
  //   ① 槽位几何（列数 / 格宽高 / 行距 / 原点）在拖拽开始时量一次，之后按算术定位 ——
  //      不再每次 mousemove 对**全部条目** getBoundingClientRect；那是强制同步布局，
  //      面板又是毛玻璃层（backdrop-filter），每次布局都可能连带背景重算 → 拖拽发涩的主因之一。
  //   ② 目标插入锚没变就直接早退：不写 DOM、不动类名，避免每帧重排 + 玻璃层重绘。
  //   ③ 指示条固定贴**被拖拽项**下缘（跟随图标移动，不随光标漂移）。
  function panelGeom() {
    const items = [...el.panelBody.querySelectorAll('.panel-item')];
    if (!items.length) return null;
    const r0 = items[0].getBoundingClientRect();
    const w = r0.width, h = r0.height;
    let cols = 1;
    for (let i = 1; i < items.length; i++) {
      if (Math.abs(items[i].getBoundingClientRect().top - r0.top) < h / 2) cols++;
      else break;
    }
    const r1 = cols > 1 ? items[1].getBoundingClientRect() : null;
    const gapX = r1 ? Math.max(0, r1.left - (r0.left + w)) : 4;
    let gapY = 4;
    if (items.length > cols) {
      gapY = Math.max(0, items[cols].getBoundingClientRect().top - (r0.top + h));
    }
    return { x0: r0.left, y0: r0.top, w, h, cols, gapX, gapY,
             n: items.length, scroll: el.panelBody.scrollTop };
  }

  // ★ 拖拽性能探针（09-29）：统计每次 mousemove 的 JS 处理耗时与事件到达间隔，
  //   拖拽结束时通过 WebMessage 上报一行 [web] dragperf ...（原生侧未知消息会落日志）。
  //   用途：区分"JS 处理慢"与"输入/渲染管线慢"，并为后续性能回归留基线。
  const dragPerf = { n: 0, sum: 0, max: 0, ivlSum: 0, ivlMax: 0, last: 0 };
  // 帧耗时探针：拖拽期间逐帧测 rAF 间隔——若 ft_max 高说明主线程有长帧（样式/布局/绘制），
  // 若 ft 平稳但观感卡则是合成器/丢帧侧问题。随 dragperf 同行上报。
  const dragFt = { n: 0, sum: 0, max: 0, last: 0, running: false };
  function ftLoop(t) {
    if (!itemDrag || !itemDrag.active) { dragFt.running = false; dragFt.last = 0; return; }
    if (dragFt.last) {
      const d = t - dragFt.last;
      dragFt.n++; dragFt.sum += d;
      if (d > dragFt.max) dragFt.max = d;
    }
    dragFt.last = t;
    requestAnimationFrame(ftLoop);
  }
  function ftKick() {
    if (!dragFt.running) { dragFt.running = true; dragFt.last = 0; requestAnimationFrame(ftLoop); }
  }
  function dragPerfReport(reason) {
    if (dragPerf.n >= 5) {
      const avg = dragPerf.sum / dragPerf.n;
      const iavg = dragPerf.ivlSum / Math.max(1, dragPerf.n - 1);
      const favg = dragFt.n ? (dragFt.sum / dragFt.n).toFixed(1) : '-';
      try {
        window.chrome.webview.postMessage(
          'dragperf ' + reason + ' moves=' + dragPerf.n +
          ' js_avg=' + avg.toFixed(2) + 'ms js_max=' + dragPerf.max.toFixed(1) +
          'ms ivl_avg=' + iavg.toFixed(1) + 'ms ivl_max=' + dragPerf.ivlMax.toFixed(1) +
          'ms ft_avg=' + favg + 'ms ft_max=' + dragFt.max.toFixed(1) + 'ms');
      } catch (err) { /* ignore */ }
    }
    dragPerf.n = 0; dragPerf.sum = 0; dragPerf.max = 0; dragPerf.ivlSum = 0; dragPerf.ivlMax = 0; dragPerf.last = 0;
    dragFt.n = 0; dragFt.sum = 0; dragFt.max = 0; dragFt.last = 0;
  }

  // ★ rAF 合帧（v1.12.8）：mousemove 事件率可达 ~125Hz，而渲染帧只有 ≤60Hz。
  //   事件处理器里直接写 DOM/读布局会在高频事件下产生成倍的样式计算与强制布局：
  //     - sort 模式：插入锚变化时 insertBefore + 类名切换 → 面板区重排重绘
  //     - move 模式：ghost 写 left/top（布局属性）→ elementFromPoint 强制同步布局+命中测试
  //   （注：玻璃层是纯 CSS 渐变，没有 backdrop-filter；拖拽卡顿主因是上述布局抖动，
  //     不是"毛玻璃全量重绘"——v1.12.7 注释有误，在此更正。）
  //   方案：mousemove 只缓存最新一次事件坐标，rAF 回调里按当前模式分派处理：
  //   DOM 写入与布局读取都收敛到每帧一次，命中判定永远用最新光标位置。
  let dragRafHandle = 0;
  let dragLastEvent = null;

  function scheduleDragFrame(e) {
    dragLastEvent = e;                 // 只保留最新事件，已排帧则直接返回
    ftKick();                          // 拖拽期间启动帧耗时探针（惰性，仅一次）
    if (dragRafHandle) return;
    dragRafHandle = requestAnimationFrame(dragFrame);
  }

  // 每渲染帧至多执行一次：模式切换 + 按 mode 分派（sort=面板内排序 / move=拖出归类）
  function dragFrame() {
    dragRafHandle = 0;
    const ev = dragLastEvent;
    dragLastEvent = null;
    if (!ev || !itemDrag || !itemDrag.active) return;   // 拖拽已结束/未激活 → 丢弃过期事件
    // ★ 动态切换（用最新坐标判定）：拖出面板 → 归类；拖回面板 → 排序（快照保留，Esc 仍恢复按下前顺序）
    const inP = inPanel(ev.clientX, ev.clientY);
    if (inP && itemDrag.mode !== 'sort') {
      stopSortVisual();
      clearDropTargets(); itemDrag.targetId = null;
      itemDrag.mode = 'sort';
      if (!itemDrag.order) itemDrag.order = snapshotPanelOrder();
      document.body.classList.add('dragging-item');
      if (itemDrag.srcEl) itemDrag.srcEl.classList.add('dragging');
    } else if (!inP && itemDrag.mode === 'sort') {
      itemDrag.mode = 'move';
      startMoveVisual();
    }
    if (itemDrag.mode === 'sort') movePanelSort(ev);
    else moveGhostFrame(ev);
  }

  // move 模式每帧处理：ghost 用 transform 定位（纯合成，不触发 layout）；
  // 落点命中每帧一次 elementFromPoint（此时无未应用的样式写入，不再强制布局）；
  // drop-target 类名只在目标变化时写一次。
  function moveGhostFrame(ev) {
    if (itemDrag.ghost) {
      itemDrag.ghost.style.transform =
        'translate(' + ev.clientX + 'px,' + ev.clientY + 'px) translate(-50%,-50%) scale(1.06)';
    }
    itemDrag.gotMoveSinceLeave = true;   // mouseleave 宽限期内又有移动 → 拖拽仍在进行
    const chip = chipAt(ev.clientX, ev.clientY);
    const id = chip && chip.dataset.id ? chip.dataset.id : null;
    if (id !== itemDrag.targetId) {
      clearDropTargets();
      if (id) chip.classList.add('drop-target');
      itemDrag.targetId = id;
    }
  }

  // 同步应用挂起帧（endPanelSort 提交前调用）：保证松手位置 = 光标最终位置，不丢最后一次移动
  function flushPendingDragFrame() {
    if (dragRafHandle) { cancelAnimationFrame(dragRafHandle); dragRafHandle = 0; }
    const ev = dragLastEvent;
    dragLastEvent = null;
    if (ev && itemDrag && itemDrag.active) {
      if (itemDrag.mode === 'sort') movePanelSort(ev);
      else moveGhostFrame(ev);
    }
  }

  // 丢弃挂起帧（Esc 取消 / 异常复位时调用）：过期坐标不再应用
  function dropPendingDragFrame() {
    if (dragRafHandle) { cancelAnimationFrame(dragRafHandle); dragRafHandle = 0; }
    dragLastEvent = null;
  }

  function movePanelSort(e) {
    // 注：合帧后本函数每渲染帧至多执行一次，dragperf 统计的是"DOM 写入速率"（≤60Hz），
    //     与之前"每事件一次（~125Hz）"的口径不同，对比历史基线时需注意。
    const t0 = performance.now();
    if (!dragPerf.n) dragPerf.last = 0;      // 每次拖拽从零计（否则跨拖拽会产生巨幅"间隔"假象）
    if (dragPerf.last) {
      const ivl = t0 - dragPerf.last;
      dragPerf.ivlSum += ivl;
      if (ivl > dragPerf.ivlMax) dragPerf.ivlMax = ivl;
    }
    dragPerf.last = t0;
    movePanelSortBody(e);
    const dt = performance.now() - t0;
    dragPerf.n++; dragPerf.sum += dt;
    if (dt > dragPerf.max) dragPerf.max = dt;
  }

  function movePanelSortBody(e) {
    // 被拖拽节点 = 源条目（无需每帧 querySelector('.dragging')）
    const drag = itemDrag.srcEl;
    if (!drag || !drag.isConnected) return;
    const body = el.panelBody;
    let all = itemDrag.nodes;            // ★ 缓存条目数组（DOM 顺序），免每帧重查
    let g = itemDrag.geom;
    if (!g || !all || g.scroll !== body.scrollTop) {
      all = [...body.querySelectorAll('.panel-item')];
      itemDrag.nodes = all;
      if (all.length <= 1) { clearPanelInsertMarkers(); return; }
      g = panelGeom();
      itemDrag.geom = g;
      if (!g) return;
    }
    if (all.length <= 1) { clearPanelInsertMarkers(); return; }

    // 槽位 = 行 × 列（纯算术，零布局读取）
    const rowsTotal = Math.max(1, Math.ceil(all.length / g.cols));
    let rowIdx = Math.floor((e.clientY - g.y0) / (g.h + g.gapY));
    rowIdx = Math.max(0, Math.min(rowIdx, rowsTotal - 1));
    let colIdx = Math.floor((e.clientX - g.x0) / (g.w + g.gapX));
    colIdx = Math.max(0, Math.min(colIdx, g.cols - 1));
    const slot = Math.min(rowIdx * g.cols + colIdx, all.length - 1);
    const anchorNode = all[slot];
    const slotTop = g.y0 + rowIdx * (g.h + g.gapY);
    const afterAnchor = e.clientY > slotTop + g.h / 2;   // 上半 = 插到其前、下半 = 插到其后
    const ref = afterAnchor ? anchorNode.nextElementSibling : anchorNode;

    // ★ 早退：插入锚未变且指示条已在位 → 本帧什么都不做
    if (itemDrag.lastRef === ref && drag.classList.contains('insert-after')) return;
    itemDrag.lastRef = ref;
    clearPanelInsertMarkers();
    if (ref !== drag) {
      body.insertBefore(drag, ref);
      // ★ 增量维护缓存数组顺序（与 insertBefore 等价），下一帧锚点判定不读 DOM
      const di = all.indexOf(drag);
      if (di >= 0) all.splice(di, 1);
      const ri = ref ? all.indexOf(ref) : all.length;
      all.splice(ri < 0 ? all.length : ri, 0, drag);
    }
    drag.classList.add('insert-after');
  }

  // 排序结束：commit=true 按面板 DOM 顺序重排源分类 items 并落盘（实时生效且保持）；
  // false（Esc）恢复按下前快照，不落盘。与 resetDrag/endChipDrag 同级的唯一出口收敛。
  function endPanelSort(reason, commit) {
    if (!itemDrag) return;
    // ★ 提交前先同步应用挂起的合帧（松手位置 = 光标最终位置）；取消路径直接丢弃
    if (commit) flushPendingDragFrame(); else dropPendingDragFrame();
    dragPerfReport(reason);
    const st = itemDrag;
    itemDrag = null;
    document.body.classList.remove('drag-ghost-active', 'dragging-item');
    if (st.srcEl) st.srcEl.classList.remove('dragging');
    if (st.srcCatEl) st.srcCatEl.classList.remove('drag-source');
    clearPanelInsertMarkers();
    clearDropTargets();
    if (!st.active) return;
    if (!commit) { restorePanelOrder(st.order); console.log('[panelsort] cancel', reason); return; }
    suppressClickUntil = Date.now() + 400;      // 排序后的 click 视为误触
    const cat = categories.find((c) => c.id === st.srcCatId);
    if (cat) {
      const order = [...el.panelBody.querySelectorAll('.panel-item')].map((n) => n.title);
      cat.items.sort((a, b) => {
        const ia = order.indexOf(a.path), ib = order.indexOf(b.path);
        return (ia < 0 ? 1e9 : ia) - (ib < 0 ? 1e9 : ib);
      });
      persist();
    }
    console.log('[panelsort] end', reason);
  }

  // 归类模式视觉的创建/拆除（面板内排序 ⇄ 拖出归类 动态切换共用）
  function startMoveVisual() {
    const g = document.createElement('div');
    g.className = 'drag-ghost';
    g.appendChild(makeIconEl(itemDrag.item));
    document.body.appendChild(g);
    itemDrag.ghost = g;
    document.body.classList.add('drag-ghost-active');
    document.body.classList.add('dragging-item');
    if (itemDrag.srcEl) itemDrag.srcEl.classList.add('dragging');
    if (itemDrag.srcCatEl) itemDrag.srcCatEl.classList.add('drag-source');
  }
  function stopSortVisual() {
    if (itemDrag.ghost) { itemDrag.ghost.remove(); itemDrag.ghost = null; }
    document.body.classList.remove('drag-ghost-active');
    clearPanelInsertMarkers();
  }

  document.addEventListener('mousemove', (e) => {
    lastPtrX = e.clientX; lastPtrY = e.clientY;   // ★ 全局光标跟踪（scheduleHide 过渡带豁免判定用）
    if (chipDrag) { moveChipDrag(e); return; }   // 芯片排序进行中（与条目拖拽互斥）
    if (!itemDrag) return;
    lastPtrX = e.clientX; lastPtrY = e.clientY;   // ★ 供 mouseleave 出口复核光标是否真在视口内
    // 自检：ghost 被外部移除（重渲染/异常）时立即复位，杜绝"卡住"
    if (itemDrag.active && itemDrag.ghost && !itemDrag.ghost.isConnected) {
      resetDrag('ghost-gone');
      return;
    }
    if (!itemDrag.active) {
      if (Math.hypot(e.clientX - itemDrag.sx, e.clientY - itemDrag.sy) < 6) return;
      itemDrag.active = true;                 // 超过阈值 → 进入拖拽
      clearTimeout(hideTimer);                // 拖拽期间不收起坞条/面板
      // ★ 初始模式：光标在面板内 = 排序；否则归类
      itemDrag.mode = inPanel(e.clientX, e.clientY) ? 'sort' : 'move';
      if (itemDrag.mode === 'sort') {
        itemDrag.order = snapshotPanelOrder();
        document.body.classList.add('dragging-item');
        if (itemDrag.srcEl) itemDrag.srcEl.classList.add('dragging');
      } else {
        startMoveVisual();
      }
    }
    // ★ 两种模式统一 rAF 合帧：激活/模式切换/命中判定/全部 DOM 写入都在帧回调里做
    //   （dragFrame 内部用最新坐标重判 inPanel，事件里不再重复判定）
    scheduleDragFrame(e);
  });

  // 主出口：左键松开
  document.addEventListener('mouseup', (e) => {
    if (chipDrag) { endChipDrag('mouseup', chipDrag.active && e.button === 0); return; }
    if (!itemDrag) return;
    if (e.button !== 0 && itemDrag.active) { resetDrag('rightbutton'); return; }
    if (itemDrag.mode === 'sort') { endPanelSort('mouseup', true); return; }   // ★ 排序提交落盘
    const chip = chipAt(e.clientX, e.clientY);   // 以松开位置为准
    if (chip && chip.dataset.id) itemDrag.targetId = chip.dataset.id;
    endItemDrag(true);
  });

  // 出口②：光标离开文档。
  // ★ 关键事实：WebView2 组合宿主下，鼠标在窗口内正常移动也会高频触发 document
  //   mouseleave/mouseenter 对（每次 SendMouseInput 移动都会重建 hover 链）。
  //   因此不能仅凭「220ms 内没有 mousemove」就判定离开——用户拖到目标芯片上
  //   停顿观察高亮再松手（>220ms）会被误复位，表现为「松手没反应、图标弹回」。
  //   修复：宽限期内无移动时，用最后光标坐标 elementFromPoint 复核——
  //   坐标仍在视口内且命中元素 → 光标没走，继续拖拽；越界/无命中 → 真离开，复位。
  let lastPtrX = -1, lastPtrY = -1;
  document.addEventListener('mouseleave', () => {
    // 芯片排序：同款 220ms 宽限复核（见下方 itemDrag 版注释）
    if (chipDrag && chipDrag.active) {
      setTimeout(() => {
        if (!chipDrag || !chipDrag.active) return;
        const inside = lastPtrX >= 0
          && lastPtrX < window.innerWidth && lastPtrY < window.innerHeight
          && !!document.elementFromPoint(lastPtrX, lastPtrY);
        if (!inside) endChipDrag('leave-timer', true);   // 已达成的顺序保留并落盘
      }, 220);
    }
    if (!itemDrag) return;
    setTimeout(() => {
      if (!itemDrag) return;
      if (itemDrag.gotMoveSinceLeave) { itemDrag.gotMoveSinceLeave = false; return; }
      const inside = lastPtrX >= 0
        && lastPtrX < window.innerWidth && lastPtrY < window.innerHeight
        && !!document.elementFromPoint(lastPtrX, lastPtrY);
      if (!inside) {
        if (itemDrag.mode === 'sort') endPanelSort('leave-timer', true);   // 已达成的顺序保留并落盘
        else resetDrag('leave-timer');
      }
    }, 220);
  });

  // 出口③：窗口失焦（Alt+Tab、点击其它程序、弹出系统对话框）
  window.addEventListener('blur', () => {
    if (chipDrag) endChipDrag('blur', true);
    if (itemDrag && itemDrag.mode === 'sort') endPanelSort('blur', true);
    else resetDrag('blur');
  });
  // 出口④：Esc 取消（面板排序恢复按下前顺序不落盘；归类复位）
  window.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (chipDrag) { endChipDrag('escape', false); return; }
    if (itemDrag && itemDrag.mode === 'sort') { endPanelSort('escape', false); return; }
    if (itemDrag) resetDrag('escape');
  });
  // 出口⑤：右键被按下（弹出右键菜单时不该同时处于拖拽态）
  window.addEventListener('contextmenu', () => {
    if (chipDrag && chipDrag.active) endChipDrag('contextmenu', true);
    if (itemDrag && itemDrag.mode === 'sort') endPanelSort('contextmenu', true);
    else if (itemDrag && itemDrag.active) resetDrag('contextmenu');
  });
  // 出口⑥：指针取消（触摸/笔）
  window.addEventListener('pointercancel', () => {
    if (chipDrag) endChipDrag('pointercancel', chipDrag.active);
    if (itemDrag && itemDrag.mode === 'sort') endPanelSort('pointercancel', true);
    else resetDrag('pointercancel');
  });

  function attachItemDropTarget(chip) {
    // 兜底：即便将来宿主接入了原生拖放转发，也阻止浏览器默认行为（不再依赖它完成归类）
    chip.addEventListener('dragover', (e) => { e.preventDefault(); });
  }

  // —— 拖拽排序 ——
  // 实时把被拖元素插到光标位置（即时反馈），松手时提交并持久化顺序
  let dragging = false;

  // —— ★ 分类芯片手动拖拽排序 ——
  // 不用 HTML5 DnD（原因同条目拖拽：组合宿主下 dragstart 永不触发）。
  // 交互：按住芯片移动超 6px → 排序态（.dragging 半透明 + 收浮层 + 禁 hover 面板）
  //       → mousemove 实时 afterElement/insertBefore → 松手 commitOrder() 落盘
  //       categories.json → 重启后顺序保持。
  // 出口与条目拖拽同款（防"卡住"）：mouseup / mouseleave 复核 / blur /
  // Esc（★取消：恢复按下前顺序，不落盘）/ contextmenu / pointercancel。
  let chipDrag = null;   // { el, sx, sy, active, order }

  function chipDragActive() { return !!(chipDrag && chipDrag.active); }

  // 按下时的 DOM 顺序快照（元素引用数组），Esc 取消时按此恢复
  function snapshotChipOrder() { return [...el.catList.querySelectorAll('.cat')]; }
  function restoreChipOrder(snap) { for (const n of snap) el.catList.appendChild(n); }

  // ★ 清除插入位置指示条（insert-before/insert-after，见 dock.css）
  function clearInsertMarkers() {
    el.catList.querySelectorAll('.cat.insert-before, .cat.insert-after')
      .forEach((n) => n.classList.remove('insert-before', 'insert-after'));
  }

  // 唯一复位入口。commit=true 保留当前 DOM 顺序并持久化；false 恢复快照原序（取消）。
  // active=false（还没超阈值就松手）只清状态，无副作用。
  function endChipDrag(reason, commit) {
    if (!chipDrag) return;
    const st = chipDrag;
    chipDrag = null;
    document.body.classList.remove('chip-sorting');
    st.el.classList.remove('dragging');
    clearInsertMarkers();                            // ★ 撤掉插入指示条
    if (!st.active) return;
    if (!commit) restoreChipOrder(st.order);
    else commitOrder();                              // DOM 顺序 → categories.json
    suppressClickUntil = Date.now() + 400;           // 排序后的 click 视为误触
    console.log('[chipdrag] end', reason, 'commit=' + !!commit);
  }

  function moveChipDrag(e) {
    if (!chipDrag.active) {
      if (Math.hypot(e.clientX - chipDrag.sx, e.clientY - chipDrag.sy) < 6) return;
      chipDrag.active = true;                        // 超阈值 → 进入排序态
      chipDrag.order = snapshotChipOrder();          // 此刻 DOM 尚未变 = 按下时顺序
      document.body.classList.add('chip-sorting');
      chipDrag.el.classList.add('dragging');
      clearTimeout(hideTimer);
      closeAll();                                    // 排序期间收起浮层
    }
    lastPtrX = e.clientX; lastPtrY = e.clientY;      // 供 mouseleave 出口复核
    const after = afterElement(e.clientX);           // 复用条目排序的插入位计算
    clearInsertMarkers();                            // ★ 每帧先撤旧指示再标新位置
    if (after == null) {
      if (el.catList.lastElementChild !== chipDrag.el) el.catList.appendChild(chipDrag.el);
      // ★ 放到最右端：指示条标在最后一个非拖拽芯片的右缘
      const rest = el.catList.querySelectorAll('.cat:not(.dragging)');
      if (rest.length) rest[rest.length - 1].classList.add('insert-after');
    } else {
      el.catList.insertBefore(chipDrag.el, after);
      after.classList.add('insert-before');          // ★ 左缘竖条 = 将插到该芯片前面
    }
  }


  function attachDrag(node) {
    node.addEventListener('dragstart', (e) => {
      dragging = true;
      node.classList.add('dragging');
      clearTimeout(hideTimer);
      closeAll();
      try {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', node.dataset.id);
      } catch { /* ignore */ }
    });
    node.addEventListener('dragend', () => {
      dragging = false;
      node.classList.remove('dragging');
      commitOrder();
    });
  }

  // 返回「水平中点位于光标右侧」的第一个图标（即插入位置）
  function afterElement(x) {
    const nodes = [...el.catList.querySelectorAll('.cat:not(.dragging)')];
    let closest = null;
    let closestD = -Infinity;
    for (const n of nodes) {
      const r = n.getBoundingClientRect();
      const d = x - (r.left + r.width / 2);
      if (d < 0 && d > closestD) { closestD = d; closest = n; }
    }
    return closest;
  }

  el.catList.addEventListener('dragover', (e) => {
    if (!dragging) return;
    e.preventDefault();
    try { e.dataTransfer.dropEffect = 'move'; } catch { /* ignore */ }
    const src = el.catList.querySelector('.cat.dragging');
    if (!src) return;
    const after = afterElement(e.clientX);
    if (after == null) {
      if (el.catList.lastElementChild !== src) el.catList.appendChild(src);
    } else if (after !== src) {
      el.catList.insertBefore(src, after);
    }
  });
  el.catList.addEventListener('drop', (e) => { if (dragging) e.preventDefault(); });

  function commitOrder() {
    const order = [...el.catList.querySelectorAll('.cat')].map((n) => n.dataset.id);
    if (!order.length) return;
    const map = new Map(categories.map((c) => [c.id, c]));
    const next = order.map((id) => map.get(id)).filter(Boolean);
    for (const c of categories) if (!order.includes(c.id)) next.push(c);   // 兜底，避免丢分类
    categories = next;
    persist();
  }

  function openPanel(cat, anchor) {
    // ★ 菜单互斥：分类面板展开时收起设置面板与搜索条（同一时间只留一个浮层）
    if (window.Settings) window.Settings.close();
    if (window.Search) window.Search.close();
    // ★ 09-27 补漏：右键菜单也要一并收起——芯片右键菜单开着时把鼠标移到另一个分类芯片上，
    //   该分类面板会展开；此时旧菜单必须消失，界面上只留新展开的面板（用户报的交互缺陷）。
    //   放在 openPanel 里而非 mouseenter：任何入口展开面板都保证同时只有一个浮层。
    if (window.Menu) window.Menu.close();
    panelCatId = cat.id;
    el.panel.hidden = false;
    el.panelBody.innerHTML = '';
    if (!cat.items.length) {
      el.panelBody.innerHTML = '<div class="panel-empty">该分类暂无图标</div>';
    } else {
      for (const item of cat.items) {
        const d = document.createElement('div');
        d.className = 'panel-item';
        // ★ 不设 draggable=true（原因同分类芯片）：draggable 会让 Chromium 在移动超阈值时
        //   pointercancel 并吞掉 mousemove/mouseup → 条目拖拽归类（手动鼠标实现）无法工作
        d.appendChild(makeIconEl(item));   // ★ 图标元素（自带失败兜底）
        d.insertAdjacentHTML('beforeend',
          `<span class="nm">${escapeHtml(dispName(item))}</span>`
          + `<div class="mv" title="移动到其它分类">⇄</div>`);
        d.title = item.path;
        d.addEventListener('click', () => {
          // 拖拽刚结束时不触发启动（避免"拖到别处"被误判成点击）
          if (Date.now() < suppressClickUntil) return;
          launch(item);
        });
        // ★ 按住即准备拖拽（阈值 6px 后才真正进入拖拽，不影响单击启动）
        d.addEventListener('mousedown', (e) => {
          if (e.button !== 0) { resetDrag('nonleft-down'); return; }   // 非左键：确保清掉可能残留的拖拽态
          // 拖拽中若已有未复位状态，先复位再重新开始（避免叠影）
          if (itemDrag) resetDrag('restart');
          itemDrag = {
            item,
            srcEl: d,
            srcCatEl: el.catList.querySelector(`.cat[data-id="${cat.id}"]`),
            srcCatId: cat.id,
            sx: e.clientX,
            sy: e.clientY,
            active: false,
            ghost: null,
            targetId: null,
            gotMoveSinceLeave: false,
            mode: null,     // ★ 'sort'（面板内排序）| 'move'（拖出到芯片归类）——激活时按光标位置判定，拖动中可切换
            order: null,    // ★ 排序模式 DOM 快照（Esc 取消恢复用）
          };
        });
        // ★ 右键：条目菜单（打开/管理员运行/定位/属性/重命名/移动/删除/取消手动归类）
        // ★ v1.13.10 面板保持展开：右键图标时下拉面板不得关闭 ——
        //   自动隐藏保持域由 DEBUG_JS 的「所有浮层包围盒并集」（面板 ∪ 菜单 ∪ 二级浮层）保证，
        //   面板侧 scheduleHide 也有 Menu.isOpen 守卫，菜单与面板互不挤掉
        d.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (dragActive()) resetDrag('item-ctx');
          clearTimeout(hideTimer);
          if (window.Menu) window.Menu.open({ kind: 'item', item, cat }, e.clientX, e.clientY);
        });
        d.querySelector('.mv').addEventListener('click', (e) => {
          e.stopPropagation();
          if (window.Cats && window.Cats.openMoveMenu) window.Cats.openMoveMenu(item, e.currentTarget);
        });
        el.panelBody.appendChild(d);
      }
    }
    // 定位：面板中心对齐分类图标（防止溢出屏幕）；滚轮调列数后复用
    applyPanelCols(panelCols);              // ★ 重开面板时同步当前列数（右键菜单/滚轮设置保持）
    positionPanel(anchor);
    setOpenAnchor(anchor);                  // ★ 源芯片保持悬停效果
    reportShape(true);
  }

  function positionPanel(anchor) {
    const aR = anchor.getBoundingClientRect();
    const pw = Math.min(el.panel.offsetWidth || 400, window.innerWidth - 20);
    let x = aR.left + aR.width / 2 - pw / 2;
    x = Math.max(10, Math.min(x, window.innerWidth - pw - 10));
    el.panel.style.left = x + 'px';
    el.panel.style.right = 'auto';
  }

  // —— ★ 滚轮调节面板列数（悬停面板滚动：向上 +1 列最多 4，向下 -1 列最少 2，默认 3）——
  // preventDefault 完全接管滚轮：#panel-body 内容滚动与页面默认滚动都不会被触发，
  // 内容超高时用面板自带滚动条查看。列数会话内保持（不随面板关闭重置）。
  const PANEL_COLS_MIN = 2, PANEL_COLS_MAX = 4;
  let panelCols = 3;
  // ★ 各列数的设计列宽下限：2 列 110px（用户反馈滚动条出现时 104 偏窄 → 适当加宽）
  const PANEL_COL_W = { 2: 110, 3: 104, 4: 104 };
  // 面板总宽 = 左右边框 2 + padding 24 + n×列宽 + (n-1)×4 gap + 6 滚动条槽位预留
  //（配合 panel.css scrollbar-gutter: stable —— 列宽恒等于下限，不随滚动条出现/消失跳变）
  const panelWidthFor = (n) => 26 + n * PANEL_COL_W[n] + (n - 1) * 4 + 6;

  function applyPanelCols(n) {
    panelCols = Math.max(PANEL_COLS_MIN, Math.min(PANEL_COLS_MAX, n));
    if (itemDrag) itemDrag.geom = null;      // ★ 列数变化 → 拖拽用的槽位几何缓存失效
    el.panel.style.width = panelWidthFor(panelCols) + 'px';
    const cw = PANEL_COL_W[panelCols] || 104;
    el.panelBody.style.gridTemplateColumns = `repeat(${panelCols}, minmax(${cw}px, 1fr))`;
    // ★ 2 列模式挂紧凑类：条目高度压缩使 14 项 7 行 ≤ 面板 max-height，不出纵向滚动条
    el.panelBody.classList.toggle('cols-2', panelCols === 2);
    // 宽度变化后重新中心对齐当前分类芯片（防偏移/出屏），并上报新形状（窗口裁剪跟随）
    const cat = categories.find((c) => c.id === panelCatId);
    const anchor = cat ? el.catList.querySelector(`.cat[data-id="${cat.id}"]`) : null;
    if (anchor) positionPanel(anchor);
    reportShape();
  }

  el.panel.addEventListener('wheel', (e) => {
    // ★ 仅 Ctrl+滚轮调列数：普通滚轮放行给默认行为（面板内容滚动），
    //   Ctrl+滚轮的浏览器默认缩放被 preventDefault 吞掉
    if (!e.ctrlKey || !e.deltaY) return;
    e.preventDefault();
    e.stopPropagation();
    applyPanelCols(panelCols + (e.deltaY < 0 ? 1 : -1));
  }, { passive: false });

  // 供右键菜单（menu.js 分类菜单「面板列数」组）读写当前列数
  function setPanelCols(n) { applyPanelCols(Math.max(PANEL_COLS_MIN, Math.min(PANEL_COLS_MAX, n | 0))); }
  function getPanelCols() { return panelCols; }

  // ★ 悬停连续性：面板展开期间源芯片挂 .open（与 :hover 同效果）——
  //   鼠标从芯片移入面板时芯片提示效果不消失；收起/切换时移除
  let openAnchorEl = null;
  function setOpenAnchor(a) {
    if (openAnchorEl && openAnchorEl !== a) openAnchorEl.classList.remove('open');
    openAnchorEl = a || null;
    if (openAnchorEl) openAnchorEl.classList.add('open');
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      if (dragActive()) return;                  // ★ 拖拽归类进行中：不收起面板
      if (window.Menu && window.Menu.isOpen()) return;   // 右键菜单开着时不收起
      if (el.panel.matches(':hover')) return;
      // ★ 过渡带豁免：光标在「面板顶与坞条之间」约 20px 间隙内移动时不收起，
      //   防止慢速穿过间隙被 260ms 定时器掐断（面板闪烁）
      const r = el.panel.getBoundingClientRect();
      const inGap = lastPtrX >= 0
        && lastPtrY >= r.top - 20 && lastPtrY < r.top
        && lastPtrX >= r.left - 6 && lastPtrX <= r.right + 6;
      if (inGap) return;
      el.panel.hidden = true;
      panelCatId = null;
      setOpenAnchor(null);
      reportShape(false);
    }, 260);
  }

  el.panel.addEventListener('mouseenter', () => clearTimeout(hideTimer));
  el.panel.addEventListener('mouseleave', scheduleHide);

  // ★ v1.13.7：点击启动不再先行收起面板/坞条 ——
  //   启动成功由原生 HIDE_NOW 收起（原本就是同一通道）；
  //   启动失败（文件不存在）时面板保持打开，原生回发 launch-failed → 弹「是否删除失效图标」确认框
  async function launch(item) {
    await window.desknest.launch({ path: item.path, srcLnk: item.srcLnk, target: item.target, type: item.type });
  }

  // 供右键菜单「打开」调用（不依赖面板是否可见）
  async function launchItem(item) {
    if (window.Menu) window.Menu.close();
    await window.desknest.launch({ path: item.path, srcLnk: item.srcLnk, target: item.target, type: item.type });
  }

  // ★ v1.13.7 功能③：删除图标（仅从分类移除，不动电脑上的文件）
  // ★ v1.31：按「分类内实例」定位——同名快捷方式可同时存在于多个分类，
  // 旧实现全局找第一个匹配，会把别的分类里的同名条目误删（用户实测踩中：
  // 办公+社交通讯各一份，删社交通讯却删掉了办公的）
  function removeItem(catId, path) {
    const c = categories.find((x) => x.id === catId) ||
              categories.find((x) => x.items.some((it) => it.path === path));
    if (!c) return;
    const idx = c.items.findIndex((it) => it.path === path);
    if (idx >= 0) {
      c.items.splice(idx, 1);
      // ★ v1.32.4 删除语义修复：删除 ≠ 移动。桌面文件实体仍在时，原生的
      //   「桌面新文件监控」会把它当漏检新文件重新补入「其他」分类（表现为
      //   删除后 5 秒内图标又在「其他」里出现）。此处上报原生记入
      //   removed.json 忽略清单，监控 diff 据此排除；重扫/该文件重新收录时自动失效。
      try { window.chrome.webview.postMessage('item-removed ' + path); } catch (e) { /* ignore */ }
      return persist();
    }
  }

  // ★ v1.13.7 功能①：失效文件提示 —— 原生启动回退链全部落空时回发 launch-failed，
  //   在此弹确认框：告知文件不存在，确认后从分类中移除该失效图标
  // ★ 隐藏桌面期间的新文件：原生检测后转交页面，加入「其他」分类
  //   （桌面保持隐藏；用户在坞条「其他」里即可看到并打开新文件）
  window.__onDesktopNewFiles = (items) => {
    if (!Array.isArray(items) || !items.length) return;
    try {
      // ★ 防重复：路径已收录于任意分类的一律跳过
      const known = new Set();
      for (const c of window.Dock.getCats()) {
        for (const it of (c.items || [])) known.add(it.path);
      }
      items = items.filter((it) => it && it.path && !known.has(it.path));
      if (!items.length) return;
      // ★ v1.33.10：原生已给出每个新文件的自动分类结果（it.cat），按分类分别插入；
      //   auto=true → 不标 manual，后续「重扫」仍可按规则重新归类
      const byCat = new Map();
      for (const it of items) {
        const cid = it.cat || 'uncategorized';
        if (!byCat.has(cid)) byCat.set(cid, []);
        byCat.get(cid).push(it);
      }
      let total = 0;
      for (const [cid, arr] of byCat) {
        const target = (window.Dock.getCats() || []).some((c) => c.id === cid) ? cid : 'uncategorized';
        total += window.Dock.addItems(target, arr, { auto: true }) || arr.length;
      }
      if (window.Menu && window.Menu.notice) {
        const names = items.slice(0, 3).map((it) => dispName(it)).join('、');
        window.Menu.notice(
          `检测到桌面新文件（${total} 个）${names ? '：' + names : ''}\n已按类型自动归入对应分类`
        );
      }
    } catch (e) { /* ignore */ }
  };

  window.__onLaunchFailed = (path) => {
    const found = findInCategories((it) => it.path === path);
    if (!found || !window.Menu || !window.Menu.ask) return;
    window.Menu.ask(
      '文件不存在',
      `「${dispName(found.item)}」对应的文件已被删除或移动。\n是否删除该图标？`,
      '删除图标',
      () => removeItem(found.cat.id, path)
    );
  };

  // ★ v1.32.8「删除并移入回收站」回执：成功 → 从分类移除图标；失败 → 弹提示
  window.__onFileDeleted = (ok, errMsg, path) => {
    if (!ok) {
      if (window.Menu && window.Menu.notice) {
        window.Menu.notice(`删除失败：${errMsg || '未知错误'}`);
      }
      return;
    }
    const found = findInCategories((it) => it.path === path);
    if (found) removeItem(found.cat.id, path);
  };

  // —— ★ 回收站虚拟条目（v1.13.11，原生注入于「其他」分类）——
  // 原生 10s 轮询 + 呼出坞条强制查；状态变化推送 full|empty → 条目自带的两态 data URL
  // （rbIconFull/rbIconEmpty，系统 shell32 图标内嵌）切换名称与图标，persist 落盘
  const RB_PATH = '::{645FF040-5081-101B-9F08-00AA002F954E}';
  window.__onRecycleBin = (state) => {
    const found = findInCategories((it) => it.path === RB_PATH);
    if (!found) return;
    const it = found.item;
    const name = state === 'full' ? '回收站(满)' : '回收站(空)';
    const url = (state === 'full' ? it.rbIconFull : it.rbIconEmpty) || ('recyclebin://' + state);
    if (it.iconFile === url && it.name === name) return;
    it.name = name;
    it.iconSource = url;
    it.iconFile = url;
    persist();                                  // renderCats 随 persist 一并刷新
    console.log('[recyclebin] 状态 →', name);
  };

  // ★ v1.15.6 清空回收站回执：成功 → 即时刷新为空态图标/文字 + 提示；失败 → 错误提示
  window.__onRecycleBinEmptied = (ok, msg) => {
    if (!window.Menu || !window.Menu.notice) return;
    if (ok) {
      window.__onRecycleBin('empty');           // 图标/文字即时切换（轮询推送随后为幂等）
      window.Menu.notice('清空完成', '回收站已清空。');
    } else {
      window.Menu.notice('清空失败', `清空回收站时出错（${msg || '未知错误'}）。`);
    }
  };

  // 程序化打开某分类的面板（09-27 起右键菜单不再提供入口——悬停/点击芯片本身即展开，
  // 保留为 Dock API 供其它入口调用）
  function openCatPanel(catId) {
    const cat = categories.find((c) => c.id === catId);
    const anchor = el.catList.querySelector(`.cat[data-id="${catId}"]`);
    if (cat && anchor) openPanel(cat, anchor);
  }

  // ★ 新增快捷方式：向指定分类添加手动条目（URL 或本地路径）
  // ★ opts.auto = true 表示「系统自动发现加入」（如桌面新文件监控），而非用户手动归类：
  //   这类条目不写 manual —— 否则重扫时会被当成"用户手动选择"永远留在「其他」，
  //   表现为「新建文件后点重扫仍不归类」（用户报的问题①）。用户拖放/新增快捷方式
  //   仍为 manual=true，保留用户选择不被自动规则改动。
  function addItems(catId, items, opts) {
    const cat = categories.find((c) => c.id === catId);
    if (!cat) return 0;
    const auto = !!(opts && opts.auto);
    let added = 0;
    for (const f of items) {
      if (!f || !f.path) continue;
      const isUrl = /^[a-z]+:\/\//i.test(String(f.path)) || /^www\./i.test(String(f.path));
      const item = {
        name: f.name || f.path,
        path: f.path,
        srcLnk: isUrl ? null : f.path,
        target: null,
        iconSource: isUrl ? null : f.path,
        iconFile: isUrl ? null : f.path,   // URL 条目无本地图标 → 占位图标
        iconIndex: 0,
        args: '',
        type: isUrl ? 'url' : (/\.lnk$/i.test(String(f.path)) ? 'lnk' : 'file'),
        mtimeMs: Date.now(),
        manual: !auto,                       // 自动发现的条目可被重扫重新归类
      };
      if (auto) item.auto = true;
      cat.items.push(item);
      added++;
    }
    if (added) {
      persist();
      renderCats();
      if (items.some((f) => f && f.path && !/^[a-z]+:\/\//i.test(String(f.path)) && !/^www\./i.test(String(f.path)))) {
        try { window.chrome.webview.postMessage('extract-icons'); } catch (e) { /* ignore */ }
      }
    }
    return added;
  }

  function closeAll() {
    el.panel.hidden = true;
    panelCatId = null;
    setOpenAnchor(null);                    // ★ 收起时移除源芯片悬停保持
    if (window.Cats) window.Cats.closeMoveMenu();
    reportShape(false);
  }

  // 面板展开/收起后上报形状（面板有 160ms 缩放动画，动画结束后由 DeskUI 重测一次）
  function reportShape() {
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(220);
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function setCategories(cats) {
    // 容错：兼容 {version, categories:[...]} 与数组两种形态，避免渲染层崩溃
    let list = cats;
    if (!Array.isArray(list) && list && Array.isArray(list.categories)) list = list.categories;
    categories = Array.isArray(list) ? list : [];
    try {
      renderCats();
    } catch (err) {
      console.error('renderCats failed:', err);
    }
  }

  // 重扫/刷新后：把用户重命名覆盖表重新套用（渲染层按 path 查表，无需改数据）
  function syncRenames(map) {
    if (map) renameMap = Object.assign({}, map);
    else if (window.__RENAME) renameMap = Object.assign({}, window.__RENAME);
  }

  // —— 分类编辑（供 cats.js 调用）——
  async function persist() {
    try { await window.desknest.saveCategories(categories); } catch { /* ignore */ }
    renderCats();
    if (window.Cats && window.Cats.render) window.Cats.render();
    reportShape();
  }

  function upsertCategory(cat) {
    const i = categories.findIndex((c) => c.id === cat.id);
    if (i >= 0) {
      categories[i] = { ...categories[i], ...cat };   // 编辑：保留用户拖拽出的顺序
    } else {
      categories.push({ items: [], ...cat });         // 新建：默认追加在末尾（未分类之前）
      const inboxIdx = categories.findIndex((c) => c.id === 'uncategorized');
      const lastIdx = categories.length - 1;
      if (inboxIdx >= 0 && inboxIdx !== lastIdx) {
        const [inbox] = categories.splice(inboxIdx, 1);
        categories.push(inbox);
      }
    }
    return persist();
  }

  function removeCategory(id) {
    const i = categories.findIndex((c) => c.id === id);
    if (i < 0) return;
    const [removed] = categories.splice(i, 1);
    const inbox = categories.find((c) => c.id === 'uncategorized');
    if (inbox && removed && removed.items && removed.items.length) inbox.items.push(...removed.items);
    return persist();
  }

  // ★ v1.31：从来源分类内定位条目（同名快捷方式多分类共存时不再误移别的分类）
  function moveItem(fromId, path, toId) {
    const src = categories.find((c) => c.id === fromId) ||
                categories.find((c) => c.items.some((it) => it.path === path));
    if (!src) return;
    const idx = src.items.findIndex((it) => it.path === path);
    if (idx < 0) return;
    const moved = src.items.splice(idx, 1)[0];
    // ★ 标记为「手动归类」：原生重扫/自动分类时不再覆盖用户的选择
    moved.manual = true;
    const target = categories.find((c) => c.id === toId);
    if (target) target.items.push(moved);
    return persist();
  }

  function findInCategories(predicate) {
    for (const c of categories) {
      for (const it of c.items) {
        if (predicate(it, c)) return { item: it, cat: c };
      }
    }
    return null;
  }

  // —— ★ 右键菜单支撑：新建分类并移入 ——
  function addCategoryWithItem(cat, item, fromCatId) {
    const inbox = categories.find((c) => c.id === 'uncategorized');
    let moved = null;
    const src = fromCatId ? categories.find((c) => c.id === fromCatId) : null;
    if (src) {
      const idx = src.items.findIndex((it) => it.path === item.path);
      if (idx >= 0) moved = src.items.splice(idx, 1)[0];
    } else {
      for (const c of categories) {
        const idx = c.items.findIndex((it) => it.path === item.path);
        if (idx >= 0) { moved = c.items.splice(idx, 1)[0]; break; }
      }
    }
    const target = { items: [], ...cat };
    if (moved) { moved.manual = true; target.items.push(moved); }
    // 插到「其他」之前，与 Dock.upsertCategory 的新建策略一致
    const inboxIdx = categories.findIndex((c) => c.id === 'uncategorized');
    if (inboxIdx >= 0) categories.splice(inboxIdx, 0, target);
    else categories.push(target);
    return persist();
  }

  // —— ★ 右键菜单支撑：取消手动归类（下次重扫重新按规则引擎归类）——
  // 顺序很重要：先 persist 把 manual:false 写进 categories.json，再发 rescan ——
  // 两条 WebMessage 顺序到达，原生按序处理，重扫读到的才是已撤标的数据。
  // 其它条目无需保护：手动项原生保留、非手动项规则重判结果确定不变。
  function clearManual(catId, path) {
    const found = (catId ? findInCategories((it) => it.path === path && it.cat.id === catId) : null) ||
                  findInCategories((it) => it.path === path);
    if (!found || !found.item.manual) return Promise.resolve();
    delete found.item.manual;
    return persist()
      .then(() => window.desknest.rescan())
      .then((cats) => {
        if (Array.isArray(cats) && cats.length) setCategories(cats);
        if (window.Menu) window.Menu.close();
      })
      .catch(() => {});
  }

  // —— ★ 右键菜单支撑：整理（排序）——
  //  'name'   按显示名自然序（数字段按数值比较，'10' 排在 '2' 之后）
  //  'type'   按类型分组：目录 → 快捷方式 → 文件，组内按名称
  //  'default' 恢复默认识别顺序（重扫一次，规则引擎的原始顺序）
  function naturalKey(s) {
    return String(s || '').toLowerCase().split(/(\d+)/).filter((x) => x !== '')
      .map((x) => (/^\d+$/.test(x) ? Number(x) : x));
  }
  function cmpNatural(a, b) {
    const ka = naturalKey(a), kb = naturalKey(b);
    for (let i = 0; i < Math.max(ka.length, kb.length); i++) {
      const x = ka[i], y = kb[i];
      if (x === undefined) return -1;
      if (y === undefined) return 1;
      if (typeof x === 'number' && typeof y === 'number') { if (x !== y) return x - y; }
      else {
        const sx = String(x), sy = String(y);
        if (sx !== sy) return sx < sy ? -1 : 1;
      }
    }
    return 0;
  }
  function typeRank(it) {
    if (it.type === 'dir') return 0;
    if (it.type === 'lnk') return 1;
    return 2;
  }
  function sortCategory(catId, mode) {
    if (mode === 'default') return window.desknest.rescan().then((cats) => {
      if (Array.isArray(cats) && cats.length) setCategories(cats);
    }).catch(() => {});
    const cat = categories.find((c) => c.id === catId);
    if (!cat || cat.items.length < 2) return Promise.resolve();
    const arr = cat.items.slice();
    if (mode === 'type') {
      arr.sort((a, b) => (typeRank(a) - typeRank(b)) || cmpNatural(dispName(a), dispName(b)));
    } else {
      arr.sort((a, b) => cmpNatural(dispName(a), dispName(b)));
    }
    cat.items = arr;
    // 排序是一种用户意图 → 打 manual 标记，避免下次重扫被打回原序
    for (const it of cat.items) it.manual = true;
    if (window.Menu) window.Menu.close();
    return persist();
  }
  function sortAll(mode) {
    for (const cat of categories) {
      if (mode === 'type') {
        cat.items.sort((a, b) => (typeRank(a) - typeRank(b)) || cmpNatural(dispName(a), dispName(b)));
      } else {
        cat.items.sort((a, b) => cmpNatural(dispName(a), dispName(b)));
      }
      for (const it of cat.items) it.manual = true;
    }
    if (window.Menu) window.Menu.close();
    return persist();
  }

  // —— ★ 右键菜单支撑：分类左右移动 ——
  function moveCategory(catId, delta) {
    const i = categories.findIndex((c) => c.id === catId);
    const j = i + delta;
    if (i < 0 || j < 0 || j >= categories.length) return Promise.resolve();
    const [c] = categories.splice(i, 1);
    categories.splice(j, 0, c);
    if (window.Menu) window.Menu.close();
    return persist();
  }

  // —— ★ 坞条空白处右键：重扫 / 整理 / 设置 / 分类管理 / 隐藏 / 退出 ——
  //   只在「没点到分类芯片 / 搜索 / 设置按钮」时触发；空白判定靠 closest 排除。
  const dockEl = document.getElementById('dock');
  if (dockEl) {
    dockEl.addEventListener('contextmenu', (e) => {
      // ★ 搜索/设置按钮：无右键功能 → 吞掉事件，不许浏览器默认菜单泄漏
      //   （旧代码裸 return，WebView2 里默认菜单会在这两个按钮上弹出）
      if (e.target.closest && (e.target.closest('#search-btn') || e.target.closest('#bm-btn') || e.target.closest('#settings-btn'))) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (e.target.closest && e.target.closest('.cat')) return;   // 芯片有自己的 contextmenu 处理器
      e.preventDefault();
      e.stopPropagation();
      if (dragActive()) resetDrag('dock-ctx');
      clearTimeout(hideTimer);
      closeAll();
      if (window.Menu) window.Menu.open({ kind: 'dock' }, e.clientX, e.clientY);
    });
  }

  // ★ 重扫回传兜底：settings.js 的重扫请求若超时（返回 null），原生的迟到回传
  //   会经 ipc-stub 的 __onCatsRefresh 到达这里 —— 数据其实已生成，照常刷新界面
  window.__onCatsRefresh = (cats) => {
    if (Array.isArray(cats) && cats.length) {
      setCategories(cats);
      syncRenames();
      applyRenames();
      console.log('[rescan] late categories applied:', cats.reduce((a, c) => a + (c.items || []).length, 0), 'items');
    }
  };

  // —— ★ OS 级拖放归类（v1.12.9 功能②，原生 IDropTarget 转发）——
  // 资源管理器/程序列表拖出的文件：原生 DragEnter/Over → "os-dragover x y"（芯片高亮）；
  // Drop → "os-drop x y <[{name,path,target,isDir}]>"（已解析 .lnk 目标）→ 按落点芯片归类落盘。
  let osDragChip = null;

  function osDragOver(x, y) {
    const chip = chipAt(x, y);
    if (chip === osDragChip) return;                 // 目标未变早退（原生已 40ms 节流）
    clearDropTargets();
    osDragChip = chip;
    if (chip) chip.classList.add('drop-target');
  }

  function osDragLeave() {
    if (osDragChip) {
      clearDropTargets();
      osDragChip = null;
    }
  }

  function osDrop(x, y, items) {
    osDragLeave();
    const chip = chipAt(x, y);
    const catId = chip && chip.dataset.id ? chip.dataset.id : null;
    if (!catId) {
      console.log('[osdrop] 落点不在任何分类芯片上，忽略', JSON.stringify({ x, y }));
      return;
    }
    const cat = categories.find((c) => c.id === catId);
    if (!cat) return;
    let added = 0, moved = 0, skipped = 0;
    for (const f of (Array.isArray(items) ? items : [])) {
      if (!f || !f.path) { skipped++; continue; }
      // 已在坞中的条目（重复拖放）：等价于移动到目标分类
      const existing = findInCategories((it) => it.path === f.path);
      if (existing) {
        if (existing.cat.id !== catId) { moveItem(existing.cat.id, f.path, catId); moved++; }
        else skipped++;
        continue;
      }
      const isLnk = /\.lnk$/i.test(String(f.path));
      cat.items.push({
        name: f.name || f.path,
        path: f.path,
        srcLnk: f.path,
        target: f.target || null,              // ★ 持久化 .lnk 解析目标：删桌面快捷方式后仍可启动
        iconSource: f.path,
        iconFile: f.path,                      // 图标由原生 extract-icons 补提取后经 desknest-icon:// 提供
        iconIndex: 0,
        args: '',
        type: f.isDir ? 'dir' : (isLnk ? 'lnk' : 'file'),
        mtimeMs: Date.now(),
        manual: true,                          // 手动归类：重扫不覆盖、不因文件暂时缺席被误清
      });
      added++;
    }
    if (added || moved) {
      persist();
      if (added) {
        try { window.chrome.webview.postMessage('extract-icons'); } catch (e) { /* ignore */ }
      }
      console.log('[osdrop]', JSON.stringify({ cat: catId, added, moved, skipped }));
    }
  }

  // 原生拖放事件 → 处理器（经 ipc-stub 的 message 监听转发）
  window.__onOsDragOver = (x, y) => osDragOver(x, y);
  window.__onOsDragLeave = () => osDragLeave();
  window.__onOsDrop = (x, y, items) => osDrop(x, y, items);

  return {
    setCategories, findInCategories, closeAll, addItems, iconSrc, makeIconEl, makePhIcon, dispName,
    applyRenames, syncRenames, resetDrag, launchItem, openCatPanel,
    addCategoryWithItem, clearManual, sortCategory, sortAll, moveCategory, dragActive, dragLog: () => lastDrag,
    CAT_ICONS, ICON_KEYS, PALETTE, catIconSvg,
    getCats: () => categories, persist, upsertCategory, removeCategory, removeItem, moveItem,
    setPanelCols, getPanelCols
  };
})();
