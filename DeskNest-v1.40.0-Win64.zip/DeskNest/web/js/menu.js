// menu.js：桌面坞右键菜单
//
// 为什么自绘而不用系统菜单：
//   本壳是 WS_EX_NOREDIRECTIONBITMAP + WS_POPUP 的组合宿主窗口，窗口形状由原生
//   按页面上报的矩形组裁剪。系统原生菜单是独立顶层窗口，既不受我们的形状裁剪管理，
//   也不会在光标离开坞区时随坞条一起收起 —— 会出现「菜单留在屏幕上无法归位」的观感。
//   自绘菜单走同一套 FLOAT_IDS 形状上报，与面板/设置条行为完全一致。
//
// 菜单内容按上下文（context）分三类：
//   'item'  面板里的某个图标 → 打开 / 管理员运行 / 定位 / 属性 / 重命名 / 移动 / 取消手动归类
//   'cat'   坞上的某个分类芯片 → 打开该分类 / 整理排序 / 重命名分类 / 分类管理
//   'dock'  坞条空白处        → 重扫桌面 / 整理 / 设置 / 分类管理 / 隐藏 / 退出
'use strict';

window.Menu = (() => {
  const el = document.getElementById('ctx-menu');

  // 内置菜单图标（单色 currentColor，与 dock.js 的 CAT_ICONS 同风格）
  const MI = {
    play: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4.8v14.4l12-7.2z"/></svg>',
    shield: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.2 5 6v5.5c0 4.3 2.9 8.1 7 9.3 4.1-1.2 7-5 7-9.3V6z"/><path d="M12 8.4v4.2M12 15.4h.01"/></svg>',
    folder: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 6.5a1.5 1.5 0 0 1 1.5-1.5h4l2 2.5h7.5a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5z"/></svg>',
    info: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8h.01"/></svg>',
    pencil: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4l10-10-4-4L4 16z"/><path d="M14.5 5.5 18.5 9.5"/></svg>',
    move: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5v17M3.5 12h17M12 3.5 9.5 6M12 3.5 14.5 6M12 20.5 9.5 18M12 20.5l2.5-2.5M3.5 12 6 9.5M3.5 12 6 14.5M20.5 12 18 9.5M20.5 12 18 14.5"/></svg>',
    plus: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M12 5.5v13M5.5 12h13"/></svg>',
    undo: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h9.5a5.5 5.5 0 0 1 0 11H8"/><path d="M7 5.5 3.5 9 7 12.5"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11.5a8 8 0 1 0-.9 4.6"/><path d="M20 4.5v6h-6"/></svg>',
    sort: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h11M4 12h8M4 17h5"/><path d="M17.5 14.5v6M17.5 20.5 15 18M17.5 20.5 20 18"/></svg>',
    grid: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><rect x="4" y="4" width="6.5" height="6.5" rx="1.4"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.4"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.4"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.4"/></svg>',
    gear: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="3.1"/><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1"/></svg>',
    eye: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M2.8 12S6 5.8 12 5.8 21.2 12 21.2 12 18 18.2 12 18.2 2.8 12 2.8 12z"/><circle cx="12" cy="12" r="2.6"/></svg>',
    power: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 3.5v8"/><path d="M6.7 6.9a7.6 7.6 0 1 0 10.6 0"/></svg>',
    trash: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6.5h16M9.5 6.5V4.8a1.3 1.3 0 0 1 1.3-1.3h2.4a1.3 1.3 0 0 1 1.3 1.3v1.7M6.5 6.5l1 12.2a1.6 1.6 0 0 0 1.6 1.5h5.8a1.6 1.6 0 0 0 1.6-1.5l1-12.2M10 10.5v6M14 10.5v6"/></svg>'
  };

  let openAt = null;        // 当前菜单上下文 { kind, ... }
  let subEl = null;         // 二级浮层（移动到分类）
  let renamePath = null;    // 正在重命名的条目 path
  let outsideBound = false;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // 显示名：原生自定义名（rename.json）优先，其次去掉 .lnk 的本名
  function itemLabel(item) {
    const custom = renames[item.path];
    if (custom) return custom;
    return window.Dock.dispName(item);
  }

  // —— 重命名覆盖表（%APPDATA%\DeskNest\rename.json，由原生注入 window.__RENAME）——
  let renames = Object.assign({}, window.__RENAME || {});
  function setRename(path, name) {
    const v = String(name || '').trim();
    // ★ 发给原生的必须是【补丁】：恢复原名时内存表已删项，但补丁里必须带 path → ""，
    //   否则原生 merge 收不到该条 → rename.json 旧值残留（重启后旧名复活）
    const payload = Object.assign({}, renames);
    if (v && v !== window.Dock.dispName({ name: baseName(path) })) {
      renames[path] = v;
      payload[path] = v;
    } else {
      delete renames[path];
      payload[path] = '';              // 空串 = 原生 remove 分支（恢复原名）
    }
    try { window.desknest.saveRenames(payload); } catch (e) { /* ignore */ }
    // 覆盖表变了 → 重建分类渲染（条目名、搜索、移动浮层都走 Dock.dispName）
    window.Dock.applyRenames(renames);
  }
  function baseName(p) {
    const s = String(p || '');
    const i = Math.max(s.lastIndexOf('\\'), s.lastIndexOf('/'));
    return i >= 0 ? s.slice(i + 1) : s;
  }

  // —— 菜单项构造 ——
  function mkItem(icon, label, opts) {
    const o = opts || {};
    const d = document.createElement('div');
    d.className = 'ci' + (o.disabled ? ' disabled' : '') + (o.danger ? ' danger' : '') + (o.on ? ' on' : '');
    d.innerHTML =
      `<span class="ico">${o.dot != null
        ? `<span class="sw" style="background:${o.dot}"></span>`
        : (MI[icon] || MI.info)}</span>` +
      `<span>${esc(label)}</span>` +
      (o.caret ? '<span class="arrow">▸</span>' : '') +
      (o.key ? `<span class="key">${esc(o.key)}</span>` : '');
    if (!o.disabled && o.run) {
      d.addEventListener('click', (e) => {
        e.stopPropagation();
        if (o.keepOpen) o.run(d);
        else { close(); o.run(d); }
      });
    }
    return d;
  }

  function mkSep() {
    const d = document.createElement('div');
    d.className = 'csep';
    return d;
  }

  function mkTitle(text) {
    const d = document.createElement('div');
    d.className = 'ctitle';
    d.textContent = text;
    d.title = text;
    return d;
  }

  // —— 菜单构建 ——
  function build() {
    el.innerHTML = '';
    const ctx = openAt;
    if (!ctx) return;

    if (ctx.kind === 'item') buildItem(ctx);
    else if (ctx.kind === 'cat') buildCat(ctx);
    else buildDock(ctx);
  }

  // 面板条目菜单
  function buildItem(ctx) {
    const { item, cat } = ctx;
    el.appendChild(mkTitle(itemLabel(item)));

    el.appendChild(mkItem('play', '打开', { key: 'Enter', run: () => window.Dock.launchItem(item) }));
    // ★ v1.15.6 回收站虚拟条目专属：清空回收站（查询项数 → 二次确认 → 原生清空）
    if (item.rb) {
      el.appendChild(mkItem('trash', '清空回收站', {
        danger: true,
        run: () => {
          // 原生回执 recyclebin-count <n> → 有项才弹确认，空则友好提示
          window.__onRecycleBinCount = (n) => {
            n = Number(n) || 0;
            if (n <= 0) {
              askConfirm('回收站已是空', '当前回收站没有可清空的项目。', '确定', null, true);
              return;
            }
            askConfirm(
              '清空回收站',
              `将永久删除回收站中的 ${n} 个项目，\n此操作不可恢复。`,
              '清空',
              () => { try { window.chrome.webview.postMessage('empty-recyclebin'); } catch (e) { /* ignore */ } }
            );
          };
          try { window.chrome.webview.postMessage('recyclebin-count'); } catch (e) { /* ignore */ }
        },
      }));
    }
    el.appendChild(mkItem('shield', '以管理员身份运行', { run: () => window.desknest.openAsAdmin(item.srcLnk || item.path) }));
    el.appendChild(mkSep());

    el.appendChild(mkItem('folder', '打开所在位置', { run: () => window.desknest.openPath(item.path) }));
    el.appendChild(mkItem('info', '属性', { key: 'Alt+Enter', run: () => window.desknest.showProperties(item.path) }));

    // 重命名：行内输入，避免弹原生 prompt（组合宿主下 prompt 会产生独立窗口）
    const re = mkItem('pencil', '重命名…', { keepOpen: true, run: (node) => {
      renamePath = item.path;
      node.classList.add('edit');
      node.innerHTML = `<span class="ico">${MI.pencil}</span>` +
        `<input type="text" value="${esc(itemLabel(item))}" spellcheck="false">`;
      const input = node.querySelector('input');
      input.focus();
      input.select();
      const commit = () => {
        const v = input.value;
        renamePath = null;
        close();
        setRename(item.path, v);
      };
      input.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter') commit();
        else if (e.key === 'Escape') { renamePath = null; close(); }
      });
      input.addEventListener('blur', () => { if (renamePath) commit(); });
      input.addEventListener('mousedown', (e) => e.stopPropagation());
    } });
    el.appendChild(re);

    // 移动到分类（二级菜单）
    const mv = mkItem('move', '移动到分类', { caret: true, keepOpen: true, run: (node) => openSub(node, item, cat.id) });
    el.appendChild(mv);

    // 新建分类并移入
    const nw = mkItem('plus', '新建分类并移入…', { keepOpen: true, run: (node) => {
      node.classList.add('edit');
      node.innerHTML = `<span class="ico">${MI.plus}</span><input type="text" placeholder="新分类名称" spellcheck="false">`;
      const input = node.querySelector('input');
      input.focus();
      const commit = () => {
        const v = input.value.trim();
        close();
        if (!v) return;
        // 直接构造一个分类（含条目）并走 Dock.persist，避免建完再"移动"二次落盘
        const id = 'custom-' + Date.now().toString(36);
        window.Dock.addCategoryWithItem({ id, name: v, icon: 'builtin:folder', color: window.Dock.PALETTE[0] }, item, cat.id);
      };
      input.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter') commit();
        else if (e.key === 'Escape') close();
      });
      input.addEventListener('mousedown', (e) => e.stopPropagation());
    } });
    el.appendChild(nw);

    // ★ v1.33.9 删除语义合并（原两项功能重复，现只留一个入口）：
    //   「删除图标」= 从分类移除 + 电脑上的实体文件移入回收站（可恢复）。
    //   虚拟条目（回收站 / 此电脑等 shell 命名空间项）不是磁盘文件，不提供删除。
    //   注：失效图标提示（__onLaunchFailed）仍只移出分类 —— 那种情况文件本就不存在了。
    if (!item.virtual) {
      el.appendChild(mkItem('trash', '删除图标…', {
        danger: true,
        run: () => {
          const base = baseName(item.srcLnk || item.path);
          askConfirm(
            '删除图标',
            `将把「${itemLabel(item)}」从「${cat ? cat.name : '当前分类'}」移除，\n` +
            `并删除电脑上的文件「${base}」（移入回收站，可恢复）。`,
            '删除',
            () => window.desknest.deleteFile(item.path)
          );
        },
      }));
    }

    if (item.manual) {
      el.appendChild(mkSep());
      el.appendChild(mkItem('undo', '取消手动归类', {
        danger: true,
        run: () => window.Dock.clearManual(cat.id, item.path),
      }));
    }
    el.appendChild(mkSep());
    el.appendChild(mkItem('refresh', '刷新桌面', { run: () => rescan() }));
    el.appendChild(mkItem('gear', '设置', { run: () => window.Settings.open() }));
  }

  // 分类芯片菜单
  function buildCat(ctx) {
    const { cat } = ctx;
    const cats = window.Dock.getCats();
    const idx = cats.findIndex((c) => c.id === cat.id);
    el.appendChild(mkTitle(`${cat.name} · ${cat.items.length} 项`));
    el.appendChild(mkSep());      // ★ 09-27 移除「打开此分类」项（悬停芯片即已展开该分类，此项多余）；
                                  //   分隔线保留，标题与「面板列数」组的分组关系不变

    // ★ 面板列数（2/3/4 列，当前列数高亮；与 Ctrl+滚轮调列共用 Dock.setPanelCols）
    el.appendChild(mkTitle('面板列数'));
    for (const n of [2, 3, 4]) {
      el.appendChild(mkItem('grid', `${n} 列显示`, {
        on: window.Dock.getPanelCols() === n,
        run: () => window.Dock.setPanelCols(n),
      }));
    }
    el.appendChild(mkSep());

    el.appendChild(mkItem('sort', '整理·按名称排序', {
      disabled: cat.items.length < 2,
      run: () => window.Dock.sortCategory(cat.id, 'name'),
    }));
    el.appendChild(mkItem('sort', '整理·按类型排序', {
      disabled: cat.items.length < 2,
      run: () => window.Dock.sortCategory(cat.id, 'type'),
    }));
    el.appendChild(mkItem('undo', '恢复默认识别顺序', {
      disabled: cat.items.length < 2,
      run: () => window.Dock.sortCategory(cat.id, 'default'),
    }));
    el.appendChild(mkSep());

    el.appendChild(mkItem('pencil', '重命名此分类…', {
      disabled: cat.id === 'uncategorized',
      keepOpen: true,
      run: (node) => {
        node.classList.add('edit');
        node.innerHTML = `<span class="ico">${MI.pencil}</span>` +
          `<input type="text" value="${esc(cat.name)}" spellcheck="false">`;
        const input = node.querySelector('input');
        input.focus();
        input.select();
        input.addEventListener('keydown', (e) => {
          e.stopPropagation();
          if (e.key === 'Enter') {
            const v = input.value.trim();
            close();
            if (v) window.Dock.upsertCategory({ id: cat.id, name: v });
          } else if (e.key === 'Escape') close();
        });
        input.addEventListener('mousedown', (e) => e.stopPropagation());
      },
    }));

    el.appendChild(mkItem('move', '左移', {
      disabled: idx <= 0,
      run: () => window.Dock.moveCategory(cat.id, -1),
    }));
    el.appendChild(mkItem('move', '右移', {
      disabled: idx < 0 || idx >= cats.length - 1,
      run: () => window.Dock.moveCategory(cat.id, 1),
    }));
    el.appendChild(mkSep());
    // ★ 右键新增快捷方式：直接弹文件对话框选程序/文件 → 自动命名并加入本分类
    //   （无输入框；名称取文件名去扩展名；图标由 extract-icons 补提取）
    el.appendChild(mkItem('plus', '新增快捷方式…', {
      run: () => {
        close();
        try { window.chrome.webview.postMessage('add-shortcut ' + cat.id); } catch (e) { /* ignore */ }
      },
    }));
    el.appendChild(mkSep());
    el.appendChild(mkItem('grid', '分类管理…', { run: () => window.Cats.open() }));
  }

  // 坞条空白处菜单
  function buildDock() {
    const cats = window.Dock.getCats();
    const total = cats.reduce((a, c) => a + c.items.length, 0);
    el.appendChild(mkTitle(`DeskNest 桌面巢 · ${cats.length} 分类 / ${total} 项`));

    el.appendChild(mkItem('refresh', '重扫桌面', { run: () => rescan() }));
    el.appendChild(mkItem('grid', '分类管理…', { run: () => window.Cats.open() }));
    el.appendChild(mkSep());
    el.appendChild(mkItem('gear', '设置', { run: () => window.Settings.open() }));
    el.appendChild(mkItem('sort', '整理全部分类·按名称排序', {
      disabled: total < 2,
      run: () => window.Dock.sortAll('name'),
    }));
    el.appendChild(mkSep());
    el.appendChild(mkItem('eye', '隐藏坞条', { key: 'Esc', run: () => window.DeskUI.collapse() }));
    el.appendChild(mkItem('power', '退出程序', {
      danger: true,
      run: () => { try { window.chrome.webview.postMessage('exit'); } catch (e) { /* ignore */ } },
    }));
  }

  function rescan() {
    const btn = document.getElementById('rescan-btn');
    if (btn) btn.click();
    else window.desknest.rescan().then((c) => { if (Array.isArray(c) && c.length) window.Dock.setCategories(c); });
  }

  // —— 二级浮层：移动到分类 ——
  function openSub(anchor, item, srcCatId) {
    if (subEl) { subEl.remove(); subEl = null; }
    subEl = document.createElement('div');
    subEl.className = 'csub scroll-y';
    for (const c of window.Dock.getCats()) {
      const d = mkItem(null, c.name, {
        dot: c.color || 'var(--accent)',
        on: c.id === srcCatId,
        disabled: c.id === srcCatId,
        run: () => { close(); window.Dock.moveItem(srcCatId, item.path, c.id); },
      });
      d.classList.add('ci');
      subEl.appendChild(d);
    }
    el.appendChild(subEl);
    const r = anchor.getBoundingClientRect();
    const w = subEl.offsetWidth || 150;
    let x = r.right + 4;
    if (x + w > window.innerWidth - 6) x = Math.max(6, r.left - w - 4);
    subEl.style.left = x + 'px';
    subEl.style.top = Math.min(r.top, window.innerHeight - (subEl.offsetHeight || 200) - 6) + 'px';
    if (window.DeskUI) window.DeskUI.reportShapeSoon(30);
  }

  function closeSub() {
    if (subEl) { subEl.remove(); subEl = null; }
  }

  // —— 打开 / 关闭 ——
  // ctx: { kind:'item', item, cat } | { kind:'cat', cat } | { kind:'dock' }
  function open(ctx, x, y) {
    openAt = ctx;
    closeSub();
    renamePath = null;
    el.hidden = false;
    build();
    // 先渲染再量尺寸，才能正确夹取到视口内
    const w = el.offsetWidth || 190;
    const h = el.offsetHeight || 260;
    let px = x;
    let py = y;
    if (px + w > window.innerWidth - 6) px = Math.max(6, x - w);
    if (py + h > window.innerHeight - 6) py = Math.max(6, window.innerHeight - h - 6);
    el.style.left = px + 'px';
    el.style.top = py + 'px';
    bindOutside();
    if (window.DeskUI) window.DeskUI.reportShapeSoon(30);
  }

  function close() {
    if (el.hidden) return;
    renamePath = null;
    closeSub();
    el.hidden = true;
    openAt = null;
    if (window.DeskUI) window.DeskUI.reportShapeSoon(30);
  }

  function bindOutside() {
    if (outsideBound) return;
    outsideBound = true;
    // 菜单外按下任意键 → 关闭（用 mousedown 保证「点了别处就消失」的直觉）
    window.addEventListener('mousedown', (e) => {
      if (el.hidden) return;
      if (el.contains(e.target)) return;
      close();
    });
    // 坞条被收起 / 窗口失焦 → 必须关闭，否则菜单会留在屏幕上（本轮修复的核心症状之一）
    window.addEventListener('keydown', (e) => {
      if (el.hidden) return;
      if (e.key === 'Escape') { e.preventDefault(); close(); }
    });
    window.addEventListener('blur', () => close());
  }

  function isOpen() { return !el.hidden; }
  function context() { return openAt; }

  // —— ★ v1.13.7 通用确认框（#confirm-box）——
  // 用途：失效图标删除确认（launch-failed）与「删除图标」二次确认。
  // 交互约定：确认/取消按钮点击生效；Esc 与点击框外 = 取消；打开期间经
  // reportShape/DEBUG_JS 上报矩形（#confirm-box 在 FLOAT_IDS），原生自动隐藏不会收起坞条。
  let confirmEl = null;
  let confirmCb = null;

  function closeConfirm() {
    if (confirmEl) { confirmEl.remove(); confirmEl = null; }
  }

  function askConfirm(title, text, okLabel, cb, okOnly) {
    closeConfirm();
    confirmCb = cb || null;
    confirmEl = document.createElement('div');
    confirmEl.id = 'confirm-box';
    confirmEl.innerHTML =
      '<div class="glass"></div>' +
      `<div class="cb-title">${esc(title)}</div>` +
      `<div class="cb-text">${esc(text)}</div>` +
      '<div class="cb-actions">' +
      (okOnly ? '' : '<button class="wide cb-cancel">取消</button>') +
      `<button class="wide cb-ok">${esc(okLabel || '确定')}</button>` +
      '</div>';
    document.body.appendChild(confirmEl);
    // 居中（页面客户区坐标；窗口 1100x572 在屏幕顶部，页面上方留些余量更接近视觉中心）
    const w = confirmEl.offsetWidth || 280;
    const h = confirmEl.offsetHeight || 150;
    confirmEl.style.left = Math.max(8, Math.round((window.innerWidth - w) / 2)) + 'px';
    confirmEl.style.top = Math.max(8, Math.round((window.innerHeight - h) / 2) + 46) + 'px';
    const done = (yes) => {
      const cb2 = confirmCb;
      closeConfirm();
      confirmCb = null;
      if (yes && cb2) cb2();
    };
    confirmEl.querySelector('.cb-ok').addEventListener('click', (e) => { e.stopPropagation(); done(true); });
    const cancelBtn = confirmEl.querySelector('.cb-cancel');
    if (cancelBtn) cancelBtn.addEventListener('click', (e) => { e.stopPropagation(); done(false); });
    confirmEl.addEventListener('mousedown', (e) => e.stopPropagation());   // 防止框内按下被外点关闭逻辑误伤
    if (window.DeskUI) window.DeskUI.reportShapeSoon(30);
  }

  // 单按钮提示框（操作成功/失败的告知，无回调）
  function askNotice(title, text) {
    askConfirm(title, text, '确定', null, true);
  }

  // Esc / 点击框外 = 取消（模态语义；与菜单互斥：弹确认框时先收菜单）
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && confirmEl) { e.preventDefault(); closeConfirm(); confirmCb = null; }
  });
  window.addEventListener('mousedown', (e) => {
    if (!confirmEl) return;
    if (confirmEl.contains(e.target)) return;
    closeConfirm(); confirmCb = null;
  });
  window.addEventListener('blur', () => { if (confirmEl) { closeConfirm(); confirmCb = null; } });

  // ★ 原生文件对话框选完程序/文件 → 自动命名并加入对应分类
  window.__onShortcutPicked = (catId, path) => {
    const base = String(path).split('\\').pop().replace(/\.(exe|lnk)$/i, '');
    if (base && window.Dock) window.Dock.addItems(catId, [{ name: base, path }]);
  };
  return { open, close, isOpen, context, itemLabel, ask: askConfirm, notice: askNotice };
})();
