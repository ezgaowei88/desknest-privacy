// glass.js：假毛玻璃
//
// 背景来源：主进程在窗口「屏外」时用 desktopCapturer 截取的整屏画面（data 里含 PNG 字节）。
//   · #backdrop   —— 清晰版，铺满窗口并与屏幕像素对齐 → 不透明窗口的矩形视觉上消失
//   · .glass      —— 模糊版（canvas 降采样 + blur），铺在坞/面板/搜索/设置上 → 磨砂玻璃质感
'use strict';

window.Glass = (() => {
  const state = { meta: null, baseUrl: null, blurUrl: null, ready: false, lastLen: 0 };
  const DS = 0.18;            // 降采样系数：小图上做模糊，软件渲染（禁GPU）下才不会卡死渲染进程
                            // 等效模糊半径不变（radius = BLUR_CSS_PX * DS，小图拉回后视觉等效）
  const BLUR_CSS_PX = 40;     // 目标模糊半径（CSS px）——够大才能把背后的窗口标题栏等
                              // 强对比内容糊匀，否则坞内会出现深浅分界（看起来像「方格」）

  function toBytes(png) {
    if (png instanceof Uint8Array) return png;
    if (png instanceof ArrayBuffer) return new Uint8Array(png);
    if (png && png.data && png.data instanceof Uint8Array) return png.data;  // Buffer 序列化形态
    if (Array.isArray(png)) return new Uint8Array(png);
    return null;
  }

  function makeBlur(blob, m) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        try {
          const cw = Math.max(1, Math.round(img.width * DS));
          const ch = Math.max(1, Math.round(img.height * DS));
          const cv = document.createElement('canvas');
          cv.width = cw;
          cv.height = ch;
          const ctx = cv.getContext('2d');
          const radius = BLUR_CSS_PX * DS * (m.scale || 1);
          // ★ 09-23：模糊同时强力去饱和——壁纸可能任何颜色（用户壁纸为蓝色图时
          // 曾把整个坞染蓝），saturate(0.22) 后只剩中性明度，玻璃质感不串色
          try { ctx.filter = `saturate(0.22) blur(${radius}px)`; } catch { /* 不支持则退化为无模糊 */ }
          // 放大 1.1 倍绘制：高斯模糊会让图像边界产生透明渐隐，而坞正处在屏幕顶部边缘
          // （不做这步时坞内上沿会发白/发灰，形成一条突兀的横带）
          ctx.drawImage(img, -cw * 0.05, -ch * 0.05, cw * 1.1, ch * 1.1);
          cv.toBlob((b) => resolve(b ? URL.createObjectURL(b) : null), 'image/jpeg', 0.92);
        } catch {
          resolve(null);
        }
      };
      img.onerror = () => resolve(null);
      const url = URL.createObjectURL(blob);
      img.src = url;
      img.onload_ = url;
    });
  }

  async function set(data) {
    try {
    const bytes = data && toBytes(data.png);
    console.log('[glass] set bytes=', bytes ? bytes.length : 'null', 'mime=', data && data.mime);
    if (!bytes) return;
    // 去重：同一张样张（如反复推送的壁纸）不做重复的模糊计算——
    // 软件渲染下 1080p canvas blur 很重，连续处理会拖垮渲染进程
    if (state.lastLen === bytes.length && state.ready) return;
    state.lastLen = bytes.length;
    const blob = new Blob([bytes], { type: data.mime || 'image/png' });
    if (state.baseUrl) URL.revokeObjectURL(state.baseUrl);
    if (state.blurUrl) URL.revokeObjectURL(state.blurUrl);
    state.baseUrl = URL.createObjectURL(blob);
    state.blurUrl = null;
    state.meta = {
      w: data.w,
      h: data.h,
      scale: data.scale || 1,
      offsetX: data.offsetX || 0,
      offsetY: data.offsetY || 0,
      glassOnly: !!data.glassOnly   // 玻璃纹理专用源：不铺 #backdrop（避免蓝底/对位假设）
    };
    state.ready = true;
    apply();
    const url = await makeBlur(blob, state.meta);
    console.log('[glass] blur result=', url ? 'ok' : 'null');
    if (url) {
      state.blurUrl = url;
      applyEnd();          // 可能正处入场动画中，结束后再校准一次
    }
    } catch (e) { console.error('[glass] set-err', e); }
  }

  function apply() {
    if (!state.meta) return;
    const m = state.meta;
    const sizeCss = `${m.w / m.scale}px ${m.h / m.scale}px`;
    const ox = m.offsetX / m.scale;
    const oy = m.offsetY / m.scale;

    // 底图（清晰壁纸铺满窗口）仅在「真实桌面取样」时使用；
    // 壁纸纹理源（glassOnly）只上玻璃层 —— 窗口外的区域一律不属于窗口形状，
    // 不做任何对位假设（09-23：杜绝蓝底残渣回归）
    const bd = document.getElementById('backdrop');
    if (bd && state.baseUrl && !state.meta.glassOnly) {
      bd.style.backgroundImage = `url(${state.baseUrl})`;
      bd.style.backgroundSize = sizeCss;
      bd.style.backgroundPosition = `${-ox}px ${-oy}px`;
      bd.classList.add('on');
    }

    if (!state.blurUrl) return;
    // 手动对齐（背景图按元素视口位置偏移）。
    // 注意：不能用 background-attachment:fixed —— ①祖先/自身的静态 transform 会让
    // fixed 退化成相对该容器定位；②本机禁 GPU 软件渲染下 fixed 的图片层干脆不绘制
    // （A/B 实测只剩 tint 灰块）。动画进行中测量会偏差，applyEnd 会在动画结束后重测。
    //
    // ★ 09-22 改版：背景源从「屏幕位置对齐的截图」换成了「壁纸」——壁纸不含窗口/图标，
    //   位置对齐已无意义。改用 cover 拉伸：每个浮层显示整张壁纸的模糊缩影，
    //   色彩均匀（修复大浮层上下两截色、设置条「方格」感）。
    document.querySelectorAll('.glass').forEach((el) => {
      el.style.backgroundImage =
        // 顶部玻璃反光高光（macOS 质感的关键一层）：上亮下透
        `linear-gradient(180deg, rgba(255,255,255,0.20), rgba(255,255,255,0.04) 42%, rgba(255,255,255,0.08)),` +
        `linear-gradient(var(--glass-tint), var(--glass-tint)),` +
        `url(${state.blurUrl})`;
      el.style.backgroundSize = 'auto, auto, cover';
      el.style.backgroundPosition = '0px 0px, 0px 0px, 0px 0px';
      el.classList.add('on');
    });

    // ★ 09-23e 纹理描边法（方案 2A）：body 底也刷同源纹理 —— 圆角区域外扩的
    // 1px 描边带露出的是 body，与坞体玻璃同源同色系，区域台阶落入低对比区；
    // 同时区域变更瞬间的陈旧内容也从「黑块」弱化为「不刺眼的纹理色」
    document.body.style.backgroundImage = `url(${state.blurUrl})`;
    document.body.style.backgroundSize = 'cover';
    document.body.style.backgroundPosition = 'center';
  }

  // 入场/展开动画期间测量必错位：动画结束后再重测一次
  function applyEnd() {
    apply();
    clearTimeout(applyEnd.t);
    applyEnd.t = setTimeout(apply, 320);
  }

  // 供元素位置/尺寸变化后重算（面板展开、滑杆调高度等）
  function refresh() { apply(); }

  function clear() {
    const bd = document.getElementById('backdrop');
    if (bd) { bd.classList.remove('on'); bd.style.backgroundImage = ''; }
    document.querySelectorAll('.glass').forEach((el) => {
      el.classList.remove('on');
      el.style.backgroundImage = '';
    });
    // 关毛玻璃时 body 回到纯色实底
    document.body.style.backgroundImage = '';
    document.body.style.backgroundSize = '';
    document.body.style.backgroundPosition = '';
  }

  return { set, apply, applyEnd, refresh, clear, state };
})();
