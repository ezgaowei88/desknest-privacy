// search.js：搜索过滤 + 键盘导航
'use strict';

window.Search = (() => {
  const bar = document.getElementById('search-bar');
  const input = document.getElementById('search-input');
  const results = document.getElementById('search-results');
  let selIdx = -1;
  let current = [];

  function open() {
    // ★ 菜单互斥：搜索条展开时收起分类面板与设置面板
    if (window.Dock) window.Dock.closeAll();
    if (window.Settings) window.Settings.close();
    bar.hidden = false;
    input.value = '';
    showHint('输入应用名 / 拼音 / 路径关键词，支持模糊匹配');
    window.desknest.focusWindow();          // 让输入框拿到键盘焦点
    setTimeout(() => input.focus(), 40);
    // 命中区域必须包含搜索栏，否则窗口裁剪会让鼠标点击直接穿透到桌面
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(80);
  }

  function close(refocus) {
    if (bar.hidden) return;
    bar.hidden = true;
    input.blur();
    results.innerHTML = '';
    if (refocus !== false) window.desknest.blurWindow();
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon();
  }

  function showHint(text) {
    current = [];
    selIdx = -1;
    results.innerHTML = `<div id="search-hint">${escapeHtml(text)}</div>`;
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(60);
  }

  function render(list) {
    current = list;
    selIdx = -1;
    if (!list.length) { showHint('没有匹配的条目'); return; }
    results.innerHTML = '';
    list.forEach(({ item, cat }) => {
      const d = document.createElement('div');
      d.className = 'sr-item';
      d.appendChild(window.Dock.makeIconEl(item));   // ★ 同一套图标兜底逻辑
      d.insertAdjacentHTML('beforeend',
        `<span>${escapeHtml(window.Dock.dispName(item))}</span><span class="cat-name">${escapeHtml(cat.name)}</span>`);
      d.addEventListener('mousedown', (e) => e.preventDefault());   // 防止 blur 抢先导致 click 丢失
      d.addEventListener('click', async () => {
        close();
        window.DeskUI.collapse();
        await window.desknest.launch({ path: item.path, srcLnk: item.srcLnk, target: item.target, type: item.type });
      });
      // ★ 右键：与面板条目同一套菜单（打开/管理员运行/定位/属性/重命名/移动）
      d.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.Menu) window.Menu.open({ kind: 'item', item, cat }, e.clientX, e.clientY);
      });
      results.appendChild(d);
    });
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(60);
  }

  function markSel() {
    [...results.children].forEach((c, i) => c.classList.toggle('sel', i === selIdx));
    if (selIdx >= 0) results.children[selIdx].scrollIntoView({ block: 'nearest' });
  }

  // 分类数据/显示名变更后重跑当前查询（rename、移动归类后调用）
  function refresh() {
    const q = input.value.trim().toLowerCase();
    if (!q) return;
    render(window.DeskUI.searchAll(q).slice(0, 30));
  }

  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    if (!q) { showHint('输入应用名 / 拼音 / 路径关键词，支持模糊匹配'); return; }
    render(window.DeskUI.searchAll(q).slice(0, 30));
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { close(); return; }
    if (!current.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); selIdx = Math.min(selIdx + 1, current.length - 1); markSel(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); selIdx = Math.max(selIdx - 1, 0); markSel(); }
    else if (e.key === 'Enter' && selIdx >= 0) {
      const { item } = current[selIdx];
      close();
      window.DeskUI.collapse();
      window.desknest.launch({ path: item.path, srcLnk: item.srcLnk, target: item.target, type: item.type });
    }
  });

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  return { open, close, refresh, isOpen: () => !bar.hidden };
})();
