// app.js：入口，串联 dock/search/settings/cats，处理弹出收起与命中区域上报
'use strict';

window.DeskUI = (() => {
  const dockEl = document.getElementById('dock');
  const searchBtn = document.getElementById('search-btn');
  const settingsBtn = document.getElementById('settings-btn');

  const state = {
    visible: true,
    sysInfo: {},
    categories: [],
    cfg: {}
  };

  // 命中区域上报
  // 关键：入场/收起动画期间 getBoundingClientRect 会带上 translateY 偏移。
  // ★ 09-23c：形状矩形不再把负 y 钳位成 0（钳位会产生「收起态坐标」的错位形状，
  //   4 个角被切得乱锯齿）—— 负 y 矩形原样上报，主进程过滤后保留上一份正确形状。
  let shapeTimer = null;
  let shapeTimerDelay = 0;
  const sanitize = (r) => ({
    x: Math.max(0, Math.round(r.left)),
    y: Math.max(0, Math.round(r.top)),
    width: Math.max(1, Math.round(r.width)),
    height: Math.max(1, Math.round(r.height))
  });
  const rawRect = (r) => ({
    x: Math.round(r.left),
    y: Math.round(r.top),
    width: Math.max(1, Math.round(r.width)),
    height: Math.max(1, Math.round(r.height))
  });

  const FLOAT_IDS = ['panel', 'search-bar', 'settings-bar', 'cats-bar', 'move-menu', 'ctx-menu', 'confirm-box'];

  // 元素的 CSS 圆角（px）
  function radiusOf(el) {
    const v = parseFloat(getComputedStyle(el).borderTopLeftRadius);
    return Number.isFinite(v) ? v : 0;
  }

  // ★ 09-24 圆角抗锯齿 v2（宽混合带 + 4x4 Bayer）：
  //   探针已双重复测证伪透明窗口（软件渲染 09-23、GPU 开启 09-24 均不上屏），
  //   per-pixel alpha 在本显示驱动栈下不存在 —— 区域级半调是唯一路径。
  //   v1 的 1px 混合带 + 2x2 Bayer 过渡太窄，人眼仍能分辨台阶结构；
  //   v2 把边界摊成 ~2.5px 宽的密度渐变带（像素中心距边界的位置决定覆盖率），
  //   4x4 Bayer 提供 16 级密度 —— 边缘呈「桌面→稀疏点→渐密点→坞体」的连续弧。
  //   带内区域外的像素露 body 同源纹理（glass.js），与坞体同色系。
  const BAYER4 = [
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5]
  ];
  const BLEND_W = 2.5;   // 混合带半宽+全宽总摊开 ≈ 2.5px

  function roundedRegion(r, radius) {
    const R = Math.floor(Math.min(radius, r.width / 2, r.height / 2));
    if (R < 3) return [r];
    const rects = [{ x: r.x, y: r.y + R, width: r.width, height: r.height - 2 * R }];   // 中段整块
    for (let k = 0; k < R; k++) {
      const rows = [
        [r.y + k, R - Math.sqrt(Math.max(0, R * R - (R - k) * (R - k)))],   // 顶带
        [r.y + r.height - R + k, R - Math.sqrt(Math.max(0, R * R - k * k))] // 底带
      ];
      for (const [y, e] of rows) {
        const pL = r.x + e;                    // 左边界（真实圆弧）
        const pR = r.x + r.width - e;          // 右边界
        // 实心段：像素中心距边界 ≥ BLEND_W/2（覆盖率=1）
        const solidL = Math.ceil(pL + BLEND_W / 2 - 0.5);
        const solidR = Math.floor(pR - BLEND_W / 2 - 0.5);
        if (solidR - solidL + 1 > 0) rects.push({ x: solidL, y, width: solidR - solidL + 1, height: 1 });
        // 左右混合带：中心位置决定覆盖率，Bayer 阈值决定纳入与否
        const lo = Math.max(r.x - 2, Math.floor(pL - BLEND_W));
        const hi = Math.min(r.x + r.width + 2, Math.ceil(pL + BLEND_W));
        for (let x = lo; x < hi; x++) {
          const cov = Math.min(1, Math.max(0, (x + 0.5 - pL) / BLEND_W + 0.5));
          if (cov > 0 && cov * 16 > BAYER4[y & 3][x & 3]) rects.push({ x, y, width: 1, height: 1 });
        }
        const lo2 = Math.max(r.x - 2, Math.floor(pR - BLEND_W));
        const hi2 = Math.min(r.x + r.width + 2, Math.ceil(pR + BLEND_W));
        for (let x = lo2; x < hi2; x++) {
          const cov = Math.min(1, Math.max(0, (pR - (x + 0.5)) / BLEND_W + 0.5));
          if (cov > 0 && cov * 16 > BAYER4[y & 3][x & 3]) rects.push({ x, y, width: 1, height: 1 });
        }
      }
    }
    return rects.filter((q) => q.width > 0 && q.height > 0);
  }

  function reportShapeNow() {
    // barRect 仅供 autohide 命中判定（保留 +6px 余量）；窗口形状不用它 ——
    // 否则坞下方会露出一条 6px 的底色带
    const barHit = sanitize(dockEl.getBoundingClientRect());
    barHit.height += 6;

    // 形状区域：坞条 + 每个可见浮层各自成「圆角区域」（多边形扫描线矩形组）。
    // 用 rawRect 不钳位：动画中的负 y 矩形会被主进程整体过滤，
    // 从而保留上一份静止时测得的正确形状（而不是错位的钳位形状）。
    let rects = roundedRegion(rawRect(dockEl.getBoundingClientRect()), radiusOf(dockEl));
    const floatRects = [];
    for (const id of FLOAT_IDS) {
      const e = document.getElementById(id);
      if (!e || e.hidden) continue;
      const r = rawRect(e.getBoundingClientRect());
      floatRects.push(r);
      rects = rects.concat(roundedRegion(r, radiusOf(e)));
    }

    // 兼容 autohide 的光标归属判断：仍提供所有浮层的包围盒 panelRect
    let box = null;
    for (const r of floatRects) {
      if (!box) { box = { ...r }; continue; }
      const x2 = Math.max(box.x + box.width, r.x + r.width);
      const y2 = Math.max(box.y + box.height, r.y + r.height);
      box.x = Math.min(box.x, r.x);
      box.y = Math.min(box.y, r.y);
      box.width = x2 - box.x;
      box.height = y2 - box.y;
    }
    window.desknest.reportShape({ open: !!box, barRect: barHit, panelRect: box, rects });
  }

  // 立即上报 + 动画结束后重测（保证最终区域精确）。
  // ★ 09-23c：多个调用方（expand 340ms / applyVars 60ms…）共用计时器时，
  //   不允许后到的短延迟把已排队的长延迟校准「顶掉」—— 曾导致 60ms 的重测
  //   落在入场动画中途、测到钳位的错位形状后不再有校准（四角锯齿根因）。
  //   规则：已有待校准且其延迟 >= 新延迟时，保留原计时。
  function reportShapeSoon(delay) {
    reportShapeNow();
    const d = delay || 340;
    if (shapeTimer && shapeTimerDelay >= d) return;
    clearTimeout(shapeTimer);
    shapeTimerDelay = d;
    shapeTimer = setTimeout(() => {
      shapeTimer = null;
      shapeTimerDelay = 0;
      reportShapeNow();
      if (window.Glass) window.Glass.refresh();
    }, d);
  }

  function expand() {
    state.visible = true;
    document.body.classList.remove('dock-hidden');
    document.body.classList.add('dock-anim');
    setTimeout(() => document.body.classList.remove('dock-anim'), 300);
    reportShapeSoon();
  }

  function collapse() {
    state.visible = false;
    window.Search.close(false);
    window.Settings.close();
    window.Cats.close();
    window.Dock.closeAll();
    if (window.Menu) window.Menu.close();
    document.body.classList.add('dock-hidden');
    reportShapeSoon();
  }

  function closeOthers(except) {
    if (except !== 'search') window.Search.close();
    if (except !== 'settings') window.Settings.close();
    if (except !== 'cats') window.Cats.close();
    if (except !== 'menu' && window.Menu) window.Menu.close();
    if (except !== 'bookmarks' && window.Bookmarks) window.Bookmarks.setOpen(false);
  }

  // —— ★ 浮层「点外关闭」——
  // 搜索/设置/分类管理面板展开时（点击按钮后向下展开，用户口中的"下拉框"），
  // 在面板与坞条之外的空白区域按下鼠标（左键或右键都算）→ 统一收起。
  // 面板内点击、坞条点击（按钮 toggle 自洽）、右键菜单、移动浮层不触发
  // （后两者各有自己的 outside 关闭处理，见 menu.js / cats.js）。
  // ★ 界面外单击（窗口内）：关闭全部浮层 + 界面缩回（需求3/4）
  //   范围 = #dock + 全部浮层；窗口外点击由原生泵检测（outside-click 消息）兜底
  document.addEventListener('mousedown', (e) => {
    if (e.target.closest && e.target.closest('#search-bar, #settings-bar, #cats-bar, #dock, #ctx-menu, #move-menu, #confirm-box, #panel, #bm-panel')) return;
    if (document.getElementById('confirm-box')) return;   // 确认框模态期间不缩回
    window.Search.close();
    window.Settings.close();
    window.Cats.close();
    window.Dock.closeAll();
    if (window.Bookmarks) window.Bookmarks.setOpen(false);
    window.desknest.hideNow();   // 界面缩回
  });

  // —— ★ 面板内禁用浏览器默认右键菜单 ——
  // 此前在搜索/设置/分类管理面板内部右键会泄漏 Chromium 默认菜单；
  // 搜索结果条目的自定义菜单在自身处理器里已 preventDefault+stopPropagation，不受影响。
  for (const id of ['search-bar', 'settings-bar', 'cats-bar']) {
    const el = document.getElementById(id);
    if (el) el.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  // ★ 全局兜底：壳内任何位置都不弹 Chromium 默认右键菜单（含面板外空白/backdrop 区）。
  // 自定义菜单（芯片/结果条目/dock 空白）在自己的处理器里已 preventDefault+stopPropagation
  // 或 defaultPrevented=true，到这里的一律是"没人处理"的右键 → 吞掉。
  document.addEventListener('contextmenu', (e) => {
    if (!e.defaultPrevented) e.preventDefault();
  });

  searchBtn.addEventListener('click', () => {
    const bar = document.getElementById('search-bar');
    closeOthers('search');
    if (bar.hidden) window.Search.open();
    else window.Search.close();
  });

  settingsBtn.addEventListener('click', () => {
    const bar = document.getElementById('settings-bar');
    closeOthers('settings');
    if (bar.hidden) window.Settings.open();
    else window.Settings.close();
  });

  // 主进程事件
  // ★ 尽早订阅壁纸推送：did-finish-load 后主进程立即 send BACKDROP，
  //   若订阅晚于推送（init 异步链完成前）消息直接丢失，玻璃就没有模糊图
  window.desknest.onBackdrop((d) => { try { window.Glass.set(d); } catch (e) { console.error('[glass] onBackdrop', e); } });
  window.desknest.onDockShown(() => {
    expand();
    window.Settings.applyVars();
    // ★ v1.33.10 自愈：坞条隐藏时原生 SetIsVisible(false)，WebView2 对不可见页面
    //   节流，双向消息可能被延迟/吞掉（重扫回传、新文件回执、persist 本身）——
    //   每次呼出时拉一次磁盘最新分类对齐内存，杜绝「旧内存 persist 覆盖原生写盘」。
    //   仅在数据确有差异时重渲染，避免坞条图标无谓闪烁。
    (async () => {
      try {
        const c = await window.desknest.refreshCategories();
        if (Array.isArray(c) && c.length) {
          const cur = JSON.stringify(window.Dock.getCats() || []);
          if (JSON.stringify(c) !== cur) window.Dock.setCategories(c);
        }
      } catch (e) { /* ignore */ }
    })();
  });
  window.desknest.onDockHidden(() => collapse());

  async function init() {
    state.sysInfo = await window.desknest.systemInfo();
    const cfg = await window.desknest.getConfig();
    cfg._activeHotkey = state.sysInfo.activeHotkey;
    state.cfg = cfg;
    window.SettingsInit = { cfg };
    window.Settings.init(cfg);
    // ★ v1.38.0 启动静默检查更新（每 24 小时一次，发现新版才弹提示）
    try {
      const last = parseInt(localStorage.getItem('desknest.lastUpdateCheck') || '0', 10);
      if (Date.now() - last > 24 * 3600 * 1000) {
        localStorage.setItem('desknest.lastUpdateCheck', String(Date.now()));
        window.Settings.checkUpdate(true);
      }
    } catch (e) { /* ignore */ }
    // ★ v1.33.10：启动时主动向原生拉取「磁盘最新分类」，而不是用启动快照 __CATS。
    //   竞态场景：启动重扫（原生写盘）与分类快照注入几乎同时发生，页面可能拿到重扫前的
    //   旧数据 → 之后「桌面新文件监控」用旧内存把已归类的文件当成新文件塞回「其他」
    //   并 persist，反过来把原生重扫的正确结果覆盖掉（表现为「新建文件后重扫不归类」）。
    //   拉取失败时回退到启动快照，行为与旧版一致。
    let cats = null;
    try {
      cats = await window.desknest.refreshCategories();
    } catch (e) { /* ignore */ }
    state.categories = (Array.isArray(cats) && cats.length)
      ? cats
      : await window.desknest.getCategories();
    window.Dock.setCategories(state.categories);

    // 毛玻璃：首次拉取桌面取样（推送订阅已提到模块顶层，避免与主进程推送竞态丢消息）
    try {
      const bd = await window.desknest.getBackdrop();
      if (bd) window.Glass.set(bd);
    } catch { /* ignore */ }

    reportShapeNow();
    startHealthReport();
  }

  // 诊断：每秒上报渲染层真实状态（DOM 是否渲染、有无 JS 错误）
  const jsErrors = [];
  window.addEventListener('error', (e) => jsErrors.push(String(e.message || e.error)));
  function startHealthReport() {
    setInterval(() => {
      const r = dockEl.getBoundingClientRect();
      let items = 0;
      for (const c of window.Dock.getCats()) items += c.items.length;
      window.desknest.reportHealth({
        cats: window.Dock.getCats().length,
        items,
        dockRect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) },
        bodyClass: document.body.className,
        panelHidden: document.getElementById('panel').hidden,
        searchHidden: document.getElementById('search-bar').hidden,
        settingsHidden: document.getElementById('settings-bar').hidden,
        catsHidden: document.getElementById('cats-bar').hidden,
        catNodes: document.querySelectorAll('.cat').length,
        cnameNodes: document.querySelectorAll('.cat .cname').length,
        glassReady: window.Glass ? !!window.Glass.state.blurUrl : false,
        backdropOn: !!document.getElementById('backdrop').classList.contains('on'),
        errors: jsErrors.slice(-5)
      });
    }, 1000);
  }

  function searchAll(q) {
    const out = [];
    for (const cat of window.Dock.getCats()) {
      for (const item of cat.items) {
        if (item.name.toLowerCase().includes(q) || String(item.path).toLowerCase().includes(q)) {
          out.push({ item, cat });
        }
      }
    }
    // 无子串命中时退化为子序列模糊匹配（如 "ps" 命中 "Photoshop"）
    if (!out.length) {
      for (const cat of window.Dock.getCats()) {
        for (const item of cat.items) {
          if (isSubsequence(q, item.name.toLowerCase())) out.push({ item, cat });
        }
      }
    }
    return out;
  }

  function isSubsequence(q, text) {
    let i = 0;
    for (const ch of text) {
      if (ch === q[i]) i++;
      if (i >= q.length) return true;
    }
    return false;
  }

  return { init, expand, collapse, reportShapeNow, reportShapeSoon, searchAll, state };
})();

window.addEventListener('DOMContentLoaded', () => window.DeskUI.init());
