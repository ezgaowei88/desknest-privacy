// settings.js：内嵌设置条（主题三态 + 高度/底色/图标大小 + 分类名 + 毛玻璃 + 快捷键 + 分类管理）
'use strict';

window.Settings = (() => {
  const bar = document.getElementById('settings-bar');
  const themeSeg = document.getElementById('theme-seg');
  const labelSeg = document.getElementById('label-seg');
  const glassSeg = document.getElementById('glass-seg');
  const rngHeight = document.getElementById('rng-height');
  const rngOpacity = document.getElementById('rng-opacity');
  const rngIcon = document.getElementById('rng-icon');
  const rescanBtn = document.getElementById('rescan-btn');
  const catsBtn = document.getElementById('cats-btn');
  const hotkeyBtn = document.getElementById('hotkey-btn');
  const autostartSeg = document.getElementById('autostart-seg');
  const hidedeskSeg = document.getElementById('hidedesk-seg');
  const statsSeg = document.getElementById('stats-seg');
  const linksRow = document.getElementById('links-row');
  const fbBtn = document.getElementById('fb-btn');
  const sponsorBtn = document.getElementById('sponsor-btn');
  const updBtn = document.getElementById('upd-btn');   // ★ v1.38.0 检查更新
  const moreBtn = document.getElementById('more-btn'); // ★ v1.39.0 更多设置折叠头
  const moreFold = document.getElementById('more-fold');
  let updSilent = false;

  const mq = window.matchMedia('(prefers-color-scheme: dark)');
  let config = null;
  let recording = false;

  function prettyAcc(e) {
    const parts = [];
    if (e.ctrlKey) parts.push('Control');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    if (e.metaKey) parts.push('Super');
    let key = e.key;
    if (['Control', 'Alt', 'Shift', 'Meta'].includes(key)) return null; // 还没按主键
    if (/^[a-z]$/i.test(key)) key = key.toUpperCase();
    else if (/^F\d{1,2}$/.test(key)) { /* F1-F12 保持 */ }
    else if (/^[0-9]$/.test(key)) { /* 数字保持 */ }
    else return null; // 暂不支持其他键
    parts.push(key);
    return parts.join('+');
  }

  function startRecord() {
    recording = true;
    hotkeyBtn.textContent = '按下快捷键…';
    hotkeyBtn.classList.add('recording');
    hotkeyBtn.focus();
  }

  // 初始显示实际生效的全局热键（原生启动时占用检测/回退后的真实值）
  hotkeyBtn.textContent = (window.__HOTKEY_ACTIVE || config.hotkey || 'Ctrl+Alt+D')
    .replace(/^Control/, 'Ctrl').replace(/^Super/, 'Win');

  hotkeyBtn.addEventListener('click', () => { if (!recording) startRecord(); });

  hotkeyBtn.addEventListener('keydown', async (e) => {
    if (!recording) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.key === 'Escape') {
      recording = false;
      hotkeyBtn.classList.remove('recording');
      hotkeyBtn.textContent = (config.hotkey || '').replace(/^Control/, 'Ctrl').replace(/^Super/, 'Win');
      return;
    }
    const acc = prettyAcc(e);
    if (!acc) return; // 只按了修饰键，等待主键
    if (!e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey) {
      hotkeyBtn.textContent = '需含 Ctrl/Alt/Shift';
      setTimeout(() => { hotkeyBtn.textContent = config.hotkey; hotkeyBtn.classList.remove('recording'); recording = false; }, 1200);
      return;
    }
    const r = await window.desknest.setHotkey(acc);
    recording = false;
    hotkeyBtn.classList.remove('recording');
    if (r.ok) {
      config.hotkey = r.hotkey || acc;
      window.desknest.saveConfig({ hotkey: config.hotkey });
      if (r.fallback) {
        // ★ 被占用自动回退：按钮临时提示"原组合被占用"，随后显示实际生效组合
        hotkeyBtn.textContent = `${acc} 被占用 → 已回退`;
        setTimeout(() => {
          hotkeyBtn.textContent = config.hotkey.replace(/^Control/, 'Ctrl').replace(/^Super/, 'Win');
        }, 2000);
      } else {
        hotkeyBtn.textContent = config.hotkey.replace(/^Control/, 'Ctrl').replace(/^Super/, 'Win');
      }
    } else {
      hotkeyBtn.textContent = r.error || '注册失败';
      setTimeout(() => { hotkeyBtn.textContent = config.hotkey.replace(/^Control/, 'Ctrl'); }, 1500);
    }
  });

  function applyTheme(mode) {
    const effective = mode === 'system' ? (mq.matches ? 'dark' : 'light') : mode;
    document.documentElement.dataset.theme = effective;
    // 同步主进程窗口底色（桌面取样未就绪时的兜底）
    window.desknest.setThemeBg(effective);
  }

  // 十六进制混色
  function mixHex(a, b, t) {
    const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16));
    const pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
    return '#' + pa.map((v, i) => Math.round(v + (pb[i] - v) * t).toString(16).padStart(2, '0')).join('');
  }

  // 「底色」滑杆：控制玻璃色调层的深浅（数值越大越实）
  function applyVars(cfg) {
    const c = cfg || config || {};
    const v = c.opacity != null ? c.opacity : 0.72;
    const t = Math.min(1, Math.max(0, (v - 0.4) / 0.55));
    const light = document.documentElement.dataset.theme === 'light';
    const surface = light ? mixHex('#FFFFFF', '#C7D5CF', t) : mixHex('#070A08', '#2E3A34', t);
    document.documentElement.style.setProperty('--surface', surface);
    // 玻璃色调：滑杆控制 alpha。★ 09-23 下调基数——玻璃层已有去饱和壁纸纹理垫底，
    // 旧基数(暗0.30/亮0.45)让最左端仍是一块实心板（用户反馈「拉到最左不够透」）；
    // 现在 t=0 时纹理清晰可见=通透磨砂，t=1 时近乎实底=厚重
    const alpha = light ? (0.26 + t * 0.46) : (0.14 + t * 0.54);
    document.documentElement.style.setProperty(
      '--glass-tint',
      light ? `rgba(255,255,255,${alpha.toFixed(2)})` : `rgba(9,13,11,${alpha.toFixed(2)})`
    );
    document.documentElement.style.setProperty('--dock-h', (c.dockHeight || 64) + 'px');
    document.documentElement.style.setProperty('--icon-size', (c.iconSize || 40) + 'px');
    window.DeskUI.reportShapeSoon(60);
  }

  function applyFlags(cfg) {
    document.body.classList.toggle('show-labels', cfg.showLabels !== false);
    document.body.classList.toggle('no-glass', cfg.glass === false);
    if (cfg.glass === false && window.Glass) window.Glass.clear();
    else if (window.Glass) window.Glass.refresh();
  }

  mq.addEventListener('change', () => {
    if (config && config.theme === 'system') applyTheme('system');
  });

  themeSeg.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    config.theme = btn.dataset.themeOpt;
    [...themeSeg.children].forEach((b) => b.classList.toggle('on', b === btn));
    applyTheme(config.theme);
    applyVars(config);
    window.desknest.saveConfig({ theme: config.theme });
  });

  labelSeg.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    config.showLabels = btn.dataset.labelOpt === 'on';
    [...labelSeg.children].forEach((b) => b.classList.toggle('on', b === btn));
    applyFlags(config);
    window.DeskUI.reportShapeSoon(60);
    window.desknest.saveConfig({ showLabels: config.showLabels });
  });

  glassSeg.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    config.glass = btn.dataset.glassOpt === 'on';
    [...glassSeg.children].forEach((b) => b.classList.toggle('on', b === btn));
    applyFlags(config);
    window.desknest.saveConfig({ glass: config.glass });
  });

  // 开机自启：真实状态以系统登录项为准，按钮态跟随实际生效结果
  function renderAutostart(on) {
    [...autostartSeg.children].forEach((b) => b.classList.toggle('on', (b.dataset.autostartOpt === 'on') === !!on));
  }
  (async () => {
    try {
      const r = await window.desknest.getAutostart();
      if (r && r.ok) renderAutostart(r.openAtLogin);
    } catch { /* ignore */ }
  })();
  autostartSeg.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const on = btn.dataset.autostartOpt === 'on';
    const r = await window.desknest.setAutostart(on);
    if (r && r.ok) {
      renderAutostart(r.openAtLogin);
      window.desknest.saveConfig({ autostart: r.openAtLogin });
    }
  });

  // —— ★「隐藏桌面」开关（默认关 = 显示图标）——
  // 切换：先发原生 desktop-icons show|hide（幂等：原生查 SysListView32 实际状态，
  // 只在需要时 toggle——用户在桌面右键手动切换造成的漂移也会被纠正），
  // 再 saveConfig({hideDesktop}) 持久化；启动时原生按 config 重新应用。
  function renderHidedesk(hidden) {
    [...hidedeskSeg.children].forEach((b) => b.classList.toggle('on', (b.dataset.hidedeskOpt === 'on') === !!hidden));
  }
  hidedeskSeg.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const hide = btn.dataset.hidedeskOpt === 'on';
    renderHidedesk(hide);
    window.desknest.setDesktopIcons(!hide);
    window.desknest.saveConfig({ hideDesktop: hide });
  });

  // —— ★ v1.32.8「统计」开关（config.stats_enabled，默认开）——
  // 原生统计线程每次发送前重读 config.json，切换立即生效（无需重启）
  function renderStats(on) {
    [...statsSeg.children].forEach((b) => b.classList.toggle('on', (b.dataset.statsOpt === 'on') === !!on));
  }
  statsSeg.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const on = btn.dataset.statsOpt === 'on';
    renderStats(on);
    window.desknest.saveConfig({ stats_enabled: on });
  });

  // —— ★ v1.32.8 反馈/赞助入口：config 配置了 URL 才显示（避免开箱硬编码外部链接）——
  //   config.json 加 "feedback_url": "https://…问卷…" / "sponsor_url": "https://…爱发电…"
  function renderLinks(cfg) {
    const hasFb = !!(cfg.feedback_url && String(cfg.feedback_url).trim());
    const hasSp = !!(cfg.sponsor_url && String(cfg.sponsor_url).trim());
    if (linksRow) linksRow.hidden = !(hasFb || hasSp);
    if (fbBtn) fbBtn.hidden = !hasFb;
    if (sponsorBtn) sponsorBtn.hidden = !hasSp;
  }
  if (fbBtn) fbBtn.addEventListener('click', () => {
    try { window.desknest.openUrl(config.feedback_url); } catch (e) { /* ignore */ }
  });
  if (sponsorBtn) sponsorBtn.addEventListener('click', () => {
    try { window.desknest.openUrl(config.sponsor_url); } catch (e) { /* ignore */ }
  });

  const debouncedSave = debounce((patch) => window.desknest.saveConfig(patch), 250);

  rngHeight.addEventListener('input', () => {
    config.dockHeight = +rngHeight.value;
    applyVars(config);
    debouncedSave({ dockHeight: config.dockHeight });
  });
  rngOpacity.addEventListener('input', () => {
    config.opacity = +rngOpacity.value / 100;
    applyVars(config);
    debouncedSave({ opacity: config.opacity });
  });
  rngIcon.addEventListener('input', () => {
    config.iconSize = +rngIcon.value;
    applyVars(config);
    debouncedSave({ iconSize: config.iconSize });
  });

  rescanBtn.addEventListener('click', async () => {
    rescanBtn.textContent = '⟳ 扫描中…';
    const cats = await window.desknest.rescan();
    // ★ v1.33.10 兜底：原生重扫已写盘，但回传可能迟到/被吞 —— 主动再拉一次磁盘最新数据，
    //   保证页面内存与磁盘一致（否则「桌面新文件监控」会拿旧内存把已归类的文件
    //   当成新文件塞回「其他」并覆盖原生分类结果）
    let finalCats = cats;
    if (!Array.isArray(finalCats) || !finalCats.length) {
      finalCats = await window.desknest.refreshCategories();
    }
    // 容错：重扫失败/超时返回 null 时保留当前分类，绝不清空坞条
    if (Array.isArray(finalCats) && finalCats.length) {
      window.Dock.setCategories(finalCats);
      window.Dock.syncRenames();          // ★ 重扫数据是新对象，重新套用自定义显示名
      window.Dock.applyRenames();
      rescanBtn.textContent = '⟳ 重扫';
    } else {
      // ★ 超时 ≠ 失败：原生仍在处理，迟到回传会经 __onCatsRefresh 自动刷新界面
      rescanBtn.textContent = '扫描较慢…';
      setTimeout(() => { rescanBtn.textContent = '⟳ 重扫'; }, 2000);
    }
  });

  catsBtn.addEventListener('click', () => {
    window.Settings.close();
    window.Cats.open();
  });

  function debounce(fn, ms) {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  }

  function open() {
    // ★ 菜单互斥：设置面板展开时收起分类面板与搜索条（同一时间只留一个浮层）
    if (window.Dock) window.Dock.closeAll();
    if (window.Search) window.Search.close();
    bar.hidden = false;
    window.DeskUI.reportShapeSoon(220);
  }

  function close() {
    bar.hidden = true;
    // ★ v1.39.x 退出设置时自动收起「更多设置」展开层并复位折叠头文案，
    //   下次打开从收起态开始。close 是唯一退出汇点（ESC / 再点芯片 /
    //   打开其它浮层 / 分类管理按钮均经此），改一处覆盖全部退出路径。
    if (moreFold && !moreFold.hidden) {
      moreFold.hidden = true;
      if (moreBtn) moreBtn.textContent = '更多设置 ▾';
    }
    window.DeskUI.reportShapeSoon();
  }

  function init(cfg) {
    config = cfg;
    rngHeight.value = cfg.dockHeight;
    rngOpacity.value = Math.round(cfg.opacity * 100);
    rngIcon.value = cfg.iconSize;
    hotkeyBtn.textContent = ((cfg._activeHotkey || cfg.hotkey || 'Control+Alt+D')).replace(/^Control/, 'Ctrl').replace(/^Super/, 'Win');
    [...themeSeg.children].forEach((b) => b.classList.toggle('on', b.dataset.themeOpt === cfg.theme));
    [...labelSeg.children].forEach((b) => b.classList.toggle('on', (b.dataset.labelOpt === 'on') === (cfg.showLabels !== false)));
    [...glassSeg.children].forEach((b) => b.classList.toggle('on', (b.dataset.glassOpt === 'on') === (cfg.glass !== false)));
    renderHidedesk(!!cfg.hideDesktop);      // 「隐藏桌面」开关状态回显
    renderStats(cfg.stats_enabled !== false); // 「统计」开关回显（默认开）
    renderLinks(cfg);                       // 反馈/赞助入口（配置了 URL 才显示）
    applyTheme(cfg.theme);
    applyFlags(cfg);
    applyVars(cfg);
    // ★ 滑杆值徽标初始值（v1.39.0 起统一走 fmtVal：px 带单位、底色 0~100% 归一化）
    const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    setVal('rng-height-val', fmtVal('rng-height', cfg.dockHeight));
    setVal('rng-opacity-val', fmtVal('rng-opacity', rngOpacity.value));
    setVal('rng-icon-val', fmtVal('rng-icon', cfg.iconSize));
    // 关于区块：填充版本号
    window.desknest.systemInfo().then((si) => {
      const el = document.getElementById('about-ver');
      if (el) el.textContent = 'v' + (si.appVersion || '?');
    }).catch(() => { /* ignore */ });
  }

  // ── ★ v1.38.0 检查更新 ──
  function verNewer(a, b) {
    const pa = String(a || '').split('.').map((x) => parseInt(x, 10) || 0);
    const pb = String(b || '').split('.').map((x) => parseInt(x, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const d = (pa[i] || 0) - (pb[i] || 0);
      if (d) return d > 0;
    }
    return false;
  }
  window.__onUpdateInfo = (jsonText) => {
    let info = null;
    try { info = JSON.parse(jsonText); } catch (e) { /* ignore */ }
    const restore = () => { if (updBtn) updBtn.textContent = '⟳ 检查更新'; };
    if (!info || !info.version) {
      restore();
      if (!updSilent && window.Menu && window.Menu.ask) window.Menu.ask('检查更新', '更新服务器暂时无法访问', '好的', () => {});
      return;
    }
    const cur = String(window.__SHELL_VERSION || '');
    restore();
    if (verNewer(info.version, cur)) {
      if (window.Menu && window.Menu.ask) window.Menu.ask(`发现新版本 v${info.version}`,
        `当前版本 v${cur}${info.notes ? '\n\n' + info.notes : ''}\n\n前往下载页面获取新版？`, '前往下载', () => {
          try { window.desknest.launch({ path: info.url || 'https://afdian.com/a/desknest' }); } catch (e) { /* ignore */ }
        });
    } else if (!updSilent) {
      if (window.Menu && window.Menu.ask) window.Menu.ask('已是最新版本', `当前 v${cur} 已是最新。`, '好的', () => {});
    }
  };
  window.__onUpdateInfoErr = (msg) => {
    if (updBtn) updBtn.textContent = '⟳ 检查更新';
    if (!updSilent && window.Menu && window.Menu.ask) window.Menu.ask('检查更新', msg || '网络异常', '好的', () => {});
  };
  function doCheckUpdate(silent) {
    updSilent = !!silent;
    if (updBtn) updBtn.textContent = '⟳ 检查中…';
    try { window.desknest.checkUpdate(); } catch (e) {
      if (updBtn) updBtn.textContent = '⟳ 检查更新';
    }
  }
  if (updBtn) updBtn.addEventListener('click', (e) => { e.stopPropagation(); doCheckUpdate(false); });

  // ── ★ v1.39.0 「更多设置」折叠组 ──
  // 五个带按钮的设置项（快捷键/检查更新/分类管理/重扫/反馈·赞助）收纳进同一抽屉；
  // 展开/收起改变面板高度，必须 reportShapeSoon 让原生更新浮层保持域（否则
  // 展开后鼠标在面板下半区会被判为「坞条外」触发自动隐藏）
  if (moreBtn && moreFold) moreBtn.addEventListener('click', () => {
    moreFold.hidden = !moreFold.hidden;
    moreBtn.textContent = moreFold.hidden ? '更多设置 ▾' : '收起 ▴';
    window.DeskUI.reportShapeSoon(220);
  });

  // ── ★ v1.39.0 数值徽标统一格式（单一来源，init 与拖动共用）──
  // 高度/图标：px 实际值；底色：按滑杆可调区间归一化为 0~100%。
  // 修复：此前底色徽标直接显示 opacity 百分数（如 55%），而视觉深浅是
  // (v-0.4)/0.55 归一化后映射到 alpha 0.14~0.68 —— 用户看到的"55%"实际
  // 只有 ~29% 实度，即「未按 100% 的比例正确显示」。现在徽标 = 区间占比：
  // 滑杆最左 0%（最透）、最右 100%（最实），与视觉比例一致。
  function fmtVal(rid, v) {
    if (rid === 'rng-opacity') {
      const r = document.getElementById(rid);
      if (r) {
        const min = +r.min, max = +r.max;
        return Math.round(((v - min) / (max - min)) * 100) + '%';
      }
      return v + '%';
    }
    return v + 'px';
  }

  // 滑杆当前值徽标（拖动实时刷新）
  [['rng-height-val', 'rng-height'], ['rng-opacity-val', 'rng-opacity'], ['rng-icon-val', 'rng-icon']]
    .forEach(([vid, rid]) => {
      const r = document.getElementById(rid);
      if (!r) return;
      r.addEventListener('input', () => {
        const el = document.getElementById(vid);
        if (el) el.textContent = fmtVal(rid, r.value);
      });
    });

  return { init, open, close, applyVars, applyTheme, applyFlags, checkUpdate: (silent) => doCheckUpdate(silent) };
})();
