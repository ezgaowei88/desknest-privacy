// bookmarks.js：书签面板 —— 常用（按使用频率自动统计）+ 全部列表 + 增删改 + 置顶
//   v1.24.6 扩展：
//   ① 管理器模式（#bm-head「管理」）：文件夹增删改名、书签整理（移入/移出文件夹）、
//      编辑/删除/刷新图标，导入/导出按钮仅管理模式显示
//   ② 文件夹：folders=[{id,name}]，bookmark.folder=文件夹 id（0=根级）
//   ③ favicon：添加/编辑时原生 WinHTTP 抓取（bm-fav → data\favicons\<id>.png），
//      desknest-icon:// 协议显示；离线/无图标回退首字母头像
//   v1.26.0 扩展：
//   ⑤ 导入/导出多格式：JSON + 浏览器通用 Netscape HTML（Chrome/Edge/Firefox 导出格式）
//      + CSV（name,url,folder）；原生按扩展名识别格式回发 bookmarks-import <fmt> <内容>；
//      导出页面生成标准文本（HTML 严格 NETSCAPE-Bookmark-file-1，CSV 带 BOM）
//   ⑥ Edge/Chrome 同步：原生读取浏览器 Bookmarks 文件（Default 优先）→ 同步前自动
//      备份（bookmarks-backup-<ts>.json 保留5份）→ 页面解析 Chrome 格式 → 合并去重
//      （url 相同同名跳过）；同名不同址 = 冲突，管理器顶部逐条/批量选择
//      「用浏览器版 / 保留现有」，绝不直接覆盖
// 数据：window.__BOOKMARKS 兼容两种形态——旧：顶层数组；新：{bookmarks:[…], folders:[…]}
//   （读写统一用新对象格式，原生 save/load 均兼容，原子写 bookmarks.json）
'use strict';

window.Bookmarks = (() => {
  let list = [];      // 书签数组
  // ★ 单色线性 SVG 图标（currentColor，与右键菜单图标同风格）
  const BIC = {
    refresh: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11.5a8 8 0 1 0-.9 4.6"/><path d="M20 4.5v6h-6"/></svg>',
    sync: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h9.5a5.5 5.5 0 0 1 0 11H8"/><path d="M7 5.5 3.5 9 7 12.5"/><path d="M20 15h-9.5"/></svg>',
    folderOpen: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 6.5a1.5 1.5 0 0 1 1.5-1.5h4l2 2.5h7.5a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5z"/><path d="M14 11.5h6.5l-1.8 5.2a1.5 1.5 0 0 1-1.4 1H5"/></svg>',
    folderPlus: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 6.5a1.5 1.5 0 0 1 1.5-1.5h4l2 2.5h7.5a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5z"/><path d="M12 11v5M9.5 13.5h5"/></svg>',
    folder: '<svg viewBox="0 0 24 24" class="svg-ic" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 6.5a1.5 1.5 0 0 1 1.5-1.5h4l2 2.5h7.5a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5z"/></svg>'
  };
  let expandedFolders = new Set();  // ★ 文件夹默认折叠，仅记录展开者
  let bmDrag = null;                 // ★ 常规模式：拖拽排序状态
  let folders = [];   // 文件夹数组 [{id,name}]
  let open = false;
  let manage = false;      // 管理器模式
  let editingId = null;    // 正在行内编辑的书签 id
  let editingFolder = null;// 正在行内改名的文件夹 id
  let adding = false;      // 正在添加书签（表单展开中）
  let addingFolder = false;// 正在新建文件夹
  let pickFor = null;      // 正在选择目标文件夹的书签 id（行内移动菜单）
  let pickFolder = 0;      // 新建书签时选定的目标文件夹
  let pendingConflicts = []; // 同步冲突 [{inc:{name,url,folder}, cur:bookmark}]
  let fmtOpen = false;     // 导出格式选择器展开
  let query = '';          // ★ v1.33.10 搜索关键字（名称/网址，实时过滤）

  // 搜索命中：名称或网址包含关键字（小写比较）
  function matchQ(b) {
    if (!query) return true;
    const q = query.toLowerCase();
    return String(b.name || '').toLowerCase().includes(q)
      || String(b.url || '').toLowerCase().includes(q);
  }
  // 列表过滤 + 搜索过滤（文件夹/根目录/常用区统一走这里）
  function inFolderQ(fid) {
    return inFolder(fid).filter(matchQ);
  }

  const panel = document.getElementById('bm-panel');
  const body = document.getElementById('bm-body');
  const qEl = document.getElementById('bm-q');     // ★ 搜索框（v1.33.10）
  const toolbar = document.getElementById('bm-toolbar');
  const btn = document.getElementById('bm-btn');
  const addBtn = document.getElementById('bm-add');
  const manageBtn = document.getElementById('bm-manage');
  const importBtn = document.getElementById('bm-import');
  const exportBtn = document.getElementById('bm-export');
  const mirrorBtn = document.getElementById('bm-mirror');   // ★ v1.35.4 镜像同步开关
  // 镜像同步：开启后以浏览器为准——浏览器里删除的书签在下次同步时从本地一并删除
  let mirrorSync = !!(window.__CONFIG && window.__CONFIG.bmMirrorSync);

  // ★ v1.39.x 自动同步源（用户要求：默认仅自动同步 Chrome，不再自动同步多浏览器）——
  //   其他浏览器的书签只有在用户手动点过其「同步 X」按钮（registerSource 写入
  //   config.bmAutoSources）后才纳入自动跟随（泵监听 + 启动对齐）。
  //   Chrome 恒为默认源，不需要也不允许被移出（手动点「同步 Chrome」是幂等登记）。
  function autoSources() {
    const arr = (window.__CONFIG && Array.isArray(window.__CONFIG.bmAutoSources))
      ? window.__CONFIG.bmAutoSources : null;
    const out = (arr || ['chrome'])
      .map((s) => String(s || '').trim().toLowerCase()).filter(Boolean);
    if (!out.includes('chrome')) out.unshift('chrome');   // Chrome 恒在
    return out;
  }
  function registerSource(key) {
    const k = String(key || '').trim().toLowerCase();
    if (!k || k === 'chrome') return;                     // 默认源，无需登记
    const cur = autoSources();
    if (cur.includes(k)) return;
    const next = cur.concat(k);
    try {
      window.__CONFIG = window.__CONFIG || {};
      window.__CONFIG.bmAutoSources = next;               // 页面内存即时生效
      window.desknest.saveConfig({ bmAutoSources: next }); // 磁盘持久化（原生按此监听）
    } catch (e) { /* ignore */ }
  }
  const capSrc = (k) => (k ? k.charAt(0).toUpperCase() + k.slice(1) : k);

  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // —— 数据迁移与持久化 ——

  function ingest(raw) {
    if (Array.isArray(raw)) {
      list = raw.slice();
      folders = [];
    } else if (raw && Array.isArray(raw.bookmarks)) {
      list = raw.bookmarks.slice();
      folders = Array.isArray(raw.folders) ? raw.folders.slice() : [];
    } else {
      list = [];
      folders = [];
    }
    list.forEach((b) => { if (b.folder == null) b.folder = 0; });
  }
  ingest(window.__BOOKMARKS);

  function save() {
    window.desknest.saveBookmarks({ bookmarks: list, folders });
  }

  // 常用排序：置顶 > 使用次数 > 最近使用
  function freqList() {
    return list
      .filter((b) => b.pinned || (b.count || 0) > 0)
      .slice()
      .sort((a, b) =>
        (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) ||
        (b.count || 0) - (a.count || 0) ||
        (b.lastUsed || 0) - (a.lastUsed || 0))
      .slice(0, 5);
  }

  const inFolder = (fid) => list.filter((b) => String(b.folder) === String(fid));

  // —— 渲染 ——

  function favHTML(b) {
    if (b.icon) {
      return `<img class="bm-fav" src="desknest-icon://local/${encodeURIComponent(b.icon)}" alt="">`;
    }
    const ch = (String(b.name || '').trim().charAt(0) || '?').toUpperCase();
    return `<span class="bm-fav bm-fav-letter">${esc(ch)}</span>`;
  }

  function rowHTML(b, opts) {
    const freqMode = !!(opts && opts.freqMode);
    const isManage = !!(opts && opts.manage);
    const pin = b.pinned ? ' pinned' : '';
    const acts = isManage
      ? `<button data-act="pin" title="${b.pinned ? '取消置顶' : '置顶常用'}">📌</button>` +
        `<button data-act="edit" title="编辑">✎</button>` +
        `<button data-act="del" title="删除">🗑</button>`
      : `<button data-act="pin" title="${b.pinned ? '取消置顶' : '置顶常用'}">📌</button>` +
        `<button data-act="edit" title="编辑">✎</button>` +
        `<button data-act="del" title="删除">🗑</button>`;
    const tip = esc(`${b.name}\n${b.url}`);
    // ★ 结构：bm-item（悬停载体）> bm-row（第一行：图标+名称+操作）+ bm-url（第二行网址，
    //   默认 max-height:0 折叠，悬停在标题下方平滑展开，移开恢复单行）
    return `<div class="bm-item${pin}${isManage ? ' mg' : ''}" data-id="${b.id}" title="${tip}">` +
      `<div class="bm-row">` +
      favHTML(b) +
      `<span class="bm-name" title="${esc(b.name)}">${esc(b.name)}</span>` +
      `<span class="bm-act">${acts}</span>` +
      `</div>` +
      `<div class="bm-url" title="${esc(b.url)}">${esc(b.url)}</div>` +
      `</div>`;
  }

  // 行内移动菜单：列出根目录 + 全部文件夹（排除当前位置）
  function movePickerHTML(b) {
    const cur = String(b.folder || 0);
    const opts = [{ id: 0, name: '根目录' }].concat(folders)
      .filter((f) => String(f.id) !== cur)
      .map((f) => `<button class="bm-mv-item" data-act="moveto" data-fid="${f.id}">${f.id ? '📁' : '⌂'} ${esc(f.name)}</button>`)
      .join('');
    return `<div class="bm-mv" data-mv="${b.id}"><span class="bm-mv-title">移动「${esc(b.name)}」到：</span>${opts || '<span class="bm-mv-title">（无其他位置）</span>'}<button class="bm-mv-item" data-act="mvclose">取消</button></div>`;
  }

  function formHTML(b) {
    const name = b ? esc(b.name) : '';
    const url = b ? esc(b.url) : '';
    const curF = b ? String(b.folder || 0) : String(pickFolder || 0);
    const fOpts = [{ id: 0, name: '根目录' }].concat(folders)
      .map((f) => `<option value="${f.id}"${String(f.id) === String(curF) ? ' selected' : ''}>${esc(f.name)}</option>`)
      .join('');
    return `<div class="bm-form" data-id="${b ? b.id : ''}">` +
      `<input class="bm-f-name" type="text" placeholder="名称" value="${name}" spellcheck="false">` +
      `<input class="bm-f-url" type="text" placeholder="网址或路径（https://…）" value="${url}" spellcheck="false">` +
      `<select class="bm-f-folder" title="所属文件夹">${fOpts}</select>` +
      `<div class="bm-form-btns">` +
      `<button class="bm-cancel">取消</button>` +
      `<button class="bm-save primary">保存</button>` +
      `</div></div>`;
  }

  function folderRowHTML(f) {
    const n = inFolder(f.id).length;
    if (String(editingFolder) === String(f.id)) {
      return `<div class="bm-folder-row editing" data-fid="${f.id}">` +
        `<input class="bm-fr-name" type="text" value="${esc(f.name)}" spellcheck="false">` +
        `<span class="bm-act">` +
        `<button data-act="frename-ok" title="保存">✓</button>` +
        `<button data-act="frename-no" title="取消">✕</button>` +
        `</span></div>`;
    }
    const folded = !expandedFolders.has(String(f.id));
    return `<div class="bm-folder-row${folded ? ' folded' : ''}" data-fid="${f.id}">` +
      `<span class="bm-fold">${folded ? '▶' : '▼'}</span>` +
      `<span class="bm-folder-ic">${BIC.folder}</span>` +
      `<span class="bm-name">${esc(f.name)}</span>` +
      `<span class="bm-count">${n}</span>` +
      `<span class="bm-act">` +
      `<button data-act="frename" title="重命名文件夹">✎</button>` +
      `<button data-act="fdel" title="删除文件夹（书签移回根目录）">🗑</button>` +
      `</span></div>`;
  }

  function render() {
    if (!open) return;
    let html = '';
    if (manage) {
      // —— 管理器模式：文件夹分组 + 根级书签 + 整理操作 ——
      // ★ 工具条（提示/同步按钮/导出选择器）渲染到独立容器 bm-toolbar，
      //   不随书签内容滚动 —— 滑条与按钮之间保持距离，滑条也不再贴着按钮
      let thtml = `<div class="bm-mg-tip">点书签名打开 · ↻ 刷新图标</div>`;
      thtml += `<div class="bm-sync-row">` +
        `<button class="bm-tb" data-act="refresh-all" title="对所有书签重新获取网站图标；失败者保持占位头像">${BIC.refresh}刷新图标</button>` +
        `<button class="bm-tb" data-act="sync-edge" title="读取 Edge 书签，合并去重（同步前自动备份）；同步后 Edge 纳入自动跟随范围">${BIC.sync}同步 Edge</button>` +
        `<button class="bm-tb" data-act="sync-chrome" title="读取 Chrome 书签，合并去重（同步前自动备份）">${BIC.sync}同步 Chrome</button>` +
        `<button class="bm-tb" data-act="sync-file" title="选择任意浏览器/数据目录，自动定位其中的 Bookmarks 文件同步">${BIC.folderOpen}自选浏览器</button>` +
        `</div>`;
      if (fmtOpen) {
        thtml += `<div class="bm-fmt"><span class="bm-mv-title">导出为：</span>` +
          `<button class="bm-mv-item" data-act="exp-json">JSON</button>` +
          `<button class="bm-mv-item" data-act="exp-html" title="Chrome/Edge/Firefox 可直接导入的 Netscape 格式">HTML（浏览器通用）</button>` +
          `<button class="bm-mv-item" data-act="exp-csv">CSV</button>` +
          `<button class="bm-mv-item" data-act="exp-cancel">取消</button></div>`;
      }
      toolbar.innerHTML = thtml;
      // 同步冲突（同名不同址）：逐条或批量解决，绝不静默覆盖
      if (pendingConflicts.length) {
        html += `<div class="bm-conf-head"><span>⚠ 同步冲突（${pendingConflicts.length}）——同一网址在浏览器与本地名称不同</span>` +
          `<button class="bm-tb" data-act="conf-all-in">全部用浏览器版</button>` +
          `<button class="bm-tb" data-act="conf-all-keep">全部保留现有</button></div>`;
        pendingConflicts.forEach((c, i) => {
          html += `<div class="bm-conf-row">` +
            `<span class="bm-conf-txt">浏览器：<b>${esc(c.inc.name)}</b><br>` +
            `<span class="bm-url">${esc(c.inc.url)}</span><br>现有：<b>${esc(c.cur.name)}</b></span>` +
            `<span class="bm-act" style="display:flex">` +
            `<button data-act="conf-in" data-ci="${i}" title="名称与归档采用浏览器版本">用浏览器版</button>` +
            `<button data-act="conf-keep" data-ci="${i}" title="保留本地的名称与归档">保留现有</button>` +
            `</span></div>`;
        });
      }
      if (addingFolder) {
        html += `<div class="bm-form"><input class="bm-ff-name" type="text" placeholder="文件夹名称" spellcheck="false">` +
          `<div class="bm-form-btns"><button class="bm-cancel">取消</button><button class="bm-ff-ok primary">创建</button></div></div>`;
      } else {
        html += `<button class="bm-newfolder" data-act="newfolder">${BIC.folderPlus}新建文件夹</button>`;
      }
      for (const f of folders) {
        const fb = inFolderQ(f.id);
        if (query && fb.length === 0) continue;             // 搜索时隐藏无匹配的文件夹
        html += folderRowHTML(f);
        // 管理模式：有搜索关键字时视为展开（让用户直接看到搜到的条目）
        const expanded = expandedFolders.has(String(f.id)) || (!!query && fb.length > 0);
        if (!expanded) continue;                            // ★ 默认折叠：不渲染书签
        for (const b of fb) {
          if (b.id === editingId) { html += formHTML(b); continue; }
          html += rowHTML(b, { manage: true });
          if (pickFor != null && String(pickFor) === String(b.id)) html += movePickerHTML(b);
        }
      }
      const roots = inFolderQ(0);
      if (roots.length || folders.length === 0) {
        html += `<div class="bm-sec">根目录</div>`;
        for (const b of roots) {
          if (b.id === editingId) { html += formHTML(b); continue; }
          html += rowHTML(b, { manage: true });
          if (pickFor != null && String(pickFor) === String(b.id)) html += movePickerHTML(b);
        }
        if (roots.length === 0 && folders.length === 0 && !adding && !addingFolder) {
          html += `<div class="bm-empty">暂无书签<br>点击右上 ＋ 添加常用网址</div>`;
        }
      }
      } else {
      toolbar.innerHTML = '';
      // —— 常规模式：常用 + 各级文件夹（可折叠）+ 根目录 ——
      const freq = freqList().filter(matchQ);
      let shown = 0;                       // 本次实际渲染出的条目数（用于"无匹配"提示）
      if (list.length === 0 && !adding) {
        html = `<div class="bm-empty">暂无书签<br>点击右上 ＋ 添加常用网址</div>`;
      } else {
        if (freq.length && !adding && editingId == null) {
          html += `<div class="bm-sec">常用</div>`;
          for (const b of freq) html += rowHTML(b, { freqMode: true });
          shown += freq.length;
        }
        // ★ 各级文件夹分组展示（点文件夹行折叠/展开，与管理器一致）
        if (folders.length && !adding && editingId == null) {
          for (const f of folders) {
            const fb = inFolderQ(f.id);
            if (query && fb.length === 0) continue;         // 搜索时隐藏无匹配的文件夹
            html += folderRowHTML(f);
            // 搜索时自动展开有匹配的文件夹，让用户直接看到结果
            if (!expandedFolders.has(String(f.id)) && !(query && fb.length > 0)) continue;
            for (const b of fb) {
              if (b.id === editingId) { html += formHTML(b); continue; }
              html += rowHTML(b, {});
              shown++;
            }
          }
        }
        const roots = inFolderQ(0);
        if (!adding && editingId == null && (roots.length || !query)) html += `<div class="bm-sec">全部</div>`;
        for (const b of roots) {
          if (b.id === editingId) { html += formHTML(b); continue; }
          html += rowHTML(b, {});
          shown++;
        }
        // 「全部」节容纳根级之外的历史顺序（保持旧列表语义：无文件夹的旧数据全在根）
        const rootIds = new Set(roots.map((b) => String(b.id)));
        for (const b of list) {
          if (rootIds.has(String(b.id))) continue;
          if (folders.some((f) => String(b.folder) === String(f.id))) continue;
          if (!matchQ(b)) continue;
          if (b.id === editingId) { html += formHTML(b); continue; }
          html += rowHTML(b, {});
          shown++;
        }
        // 搜索无结果：明确提示（避免「我同步了却找不到」的困惑）
        if (query && shown === 0 && !adding && editingId == null) {
          html += `<div class="bm-empty">没有匹配「${esc(query)}」的书签</div>`;
        }
        if (adding) html += formHTML(null);
      }
      }
    body.innerHTML = html;
    syncHead();
    wire();
    wireDrag();
  }

  // —— ★ v1.31 拖拽调整书签顺序（常规模式；按下 6px 起拖，落点插入）——
  let dragWired = false;
  function wireDrag() {
    if (dragWired) return;
    dragWired = true;
    body.addEventListener('mousedown', (e) => {
      if (adding || editingId != null || pickFor != null) return;
      if (e.button !== 0) return;
      // ★ 条目载体 = .bm-item（data-id 在其上；.bm-row 是内部首行）
      const el0 = e.target.closest('.bm-item');
      if (!el0 || e.target.closest('.bm-act') || e.target.closest('button')) return;
      const item = list.find((x) => String(x.id) === String(el0.dataset.id));
      if (!item) return;
      bmDrag = { item, x0: e.clientX, y0: e.clientY, active: false, ghost: null };
      const onMove = (ev) => {
        if (!bmDrag) return;
        if (!bmDrag.active) {
          if (Math.abs(ev.clientX - bmDrag.x0) + Math.abs(ev.clientY - bmDrag.y0) < 6) return;
          bmDrag.active = true;
          const srcRow = document.querySelector(`.bm-item[data-id="${item.id}"]`);
          const g = srcRow.cloneNode(true);
          g.classList.add('bm-ghost');
          g.style.width = srcRow.getBoundingClientRect().width + 'px';
          document.body.appendChild(g);
          bmDrag.ghost = g;
          document.querySelectorAll(`.bm-item[data-id="${item.id}"]`).forEach((r) => r.classList.add('bm-dim'));
        }
        bmDrag.ghost.style.left = (ev.clientX + 10) + 'px';
        bmDrag.ghost.style.top = (ev.clientY - 14) + 'px';
      };
      const onUp = (ev) => {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
        window.__onUpFired = { at: [ev.clientX, ev.clientY], active: bmDrag ? bmDrag.active : null };
        const dg = bmDrag;
        bmDrag = null;
        document.querySelectorAll('.bm-ghost').forEach((g) => g.remove());
        document.querySelectorAll('.bm-dim').forEach((r) => r.classList.remove('bm-dim'));
        if (!dg || !dg.active) return;
        const under = document.elementFromPoint(ev.clientX, ev.clientY);
        const titem = under && under.closest ? under.closest('.bm-item') : null;
        if (!titem || titem === el0) { render(); return; }
        const fromIdx = list.findIndex((x) => String(x.id) === String(dg.item.id));
        const toIdx = list.findIndex((x) => String(x.id) === String(titem.dataset.id));
        if (fromIdx < 0 || toIdx < 0 || fromIdx === toIdx) { render(); return; }
        // ★ 管理页：仅同文件夹（或同为根级）内重排；跨文件夹用 ⇆ 移动，拖拽忽略
        if (String(dg.item.folder || 0) !== String(list[toIdx].folder || 0)) { render(); return; }
        const tr = titem.getBoundingClientRect();
        let insert = toIdx + (ev.clientY > tr.top + tr.height / 2 ? 1 : 0);
        if (fromIdx < insert) insert -= 1;
        const [movedItem] = list.splice(fromIdx, 1);
        list.splice(insert, 0, movedItem);
        save(); render();
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    });
  }

  function syncHead() {
    manageBtn.textContent = manage ? '完成' : '管理';
    importBtn.hidden = !manage;
    exportBtn.hidden = !manage;
    addBtn.title = manage ? '新建文件夹' : '添加书签';
    // ★ v1.35.4 镜像开关状态可视（开=翡翠绿高亮，与 --accent 一致）
    mirrorBtn.textContent = mirrorSync ? '镜像:开' : '镜像:关';
    mirrorBtn.classList.toggle('on', mirrorSync);
  }

  // —— favicon ——

  function requestFav(b) {
    if (!b || !b.url || !/^[a-z]+:\/\//i.test(b.url)) return;
    try { window.desknest.requestFavicon(b.id, b.url); } catch (e) { /* ignore */ }
  }

  // 原生下载完成回执：bm-fav <id> <png路径>
  window.__onFavicon = (id, path) => {
    const b = list.find((x) => String(x.id) === String(id));
    if (!b || !path) return;
    b.icon = path;
    save();
    if (open) render();
  };

  // —— 多格式导入 / 导出 / 浏览器同步 ——

  const escHTML = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const folderNameOf = (fid) => (folders.find((f) => String(f.id) === String(fid)) || {}).name || '';

  // 导出文本生成（页面生成标准文本，原生仅负责写盘）
  function genJSON() {
    return JSON.stringify({ bookmarks: list, folders }, null, 2);
  }
  function genHTML() {
    const ts = Math.floor(Date.now() / 1000);
    let out = '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n' +
      '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n' +
      '<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n';
    for (const f of folders) {
      out += `    <DT><H3 ADD_DATE="${ts}" LAST_MODIFIED="${ts}">${escHTML(f.name)}</H3>\n    <DL><p>\n`;
      for (const b of inFolder(f.id)) {
        out += `        <DT><A HREF="${escHTML(b.url)}" ADD_DATE="${ts}">${escHTML(b.name)}</A>\n`;
      }
      out += '    </DL><p>\n';
    }
    for (const b of inFolder(0)) {
      out += `    <DT><A HREF="${escHTML(b.url)}" ADD_DATE="${ts}">${escHTML(b.name)}</A>\n`;
    }
    out += '</DL><p>\n';
    return out;
  }
  function genCSV() {
    const q = (s) => `"${String(s == null ? '' : s).replace(/"/g, '""')}"`;
    let out = '\uFEFFname,url,folder\r\n';   // BOM：Excel 直接打开不乱码
    for (const b of list) {
      out += q(b.name) + ',' + q(b.url) + ',' + q(b.folder ? folderNameOf(b.folder) : '') + '\r\n';
    }
    return out;
  }

  // Netscape HTML 解析（Chrome/Edge/Firefox 导出格式；属性带引号/不带引号均容错）
  function parseBookmarkHTML(text) {
    const out = { bookmarks: [], folders: [] };
    let fseq = 0;   // ★ 解析期临时 id 用负数序列：同一毫秒内 Date.now 会撞号
    const idOf = (name) => {
      name = (name || '').trim() || '未命名';
      let f = out.folders.find((x) => x.name === name);
      if (!f) { f = { id: -(++fseq), name }; out.folders.push(f); }
      return f.id;
    };
    const attr = (tag, name) => {
      const m = tag.match(new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i')) ||
                tag.match(new RegExp(name + '\\s*=\\s*([^\\s>]+)', 'i'));
      return m ? m[1] : '';
    };
    const stack = [0];   // 文件夹 id 栈；0 = 根目录
    const re = /<DT><H3\b([^>]*)>([\s\S]*?)<\/H3>|<DT><A\b([^>]*)>([\s\S]*?)(?:<\/A>|(?=<DT)|(?=<\/DL)|(?=<P)|$)|<DL\b[^>]*>|<\/DL/gi;
    let m, pending = null;
    while ((m = re.exec(text))) {
      const t = m[0].toLowerCase();
      if (t.startsWith('<dt><h3')) {
        pending = { name: (m[2] || '').replace(/<[^>]*>/g, '').trim() };
      } else if (t.startsWith('<dl')) {
        stack.push(pending ? idOf(pending.name) : stack[stack.length - 1]);
        pending = null;
      } else if (t.startsWith('</dl')) {
        pending = null;
        if (stack.length > 1) stack.pop();
      } else if (t.startsWith('<dt><a')) {
        const href = attr(m[3] || '', 'HREF');
        const name = (m[4] || '').replace(/<[^>]*>/g, '').trim();
        if (href) {
          const ad = parseInt(attr(m[3] || '', 'ADD_DATE'), 10);
          out.bookmarks.push({
            name: name || href, url: href, folder: stack[stack.length - 1],
            lastUsed: (ad > 1e9 && ad < 4e10) ? ad * 1000 : 0,
          });
        }
      }
    }
    return out;
  }

  // CSV 解析（支持引号内逗号/换行/转义引号；表头 name,url,folder 可选）
  function parseCSVRows(text) {
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    const rows = []; let row = [], cell = '', inQ = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (inQ) {
        if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else inQ = false; }
        else cell += ch;
      } else if (ch === '"') inQ = true;
      else if (ch === ',') { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && text[i + 1] === '\n') i++;
        row.push(cell); cell = '';
        if (row.length > 1 || row[0] !== '') rows.push(row);
        row = [];
      } else cell += ch;
    }
    if (cell !== '' || row.length) {
      row.push(cell);
      if (row.length > 1 || row[0] !== '') rows.push(row);
    }
    return rows;
  }
  function parseBookmarkCSV(text) {
    const rows = parseCSVRows(text);
    const out = { bookmarks: [], folders: [] };
    if (!rows.length) return out;
    let nameC = 0, urlC = 1, folderC = -1, start = 0;
    const head = rows[0].map((c) => c.trim().toLowerCase());
    if (head.includes('url')) {
      nameC = head.indexOf('name'); if (nameC < 0) nameC = 0;
      urlC = head.indexOf('url');
      folderC = head.indexOf('folder');
      start = 1;
    }
    let fseq = 0;
    const idOf = (name) => {
      name = (name || '').trim();
      if (!name) return 0;
      let f = out.folders.find((x) => x.name === name);
      if (!f) { f = { id: -(++fseq), name }; out.folders.push(f); }
      return f.id;
    };
    for (let i = start; i < rows.length; i++) {
      const r = rows[i];
      const url = (r[urlC] || '').trim();
      if (!url) continue;
      out.bookmarks.push({
        name: (r[nameC] || url).trim() || url, url,
        folder: folderC >= 0 ? idOf(r[folderC]) : 0,
      });
    }
    return out;
  }

  // Edge/Chrome Bookmarks 文件（Chrome JSON 格式）解析：书签栏 → 根目录
  function parseBrowserJSON(text) {
    const root = (JSON.parse(text).roots) || {};
    const out = { bookmarks: [], folders: [] };
    let fseq = 0;
    const idOf = (name) => {
      name = (name || '').trim() || '未命名';
      let f = out.folders.find((x) => x.name === name);
      if (!f) { f = { id: -(++fseq), name }; out.folders.push(f); }
      return f.id;
    };
    const walk = (node, fid) => {
      for (const ch of (node.children || [])) {
        if (ch.type === 'url' && ch.url) {
          out.bookmarks.push({ name: ch.name || ch.url, url: ch.url, folder: fid });
        } else if (ch.type === 'folder') {
          walk(ch, (ch.name || '').trim() ? idOf(ch.name) : fid);
        }
      }
    };
    if (root.bookmark_bar) walk(root.bookmark_bar, 0);
    for (const k of ['other', 'synced']) {
      if (root[k] && (root[k].children || []).length) walk(root[k], idOf(root[k].name || (k === 'other' ? '其他书签' : '移动设备书签')));
    }
    return out;
  }

  // 合并（url 为主键；文件夹按名称映射/新建；conflictMode=true 时同名不同址入冲突列表）
  // ★ v1.32.8：黑名单（window.__BM_REMOVED_URLS，原生注入 + 删除时同步维护）里的
  //   URL 一律跳过 —— 「删除书签 = 和电脑同步删除」，不会被下次同步/导入复活
  // ★ v1.35.4：mirrorMode=true（镜像同步）时黑名单让位——浏览器里重新出现的 URL
  //   视为用户明确想加回，正常导入并即时解除页面侧黑名单（磁盘侧由自清洁兜底）
  const removedUrls = new Set((window.__BM_REMOVED_URLS || []).map((u) => String(u || '').trim()));
  function mergeIncoming(inc, conflictMode, mirrorMode) {
    const incList = Array.isArray(inc) ? inc : (inc && Array.isArray(inc.bookmarks) ? inc.bookmarks : []);
    const incFolders = (!Array.isArray(inc) && Array.isArray(inc.folders)) ? inc.folders : [];
    let added = 0, skipped = 0, folderMoved = 0;
    const conflicts = [];
    const addedNames = [];
    const unlockedNames = [];   // 镜像模式解锁的黑名单条目名
    const nameToId = new Map(folders.map((f) => [f.name, f.id]));
    const idMap = new Map();
    for (const f of incFolders) {
      if (!f || !f.name) continue;
      if (nameToId.has(f.name)) { idMap.set(String(f.id), nameToId.get(f.name)); continue; }
      const nid = Date.now() + Math.floor(Math.random() * 100000) + folders.length;
      folders.push({ id: nid, name: f.name });
      nameToId.set(f.name, nid);
      idMap.set(String(f.id), nid);
    }
    const byUrl = new Map(list.map((b) => [b.url, b]));
    for (const b of incList) {
      if (!b || !b.url || !b.name) continue;
      const urlKey = String(b.url).trim();
      const blacklisted = removedUrls.has(urlKey);
      if (blacklisted && !mirrorMode) { skipped++; continue; }   // ★ 已删除不再导入
      const fid = b.folder ? (idMap.get(String(b.folder)) || 0) : 0;
      const ex = byUrl.get(b.url);
      if (ex) {
        const same = (ex.name || '').trim().toLowerCase() === (b.name || '').trim().toLowerCase();
        if (conflictMode && !same) conflicts.push({ inc: { name: b.name, url: b.url, folder: fid }, cur: ex });
        else skipped++;
        // ★ v1.39.0 已存在条目的文件夹归属跟随浏览器（只"入夹"、不强行拽回根层）：
        //   此前 ex 命中后直接 continue —— Chrome 后来才把 URL 挪进「办公」等文件夹时，
        //   本地早期同步的条目永远留在根层，用户看到"浏览器 25 个、文件夹里只剩 11 个"。
        //   现在浏览器说该 URL 属于某文件夹（fid≠0）而本地不在该夹 → 重新归入。
        if (fid && String(ex.folder) !== String(fid)) { ex.folder = fid; folderMoved++; }
        if (blacklisted && mirrorMode) removedUrls.delete(urlKey);   // 已在本地：仍解除黑名单
        continue;
      }
      byUrl.set(b.url, b);
      list.push({
        id: Date.now() + Math.floor(Math.random() * 1000000) + added,
        name: b.name, url: b.url, folder: fid,
        count: b.count || 0, lastUsed: b.lastUsed || 0,
        pinned: !!b.pinned, icon: b.icon || null,
      });
      added++;
      if (blacklisted && mirrorMode) {
        removedUrls.delete(urlKey);
        if (unlockedNames.length < 8) unlockedNames.push(b.name);
      }
      if (addedNames.length < 8) addedNames.push(b.name);   // 供完成提示回显，便于核对
    }
    save();
    return { added, skipped, conflicts, addedNames, unlockedNames, folderMoved };
  }

  // 原生导入文件回执：<fmt> <内容>
  window.__onBookmarksImport = (fmt, content) => {
    let inc;
    try {
      if (fmt === 'html') inc = parseBookmarkHTML(content);
      else if (fmt === 'csv') inc = parseBookmarkCSV(content);
      else inc = JSON.parse(content);
    } catch (e) { return; }
    const r = mergeIncoming(inc, false);
    if (open) render();
    try {
      if (window.Menu && window.Menu.ask) {
        window.Menu.ask('导入完成',
          `新增 ${r.added} 条书签${r.skipped ? `，跳过重复 ${r.skipped} 条` : ''}。`, '好的', () => {});
      }
    } catch (e) { /* ignore */ }
  };

  // 同步公共链路（手动同步与 v1.35.8 自动镜像共用）：
  //   镜像 diff（快照基线）→ 清理跟随 → 合并 → 快照保鲜
  //   auto=true（自动镜像）：仅「删除清理」或「冲突」弹窗，纯新增/无变化静默
  // ★ v1.35.10 快照按浏览器源独立（{Chrome:[...], Edge:[...]}）——Chrome 的删除只对
  //   Chrome 基线做差；否则双浏览器场景下，后同步的源会把先同步源独有的条目
  //   误判为"浏览器已删除"而误删（本次事故根因）。
  function syncFromBrowser(browser, content, auto) {
    let inc;
    try { inc = parseBrowserJSON(content); } catch (e) { return; }
    // ★ 快照 key 统一小写（手动链路回传 'Chrome'、自动链路/测试可能传 'chrome'，
    //   大小写混用会导致基线对不上 → 清理失效或误判）
    const bkey = String(browser || '').toLowerCase();
    const browserUrls = [...new Set((inc.bookmarks || [])
      .map((b) => String(b.url || '').trim()).filter(Boolean))];
    const cleanedNames = [];
    if (mirrorSync) {
      // 兼容旧平铺数组格式（按无基线处理，重建基线）
      const snapMap = (window.__BM_SYNC_SNAP && !Array.isArray(window.__BM_SYNC_SNAP))
        ? window.__BM_SYNC_SNAP : {};
      const snapArr = (snapMap[bkey] || []).map((u) => String(u || '').trim()).filter(Boolean);
      if (snapArr.length) {
        const bset = new Set(browserUrls);
        const gone = new Set(snapArr.filter((u) => !bset.has(u)));
        // ★ 保险丝：一次清理超过 40 条（占本地 1/3 以上）极可能是基线异常而非
        //   真实用户操作——拒绝自动清理并提示，防批量误删事故
        const goneInLocal = list.filter((b) => gone.has(String(b.url || '').trim()));
        if (goneInLocal.length > 40) {
          try {
            if (window.Menu && window.Menu.ask) window.Menu.ask('镜像清理已中止',
              `本次判定需清理 ${goneInLocal.length} 条（占现有书签比例过大），\n已拒绝执行以保护数据。\n请手动点一次「同步」核对差异，或关闭/重新开启镜像以重建基线。`, '好的', () => {});
          } catch (e) { /* ignore */ }
          snapMap[bkey] = browserUrls;   // ★ 中止也要刷新基线，防止每次同步重复弹窗
          window.__BM_SYNC_SNAP = snapMap;
          try { window.desknest.saveBmSnap(snapMap); } catch (e) { /* ignore */ }
          return;
        }
        if (gone.size) {
          for (const b of goneInLocal) cleanedNames.push(b.name || b.url);
          if (cleanedNames.length) {
            list = list.filter((b) => !gone.has(String(b.url || '').trim()));
            for (const u of gone) {
              if (!removedUrls.has(u)) {
                removedUrls.add(u);
                try { window.desknest.bmRemovedUrl(u); } catch (e) { /* ignore */ }
              }
            }
          }
        }
      }
    }
    const r = mergeIncoming(inc, true, mirrorSync);
    // 更新该源的快照基线（镜像关也更新，保持基线新鲜）
    const snapMap2 = (window.__BM_SYNC_SNAP && !Array.isArray(window.__BM_SYNC_SNAP))
      ? window.__BM_SYNC_SNAP : {};
    snapMap2[bkey] = browserUrls;
    window.__BM_SYNC_SNAP = snapMap2;
    try { window.desknest.saveBmSnap(snapMap2); } catch (e) { /* ignore */ }
    if (r.conflicts.length) pendingConflicts = pendingConflicts.concat(r.conflicts);
    if (open) render();
    try {
      if (window.Menu && window.Menu.ask) {
        if (auto) {
          // ★ 自动镜像弹窗策略：只有「用户需要知道/处理」的事才打扰
          //   v1.39.0：folderMoved（文件夹归属跟随浏览器调整）也值得告知——
          //   用户在浏览器整理文件夹后，本地结构变化需要可见
          if (cleanedNames.length || r.conflicts.length || r.folderMoved) {
            const cl = cleanedNames.slice(0, 5);
            window.Menu.ask(`自动镜像（${browser}）`,
              (cleanedNames.length
                ? `已跟随浏览器删除 ${cleanedNames.length} 条：${cl.join('、')}${cleanedNames.length > cl.length ? ' 等' : ''}\n`
                : '') +
              (r.added ? `新增 ${r.added} 条。\n` : '') +
              (r.folderMoved ? `已按浏览器调整 ${r.folderMoved} 条书签的文件夹归属。\n` : '') +
              (r.conflicts.length
                ? `检测到 ${r.conflicts.length} 条同名不同址冲突，请在管理器顶部逐条处理。`
                : ''),
              '好的', () => {});
          }
          // 纯新增/无变化：静默（书签列表本身就是反馈）
        } else {
          const names = (r.addedNames || []).slice(0, 5);
          const cl = cleanedNames.slice(0, 5);
          window.Menu.ask(`同步 ${browser} 完成`,
            `新增 ${r.added} 条书签。` +
            // ★ v1.39.0 文件夹归属调整回显：用户能核对"办公"等文件夹是否补齐
            (r.folderMoved ? `\n${r.folderMoved} 条已有书签归入浏览器侧所在的文件夹。` : '') +
            // ★ 回显新增名称：用户能直接核对"某条书签到底有没有进来"（问题③）
            (names.length ? `\n${names.join('、')}${r.added > names.length ? ' 等' : ''}` : '') +
            // ★ v1.35.4 镜像清理回显：浏览器里删了哪些、本地跟着删了哪些
            (cleanedNames.length
              ? `\n\n镜像清理 ${cleanedNames.length} 条（浏览器已删除）：${cl.join('、')}${cleanedNames.length > cl.length ? ' 等' : ''}`
              : (mirrorSync ? '\n\n镜像模式生效中：本次浏览器侧无删除，本地无需清理。' : '')) +
            (r.unlockedNames && r.unlockedNames.length
              ? `\n解除黑名单并加回 ${r.unlockedNames.length} 条：${r.unlockedNames.slice(0, 5).join('、')}`
              : '') +
            (r.conflicts.length
              ? `\n\n检测到 ${r.conflicts.length} 条同名不同址冲突——原数据未被覆盖，\n请在管理器顶部逐条选择「用浏览器版」或「保留现有」。`
              : '\n\n现有书签未做任何覆盖。可在面板顶部搜索框按名称/网址查找。'),
            '好的', () => {});
        }
      }
    } catch (e) { /* ignore */ }
  }

  // 原生浏览器同步回发：<browser> <Chrome 格式 JSON>（原生已先做备份）
  window.__onBookmarksSync = (browser, content) => syncFromBrowser(browser, content, false);
  // ★ v1.35.8 自动镜像回发：原生泵监听到浏览器书签变化 / sync-auto 对齐触发
  window.__onBookmarksSyncAuto = (browser, content) => syncFromBrowser(browser, content, true);

  // ★ v1.39.0 启动对齐（镜像开启时）：页面就绪后对自动同步源各做一次静默对齐——
  //   ① 修复历史漂移：浏览器侧后来整理出的文件夹结构（如「办公」25 条），本地已有
  //      条目此前"只增不归位"，现在 mergeIncoming 会把已有条目跟随浏览器重新归夹；
  //   ② 关机/离线期间浏览器侧的增删，启动即同步，无需等下一次文件变化才触发。
  //   ★ v1.39.x 范围收窄：只对齐 bmAutoSources（默认仅 Chrome），其他浏览器
  //   在用户手动点过其同步按钮后才纳入。缺书签文件时原生为静默 elog，不弹框。
  if (mirrorSync) {
    setTimeout(() => {
      for (const s of autoSources()) {
        try { window.desknest.syncAuto(capSrc(s)); } catch (e) { /* ignore */ }
      }
    }, 8000);
  }

  window.__onBookmarksSyncErr = (msg) => {
    try {
      if (window.Menu && window.Menu.ask) window.Menu.ask('同步失败', msg || '未知错误', '好的', () => {});
    } catch (e) { /* ignore */ }
  };

  // 冲突处理：useBrowser=true → 该条采用浏览器版（名称+归入对应文件夹）；否则保留现有
  function resolveConflict(i, useBrowser) {
    const c = pendingConflicts[i];
    if (!c) return;
    if (useBrowser) {
      c.cur.name = c.inc.name;
      if (c.inc.folder) c.cur.folder = c.inc.folder;
    }
    pendingConflicts.splice(i, 1);
    save();
    if (open) render();
  }
  function resolveAllConflicts(useBrowser) {
    for (const c of pendingConflicts) {
      if (useBrowser) {
        c.cur.name = c.inc.name;
        if (c.inc.folder) c.cur.folder = c.inc.folder;
      }
    }
    pendingConflicts = [];
    save();
    if (open) render();
  }

  function doExport(ext) {
    fmtOpen = false;
    const text = ext === 'html' ? genHTML() : ext === 'csv' ? genCSV() : genJSON();
    try { window.desknest.exportBookmarks(ext, text); } catch (e) { /* ignore */ }
    if (open) render();
  }

  // —— 事件绑定 ——

  function focusSel(sel) {
    const el = body.querySelector(sel);
    if (el) el.focus();
  }

  function wire() {
    // ★ 文件夹行：点本体 = 展开/折叠（✎/🗑 按钮有 data-act，各自拦截）
    body.querySelectorAll('.bm-folder-row').forEach((frow) => {
      frow.addEventListener('click', (e) => {
        if (e.target.closest('[data-act]')) return;
        const fid = frow.dataset.fid;
        if (expandedFolders.has(fid)) expandedFolders.delete(fid);
        else expandedFolders.add(fid);
        render();
      });
    });
    // 书签行：点名字 = 打开 + 计数 + 面板自动关闭；按钮各自拦截
    body.querySelectorAll('.bm-item').forEach((row) => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('.bm-act')) return;
        const b = list.find((x) => String(x.id) === String(row.dataset.id));
        if (!b) return;
        window.desknest.launch({ path: b.url, name: b.name });
        b.count = (b.count || 0) + 1;
        b.lastUsed = Date.now();
        save();
        setOpen(false);   // ★ 需求②：跳转后面板自动关闭
      });
    });
    // favicon 加载失败 → 回退字母头像
    body.querySelectorAll('img.bm-fav').forEach((img) => {
      img.addEventListener('error', () => {
        const row = img.closest('.bm-item');
        const b = row && list.find((x) => String(x.id) === String(row.dataset.id));
        if (b) delete b.icon;
        const ch = (String((b && b.name) || '').trim().charAt(0) || '?').toUpperCase();
        const sp = document.createElement('span');
        sp.className = 'bm-fav bm-fav-letter';
        sp.textContent = ch;
        img.replaceWith(sp);
      });
    });
    // 各类按钮（书签行 / 文件夹行 / 移动菜单 / 新建文件夹）
    [...body.querySelectorAll('[data-act]'), ...toolbar.querySelectorAll('[data-act]')].forEach((el) => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const act = el.dataset.act;
        if (act === 'newfolder') { addingFolder = true; adding = false; editingId = null; render(); focusSel('.bm-ff-name'); return; }
        if (act === 'refresh-all') {
          list.forEach((b) => { delete b.icon; });
          save(); render();
          // 200ms 间隔逐个请求，避免瞬时并发线程风暴
          list.forEach((b, i) => { setTimeout(() => requestFav(b), i * 200); });
          return;
        }
        // ★ v1.39.x 手动点「同步 Edge」= 把 Edge 纳入自动同步范围（registerSource
        //   持久化到 config.bmAutoSources），此后泵监听/启动对齐跟随 Edge；
        //   Chrome 恒为默认自动源，手动同步不改变范围
        if (act === 'sync-edge') { registerSource('edge'); try { window.desknest.syncBrowser('edge'); } catch (e) { /* ignore */ } return; }
        if (act === 'sync-chrome') { try { window.desknest.syncBrowser('chrome'); } catch (e) { /* ignore */ } return; }
        if (act === 'sync-file') { try { window.desknest.syncBrowserFile(); } catch (e) { /* ignore */ } return; }
        if (act === 'exp-json') { doExport('json'); return; }
        if (act === 'exp-html') { doExport('html'); return; }
        if (act === 'exp-csv') { doExport('csv'); return; }
        if (act === 'exp-cancel') { fmtOpen = false; render(); return; }
        if (act === 'conf-keep') { resolveConflict(Number(el.dataset.ci), false); return; }
        if (act === 'conf-in') { resolveConflict(Number(el.dataset.ci), true); return; }
        if (act === 'conf-all-keep') { resolveAllConflicts(false); return; }
        if (act === 'conf-all-in') { resolveAllConflicts(true); return; }
        if (act === 'moveto') {
          const b = list.find((x) => String(x.id) === String(pickFor));
          if (b) { b.folder = Number(el.dataset.fid) || 0; save(); }
          pickFor = null; render(); return;
        }
        if (act === 'mvclose') { pickFor = null; render(); return; }
        const row = el.closest('.bm-item');   // ★ data-id 在 .bm-item 载体上（.bm-row 无 data-id）
        const frow = el.closest('.bm-folder-row');
        if (act === 'frename-ok' || act === 'frename-no') {
          if (act === 'frename-ok') {
            const inp = frow && frow.querySelector('.bm-fr-name');
            const f = folders.find((x) => String(x.id) === String(editingFolder));
            if (f && inp && inp.value.trim()) { f.name = inp.value.trim(); save(); }
          }
          editingFolder = null; render(); return;
        }
        if (act === 'frename' && frow) { editingFolder = frow.dataset.fid; addingFolder = false; render(); focusSel('.bm-fr-name'); return; }
        if (act === 'fdel' && frow) {
          const f = folders.find((x) => String(x.id) === String(frow.dataset.fid));
          if (!f) return;
          const doDel = () => {
            list.forEach((b) => { if (String(b.folder) === String(f.id)) b.folder = 0; });
            folders = folders.filter((x) => String(x.id) !== String(f.id));
            save(); render();
          };
          if (window.Menu && window.Menu.ask) {
            window.Menu.ask('删除文件夹', `将删除文件夹「${f.name}」，其中的书签移回根目录。`, '删除', doDel);
          } else { doDel(); }
          return;
        }
        const b = row ? list.find((x) => String(x.id) === String(row.dataset.id)) : null;
        if (!b) return;
        if (act === 'pin') {
          b.pinned = !b.pinned; save(); render();
        } else if (act === 'edit') {
          editingId = b.id; adding = false; pickFor = null; render();
        } else if (act === 'fav') {
          // 单条刷新：先回退占位头像，抓取成功由 __onFavicon 回填；失败保持占位
          delete b.icon; save(); render(); requestFav(b);
        } else if (act === 'move') {
          pickFor = (pickFor != null && String(pickFor) === String(b.id)) ? null : b.id;
          adding = false; editingId = null; render();
        } else if (act === 'del') {
          // ★ v1.33.9 删除同步：按 URL 清理"所有"引用该地址的条目
          //   （同一网址可能同时存在于多个文件夹：手工添加的 + 从 Edge/Chrome 导入的分组各一份。
          //    旧实现只按 id 删一条 → 其它分组里同址记录残留，下次同步又被当成"已有"而不清理，
          //    表现为「删了百度，谷歌书签里还有百度」）
          const urlKey = String(b.url || '').trim();
          const dupes = urlKey ? list.filter((x) => String(x.url || '').trim() === urlKey) : [b];
          const n = dupes.length;
          const names = new Set(dupes.map((x) => x.folder || 0));
          const tip = n > 1
            ? `将删除所有引用该网址的 ${n} 条记录（分布在 ${names.size} 个分组）。`
            : '';
          const doDel = () => {
            list = list.filter((x) => (urlKey ? String(x.url || '').trim() !== urlKey : x.id !== b.id));
            // URL 记入原生黑名单（removed-urls.json）→ 之后同步 Edge/Chrome / 导入文件时跳过，
            // 删除不会被同步"复活"；内存表同步维护，立即对本次会话生效
            try { window.desknest.bmRemovedUrl(urlKey); } catch (e) { /* ignore */ }
            removedUrls.add(urlKey);
            // ★ v1.37.0 删除写回浏览器（镜像开时）：URL 入原生待写回队列，
            //   浏览器全部关闭后自动从 Chrome/Edge 删除，无需手动去浏览器删
            if (mirrorSync && urlKey) {
              try { window.desknest.bmBrowserDel(urlKey); } catch (e) { /* ignore */ }
            }
            save(); render();
          };
          if (window.Menu && window.Menu.ask) {
            window.Menu.ask('删除书签',
              `将删除「${b.name}」。${tip}\n` +
              `该网址会记入删除名单：之后同步 Edge/Chrome 或导入文件时不会再回来。` +
              (mirrorSync
                ? `\n镜像同步已开启：将自动从 Chrome/Edge 中删除该网址\n（浏览器关闭后自动执行，无需手动操作）。`
                : `\n（浏览器里原有的那条需你在浏览器中自行删除；\n开启「镜像:开」后可自动写回浏览器）。`),
              '删除', doDel);
          } else {
            doDel();
          }
        }
      });
    });
    // 表单（添加/编辑书签）
    const form = body.querySelector('.bm-form[data-id]');
    if (form) {
      const id = form.dataset.id;
      const nameI = form.querySelector('.bm-f-name');
      const urlI = form.querySelector('.bm-f-url');
      const folderSel = form.querySelector('.bm-f-folder');
      const commit = () => {
        const name = nameI.value.trim();
        let url = urlI.value.trim();
        if (!name || !url) return;
        if (!/^[a-z]+:\/\//i.test(url) && !/^[a-z]:[\\/]/i.test(url) && !url.startsWith('\\\\')) {
          url = 'https://' + url;
        }
        const fid = Number(folderSel && folderSel.value) || 0;
        let target = null;
        if (id) {
          const b = list.find((x) => String(x.id) === String(id));
          if (b) {
            const urlChanged = b.url !== url;
            b.name = name; b.url = url; b.folder = fid;
            if (urlChanged) delete b.icon;   // 网址变了，旧 favicon 作废
            target = urlChanged ? b : null;
          }
        } else {
          const nb = { id: Date.now(), name, url, folder: fid, count: 0, lastUsed: 0, pinned: false, icon: null };
          list.push(nb);
          target = nb;
        }
        // ★ v1.35.4 黑名单解锁：手动添加/改址 = 明确的重新收录意图，即时解除页面侧
        //   黑名单（磁盘侧由 save-bookmarks 的自清洁兜底剔除）
        if (url && removedUrls.has(String(url).trim())) removedUrls.delete(String(url).trim());
        editingId = null; adding = false;
        save(); render();
        if (target) requestFav(target);   // ★ 需求三：添加/改址后自动抓取 favicon
      };
      form.querySelector('.bm-save').addEventListener('click', commit);
      form.querySelector('.bm-cancel').addEventListener('click', () => { editingId = null; adding = false; render(); });
      [nameI, urlI].forEach((i) => i.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter') commit();
        else if (e.key === 'Escape') { editingId = null; adding = false; render(); }
      }));
      if (folderSel) folderSel.addEventListener('keydown', (e) => e.stopPropagation());
      nameI.focus();
    }
    // 新建文件夹表单
    const ffForm = body.querySelector('.bm-ff-name');
    if (ffForm) {
      const commitF = () => {
        const nm = ffForm.value.trim();
        if (!nm) return;
        folders.push({ id: Date.now(), name: nm });
        addingFolder = false;
        save(); render();
      };
      body.querySelector('.bm-ff-ok').addEventListener('click', commitF);
      body.querySelector('.bm-cancel').addEventListener('click', () => { addingFolder = false; render(); });
      ffForm.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter') commitF();
        else if (e.key === 'Escape') { addingFolder = false; render(); }
      });
      ffForm.focus();
    }
    // 文件夹改名输入
    const frInp = body.querySelector('.bm-fr-name');
    if (frInp) frInp.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') { const b = body.querySelector('[data-act="frename-ok"]'); if (b) b.click(); }
      else if (e.key === 'Escape') { editingFolder = null; render(); }
    });
  }

  // —— 显隐 ——

  function setOpen(v) {
    open = v;
    panel.hidden = !v;
    // 每次打开清空搜索（避免上次关键字把列表过滤得"看起来像没同步"）
    if (v) { adding = false; editingId = null; pickFor = null; query = ''; if (qEl) qEl.value = ''; render(); }
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(220);
  }

  function toggle() {
    if (window.Dock && window.Dock.closeAll) window.Dock.closeAll();
    try { window.Search.close(); } catch (e) {}
    try { window.Settings.close(); } catch (e) {}
    try { window.Cats.close(); } catch (e) {}
    setOpen(!open);
  }

  btn.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });
  // ★ v1.33.10 搜索框：输入即过滤（keydown 拦截避免被全局快捷键/菜单逻辑吃掉）
  if (qEl) {
    qEl.addEventListener('input', () => { query = qEl.value.trim(); render(); });
    qEl.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Escape') { query = ''; qEl.value = ''; render(); }
    });
    qEl.addEventListener('mousedown', (e) => e.stopPropagation());
  }
  addBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    if (manage) { addingFolder = true; editingId = null; render(); focusSel('.bm-ff-name'); }
    else { adding = true; editingId = null; pickFolder = 0; render(); }
  });
  manageBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    manage = !manage;
    adding = false; addingFolder = false; editingId = null; editingFolder = null; pickFor = null;
    render();
  });
  importBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    try { window.desknest.importBookmarks(); } catch (err) { /* ignore */ }
  });
  exportBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    fmtOpen = !fmtOpen;   // 展开格式选择器（JSON / HTML / CSV）
    render();
  });
  // ★ v1.35.7 镜像同步开关：状态进 config 持久化，跨重启生效
  mirrorBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    mirrorSync = !mirrorSync;
    try { window.desknest.saveConfig({ bmMirrorSync: mirrorSync }); } catch (err) { /* ignore */ }
    syncHead();
    // ★ 开启即说明规则（用户反馈"感觉无用"→ 效果不可见 + 首次同步只建基线不清理）
    if (mirrorSync) {
      try { if (window.Menu && window.Menu.ask) window.Menu.ask('镜像同步已开启（全自动）',
        '已与当前浏览器内容对齐为基线，之后无需任何手动操作：\n① 浏览器里删除书签 → 约 10 秒内自动从本地删除（弹窗列清单）；\n② 浏览器里新增/重新收藏 → 自动加回，黑名单自动解除；\n③ 仅发生删除清理或冲突时才弹窗，其余静默。\n\n自动跟随范围：默认仅 Chrome；其他浏览器需在书签管理器手动点过其「同步」按钮后纳入。\n不想跟随删除时，点回「镜像:关」即可。', '好的', () => {}); } catch (err) { /* ignore */ }
      // ★ 立即对齐一次（静默通道）：旧快照与当前浏览器的差异（开启前浏览器侧
      //   已删除的）此时一并清理，后续变化由原生泵监听自动跟随。
      //   ★ v1.39.x 只对齐 bmAutoSources（默认仅 Chrome）
      for (const s of autoSources()) {
        try { window.desknest.syncAuto(capSrc(s)); } catch (err) { /* ignore */ }
      }
    }
  });
  syncHead();   // ★ 启动即同步按钮文案（镜像开/关），不等首次交互

  // 点外关闭
  document.addEventListener('mousedown', (e) => {
    if (open && !e.target.closest('#bm-panel') && !e.target.closest('#bm-btn')) setOpen(false);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && open) setOpen(false);
  });

  return {
    toggle, setOpen, isOpen: () => open,
    reload: () => ingest(window.__BOOKMARKS),
    // ★ 测试钩子（_t80）：自动同步源只读视图 + 登记入口
    __autoSources: autoSources,
    __registerSource: registerSource,
  };
})();
