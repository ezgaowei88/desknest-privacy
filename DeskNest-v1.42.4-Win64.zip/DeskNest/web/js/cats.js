// cats.js：自定义分类（新建 / 重命名 / 换图标 / 换颜色 / 删除）+ 条目移动浮层
'use strict';

window.Cats = (() => {
  const bar = document.getElementById('cats-bar');
  const list = document.getElementById('cats-list');
  const addBtn = document.getElementById('cats-add');
  const menu = document.getElementById('move-menu');

  let pickerFor = null;   // 当前展开图标/颜色选择器的分类 id
  let menuFor = null;     // 移动浮层当前对应的条目 path
  let outsideBound = false;

  function colorOf(cat) { return cat.color || '#00E58C'; }

  function render() {
    const cats = window.Dock.getCats();
    list.innerHTML = '';
    for (const cat of cats) {
      const row = document.createElement('div');
      row.className = 'cat-row';
      row.dataset.id = cat.id;
      // ★ 不设 draggable=true：组合宿主下 HTML5 DnD 不可用（同 dock.js 分类芯片），
      //   draggable 会触发 Chromium 指针流接管（pointercancel）干扰普通鼠标交互；
      //   排序由右键菜单（整理/左右移）承担，dragstart 监听保留待壳实现拖放转发。
      row.innerHTML =
        `<div class="ic" title="更换图标 / 颜色" style="color:${colorOf(cat)}">${window.Dock.catIconSvg(cat.icon)}</div>` +
        `<input class="nm" value="${escapeAttr(cat.name)}" ${cat.id === 'uncategorized' ? 'readonly' : ''}>` +
        `<span class="n">${cat.items.length}</span>` +
        (cat.id === 'uncategorized' ? '' : '<button class="del" title="删除分类（条目并入未分类）">✕</button>');

      row.querySelector('.ic').addEventListener('click', () => {
        pickerFor = pickerFor === cat.id ? null : cat.id;
        render();
      });
      const nm = row.querySelector('.nm');
      if (cat.id !== 'uncategorized') {
        nm.addEventListener('change', () => {
          const v = nm.value.trim();
          if (!v) { nm.value = cat.name; return; }
          window.Dock.upsertCategory({ id: cat.id, name: v });
        });
        nm.addEventListener('keydown', (e) => { if (e.key === 'Enter') nm.blur(); });
      }
      const del = row.querySelector('.del');
      if (del) {
        del.addEventListener('click', () => {
          if (cats.length <= 1) return;
          window.Dock.removeCategory(cat.id);
        });
      }
      attachRowDrag(row);
      // ★ 右键：与坞上芯片同一套分类菜单（打开/整理排序/重命名/左右移）
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.Menu) window.Menu.open({ kind: 'cat', cat }, e.clientX, e.clientY);
      });
      list.appendChild(row);

      if (pickerFor === cat.id) list.appendChild(buildPicker(cat));
    }
  }

  // —— 分类管理面板内的拖拽排序（垂直列表）——
  let rowDragging = false;

  function attachRowDrag(row) {
    // 组合宿主下 dragstart 永不触发（无 draggable 且壳未实现拖放转发），监听保留备用
    row.addEventListener('dragstart', (e) => {
      rowDragging = true;
      row.classList.add('dragging');
      pickerFor = null;                                   // 收起展开中的选择器，避免随拖拽错位
      list.querySelectorAll('.picker').forEach((p) => p.remove());
      try {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', row.dataset.id);
      } catch { /* ignore */ }
    });
    row.addEventListener('dragend', () => {
      rowDragging = false;
      row.classList.remove('dragging');
      commitRowOrder();
    });
  }

  function rowAfterElement(y) {
    const nodes = [...list.querySelectorAll('.cat-row:not(.dragging)')];
    let closest = null;
    let closestD = -Infinity;
    for (const n of nodes) {
      const r = n.getBoundingClientRect();
      const d = y - (r.top + r.height / 2);
      if (d < 0 && d > closestD) { closestD = d; closest = n; }
    }
    return closest;
  }

  list.addEventListener('dragover', (e) => {
    if (!rowDragging) return;
    e.preventDefault();
    try { e.dataTransfer.dropEffect = 'move'; } catch { /* ignore */ }
    const src = list.querySelector('.cat-row.dragging');
    if (!src) return;
    const after = rowAfterElement(e.clientY);
    if (after == null) {
      if (list.lastElementChild !== src) list.appendChild(src);
    } else if (after !== src) {
      list.insertBefore(src, after);
    }
  });
  list.addEventListener('drop', (e) => { if (rowDragging) e.preventDefault(); });

  function commitRowOrder() {
    const order = [...list.querySelectorAll('.cat-row')].map((n) => n.dataset.id);
    if (!order.length) return;
    const cats = window.Dock.getCats();
    const map = new Map(cats.map((c) => [c.id, c]));
    const next = order.map((id) => map.get(id)).filter(Boolean);
    for (const c of cats) if (!order.includes(c.id)) next.push(c);   // 兜底防丢
    // 与坞上拖拽共用同一条持久化链路（Dock.persist 会同时重渲染坞与面板）
    cats.length = 0;
    cats.push(...next);
    window.Dock.persist();
  }

  function buildPicker(cat) {
    const wrap = document.createElement('div');
    wrap.className = 'picker';
    const icons = document.createElement('div');
    icons.className = 'icons';
    for (const key of window.Dock.ICON_KEYS) {
      const d = document.createElement('div');
      d.innerHTML = window.Dock.CAT_ICONS[key];
      d.title = key;
      if (String(cat.icon || '').replace(/^builtin:/, '') === key) d.classList.add('sel');
      d.addEventListener('click', () => window.Dock.upsertCategory({ id: cat.id, icon: `builtin:${key}` }));
      icons.appendChild(d);
    }
    const colors = document.createElement('div');
    colors.className = 'colors';
    for (const c of window.Dock.PALETTE) {
      const d = document.createElement('div');
      d.style.background = c;
      if (String(colorOf(cat)).toLowerCase() === c.toLowerCase()) d.classList.add('sel');
      d.addEventListener('click', () => window.Dock.upsertCategory({ id: cat.id, color: c }));
      colors.appendChild(d);
    }
    wrap.appendChild(icons);
    wrap.appendChild(colors);
    return wrap;
  }

  addBtn.addEventListener('click', () => {
    const row = document.createElement('div');
    row.className = 'cat-row';
    row.innerHTML = '<input class="nm" placeholder="新分类名称，回车确认">';
    const input = row.querySelector('.nm');
    list.prepend(row);
    input.focus();
    const commit = () => {
      const v = input.value.trim();
      if (!v) { row.remove(); return; }
      const id = 'custom-' + Date.now().toString(36);
      // ★ v1.40.9 新建后自动展开该分类的图标/颜色选择器（先置 pickerFor 再建分类，
      //   persist 内的 Cats.render 会按 pickerFor 在新分类行后渲染展开的选择器）
      pickerFor = id;
      window.Dock.upsertCategory({ id, name: v, icon: 'builtin:folder', color: window.Dock.PALETTE[0], items: [] });
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') commit();
      else if (e.key === 'Escape') row.remove();
    });
    input.addEventListener('blur', () => setTimeout(() => { if (row.isConnected) commit(); }, 120));
  });

  // —— 条目移动浮层 ——
  function openMoveMenu(item, anchor) {
    menuFor = item.path;
    menu.hidden = false;
    menu.innerHTML = '';
    const t = document.createElement('div');
    t.className = 'mm-title';
    t.textContent = `移动「${window.Dock.dispName(item)}」到`;
    menu.appendChild(t);

    for (const cat of window.Dock.getCats()) {
      const d = document.createElement('div');
      d.className = 'mm-item';
      d.innerHTML = `<span class="sw" style="background:${colorOf(cat)}"></span>` +
        window.Dock.catIconSvg(cat.icon) +
        `<span>${escapeHtml(cat.name)}</span>`;
      d.addEventListener('click', () => {
        // ★ 来源分类内定位（同名条目多分类共存时不误移）
        const found = window.Dock.findInCategories((it) => it.path === item.path);
        window.Dock.moveItem(found ? found.cat.id : undefined, item.path, cat.id);
        closeMoveMenu();
      });
      menu.appendChild(d);
    }

    const r = anchor.getBoundingClientRect();
    const mw = menu.offsetWidth || 160;
    let x = r.left - mw + r.width;
    x = Math.max(8, Math.min(x, window.innerWidth - mw - 8));
    let y = r.bottom + 6;
    if (y + menu.offsetHeight > window.innerHeight - 8) y = Math.max(8, r.top - menu.offsetHeight - 6);
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';

    bindOutside();
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(30);
  }

  function closeMoveMenu() {
    if (menu.hidden) return;
    menu.hidden = true;
    menuFor = null;
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(30);
  }

  function bindOutside() {
    if (outsideBound) return;
    outsideBound = true;
    window.addEventListener('mousedown', (e) => {
      if (menu.hidden) return;
      if (menu.contains(e.target)) return;
      if (e.target.closest && e.target.closest('.mv')) return;
      closeMoveMenu();
    });
  }

  function open() {
    bar.hidden = false;
    render();
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon(220);
  }

  function close() {
    bar.hidden = true;
    pickerFor = null;
    closeMoveMenu();
    if (window.DeskUI && window.DeskUI.reportShapeSoon) window.DeskUI.reportShapeSoon();
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function escapeAttr(s) { return escapeHtml(s); }

  return { render, open, close, openMoveMenu, closeMoveMenu, isOpen: () => !bar.hidden, menuOpen: () => !menu.hidden };
})();
